# Cotiviti New Hire Onboarding deck — Data Engineering AI Solutions Team (dated 08/20/2026)

Source: 45 phone photos of the deck and the linked SharePoint / cotiviti.com fact sheets, in D:\Cotiviti\cotiviti_new_hire_info (photographed Sep 17, 2026). Deck is 16 slides; agenda: Welcome · What Cotiviti does · Services and LOBs · Impact · AI Solutions team · Data Engineering projects · Links.

## What Cotiviti does

- Healthcare analytics and technology company; "The Healthcare Infrastructure Company". Problem solved: healthcare data is fragmented across payers, providers, government programs, employers and members, causing delayed decisions, admin complexity, payment inaccuracies and rising cost.
- Works with 200+ payers and health systems, including all top 25 US plans. Roughly $10B/yr in identified and corrected medical spend through prepay and postpay payment integrity. Processes $380B+ in annual claims for clients.
- Six solution areas: Payment accuracy (stop/recover improper payments across the claim lifecycle), Interoperability (one pathway for data exchange and governance), Risk adjustment (plans reimbursed appropriately for member risk), Quality and Stars, Engagement (multi-channel member outreach), Retail (audit/recovery outside healthcare).

## Where Cotiviti sits in the claim value chain

Market slide: "Payment Integrity vendors along the claim value chain." Flow: Member claims → Providers (Epic, Availity, Claritev) → Clearinghouse (837/835; UnitedHealthcare, Change, TriZetto, Waystar) → Gateway (Edifecs, Plexis, SSI) → Payer CAS / claim systems (HealthEdge, Cognizant, Infosys, Rialtic, ClarisHealth) → Payment Integrity Pass 1 (Optum, Lyric, Zelis, Machinify) → Pass 2 (Cotiviti, Lyric: final-filter editing, core and code auditing, CMS/Medicaid-sourced, facility, medical policy, NCD/LCD, specialty Rx, waste and abuse, custom rules, COB, clinical chart review, claim pattern review, pharmacy, dental) → Client results (postpay editing, data mining, clinical chart validation, COB, subrogation, denials management). All vendors are "shifting left" toward prevention and AI.

## Lines of business (LOB abbreviations)

PPM = Prepay Claims (Payment Policy Management) · CCV = Clinical Chart Validation · CV = Coding Validation · RCA = Retrospective Claims Analysis · HE = Health Enablement · OI = Opportunity Intelligence · FWA/CPR = Fraud, Waste and Abuse (Claim Pattern Review) · RA = Risk Adjustment · EI = Early Intervention.

SharePoint product-hub navigation (sites/cpmc): PCA → Payment Policy Management, Coding Validation · RCA → Contract Compliance, COB Validation, Payment Data Validation · CCV · FWA → FWA Validation, Sentinel, Commander, Informant, SIU Services · Risk Adjustment → Medical Record Coding, Medical Record Retrieval, Submissions, In-Home Assessments · Quality → Quality Intelligence, Star Intelligence, State and Custom Measures, Abstraction · Performance Analytics → DxCG, Medical Intelligence, Enterprise Intelligence, Provider Intelligence.

ARIA relevance: ARIA (risk-adjustment chart coding) lives under Risk Adjustment / Medical Record Coding, within the Health Enablement business unit. Rutvi's new team is on the RCA side.

## Product notes (from the fact sheets)

- PPM / Payment Policy Management: correct-coding and medical-policy content library applied to claims; $3.7B total annual net savings; 1–3% estimated savings on professional and institutional claims. Payment Clarity is the transparency portal (Program Clarity, Policy Clarity, Claim Clarity modules); Claims Inquiry Service integrates explanations into provider portals (>40% reduction in claim edit inquiries).
- Coding Validation (formerly Clinical Validation): adds a line of defense beyond primary automated editing; catches claim lines with modifiers that override edits; nurses and coding experts review flagged complex claims before adjudication. Typical error mix: multiple E/M services, global surgical package modifiers, mutually exclusive modifiers, cross-provider duplicates, unbundling (modifiers 25/59). Contacts on SharePoint: Michael Jablon (VP, PCA), Cheryl Thomas (Sr Product Manager, Coding Validation).
- Clinical Chart Validation (CCV): prospective and retrospective clinical review of inpatient DRG, short stay and readmission claims; ML picks charts with highest overpayment probability; cross-claim clinical review follows the member journey. Metrics: 3–5% potential savings on inpatient spend, 42% change rate on prospectively reviewed charts, 97% sustainability of audit findings. Contacts: Jena Reilly (Director, CCV), Brett Arnold (VP Product Management, RCA).
- RCA = COB Validation + Payment Data Validation + Contract Compliance. Contacts: Brett Arnold, Mary Dunklee (Sr Product Director, RCA).
- COB Validation: >190M members covered, >99% findings sustained, $945M client savings in 2025. Proactive COB moves COB upstream to enrollment (20–30% of COB errors prevented upstream, >40% reduction in retrospective recovery volume).
- Data Mining: >$2.5B overpayment findings identified in 2025, 0.6% average savings on annual medical spend, 97% sustainability; >2,000 concepts.
- Contract Compliance: validates provider contract terms, rate schedules, fee schedules, amendments; audit tool models unique provider contracts.
- FWA: 360 Pattern Review = prepay Claim Pattern Review + postpay FWA Pattern Review (>$21B suspect claims identified annually, >75 credentialed analysts, >25 years). FWA Pattern Review: >$18.6B suspect FWA claims identified in 2024. Claim Pattern Review: $56M prepay savings over three years for one client, 80% client approval of outlier provider referrals. SIU Services: investigative, clinical review, claims verification, consultative support, lead generation.
- Dental Claim Accuracy: prepay dental model; >3% additional savings, 100% of flagged claims reviewed.

## AI Solution Team structure (slide 13)

LOB Stakeholder · Data Science Team · Data Engineering Team · Feature Engineering Team (offshore India) · MLOps.

## Data Engineering Team Offerings (slide 12)

Three groups: AI Solutions (5 items), Data Platform Offerings (3 items), Data Product Offerings (2 items). Bullet text was not legible in the photos — get the deck file for the details.

## Links from the deck

- PPM: cotiviti.sharepoint.com/sites/cpmc/PCA/ppm/SitePages/ppm.aspx · resources.cotiviti.com/payment-accuracy-solutions/payment-policy-management-solution
- CV: cotiviti.sharepoint.com/sites/cpmc/PCA/CV/SitePages/CV.aspx
- CCV: cotiviti.sharepoint.com/sites/cpmc/CCV/SitePages/CCV.aspx
- RCA: cotiviti.sharepoint.com/sites/cpmc/RCA/SitePages/RCA.aspx (+ /RCA/CC, /RCA/CV, /RCA/PDV pages)
- Data Engineering projects and architecture: cotiviti.atlassian.net/wiki/spaces/MLSA/pages/244647835/LOBS+we+work+with+and+data+Flow+Solutions
- Data Science use cases (Confluence MLSA space): Use Cases – PPM, Use Cases – CCV, Use Cases – RCA, Use Cases – CV (confluence2.cotiviti.com/display/MLSA/...)

Closing slide: "If you want to go fast go alone, if you want to go far go together" — Welcome to Data Engineering Team.
