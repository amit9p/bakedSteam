# Data & AI organization — new structure (All Hands, Oct 22, 2026)

Source: slide "Six functional areas — each with a clear, accountable home", presented by Cloud Xia at the Data & AI All Hands, 2026-10-22 (photo: `claude_output\attachments\2026-10-22_data-ai-all-hands-six-functional-areas.jpg`). Only this slide was captured; the deck had more ("Click for how the pieces fit together").

## The story on the slide

- **01 Why:** Strong foundation · Structure must catch up · One Data & AI organization.
- **02 Achieve:** Clear ownership · Platform vision & reuse · Technical excellence & talent → Execution · delivery · impact.
- **03 New structure:** six functional areas, each with a named lead, plus a cross-cutting technical-advisor group.

## The six functional areas

| # | Area | Scope (as written) | Lead |
|---|---|---|---|
| 01 | Data | Data engineering, data platforms & foundational data capabilities | **Surya** (Vadlamani) |
| 02 | NLP & Document Intelligence | Language understanding & extraction from complex clinical documents | William |
| 03 | Predictive ML | Traditional ML, predictive modeling, optimization & analytics | Jonathan |
| 04 | GenAI & Agentic Engineering | Reusable GenAI & agentic platform, plus solution engineering & delivery | Alvin |
| 05 | AI Risk & Governance | Validation, monitoring, explainability & responsible AI standards | David |
| 06 | AI Product & Enablement | Product, execution, prioritization & value realization | Pablo |

**+ Technical advisors** — cross-organizational architecture · technical strategy · alignment (sits across all six).

## What it means for ARIA / Amit (observations, not stated on the slide)

- Amit sits in **01 Data** under Surya; the ARIA data hub is "foundational data capabilities" work.
- The agentic hub / ARIA components Reva builds map to **04 GenAI & Agentic Engineering** (reusable agentic platform) — lead Alvin. Reva's own placement (04 or technical advisor) not confirmed.
- **William** = the NLP leader Reva said he would raise the NLP output gaps with; now formally lead of 02, the CIS NLP side ARIA ingests from.
- Explainability, validation and monitoring of ARIA output (coder override rates, audit trail, CTG for CMS audits) belong to **05 AI Risk & Governance** (David) — a stakeholder for the gold/CTG design.
- Prioritization and the "demo to internal customers" ask sit with **06 AI Product & Enablement** (Pablo).
- Surnames for William, Jonathan, Alvin, David, Pablo not on the slide — fill in from Teams when met.
