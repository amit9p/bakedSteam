# "Engineering Vision · AI at Cotiviti" — Cloud Xia's deck (All Hands, Oct 22, 2026)

Source: slides photographed during the Data & AI All Hands, 2026-10-22, presented by Cloud Xia (an HTML deck, `cotiviti-ai-engineering-vision-v3.html`). Photos in `claude_output\attachments\2026-10-22_*.jpg`. Slides 01–05 captured; slide 06+ ("lay the foundation") still to capture. Companion: `cotiviti/data-ai-org-structure-2026-10.md` (the six-functional-areas slide from the same event).

## Slide 01 — The problem: "Every Cotiviti business makes the same kind of call"

Tagline: different products, one shared problem. Six business lines, each a decision plus the rulebook it is judged against:

| Business line | The call | Rulebook |
|---|---|---|
| Payment Accuracy | Was this claim paid correctly? | DRG & coding guidelines |
| Coordination of Benefits | Who should be paying for this? | Coverage & liability rules |
| Coding & Billing | Is this coding and billing compliant? | Payer payment policy |
| **Risk Adjustment** (ARIA's line) | **Does the chart support this diagnosis?** | **CMS HCC model · ICD-10-CM** |
| Quality | Is there a gap in care to close? | Quality measure specs |
| Rx & Retail | Does this rule or contract term apply? | Rx rules · contracts |

**The common problem:** "Make accurate decisions, following policies & guidelines, at massive scale."

Scale and constraint stated on the slide: **28.6M charts/month processed via NLP**; **hundreds of millions of clinical documents processed**; **every decision must be defensible**.

### Why it matters for ARIA
- ARIA is the Risk Adjustment instance of the shared pattern (chart → does it support the diagnosis → HCC). The same shape — document + policy/guideline → defensible decision — is what Reva's policy-to-logic and the CCDM/CTG are meant to make reusable across the other five lines. Useful framing when explaining the data hub: it is the shared data foundation for that pattern, not an ARIA-only pipeline.
- "Every decision must be defensible" is the leadership statement behind the audit-trail / explainability requirements (CTG behind every gold determination, version keys, evidence spans) — cite it when justifying that design.
- 28.6M charts/month is the volume ceiling the NLP system already handles; the data hub's ingress design should be sized against that order of magnitude, not against the handful of sample charts in slice 1.

## Slide 02 — Breaking it down: "It breaks down into two problems"

Subtitle: *Wrong evidence means a wrong decision. A decision we can't explain, we can't defend.*

**Problem 1 — Extract the right information** from charts, notes, claims and policies, structured and unstructured. Worked example on the slide — progress note, DOS 03/14: "Pt seen for f/u of congestive heart failure. Denies chest pain. Continues furosemide 40mg daily. Echo: EF 35%, stable. Hx of tobacco use, quit 2015. Plan: continue current regimen, recheck BMP." Extracted as typed evidence: CHF · condition · affirmed; Chest pain · (symptom) · negated; Furosemide · treatment · current; EF 35% · assessment · 03/14.

**Problem 2 — Make accurate decisions & recommendations**, auditable and explainable, every time. Example output: Recommendation "CHF diagnosis supported by the chart" with four fields — Evidence: monitored, evaluated, assessed & treated (MEAT met) · Policy: cites the applicable coding guideline · Confidence: high → auto-accept, low → route to a coder · Audit trail: every step logged and reproducible. Tags: Accurate · Auditable · Explainable.

For ARIA: this is literally the gold determination row — evidence (CTG), policy citation (rule set id), confidence (CoPilot/AutoPilot routing), audit trail (version keys, replay). The example (CHF, EF 35%, furosemide, MEAT) matches the Maria CH-8841 walkthrough in the proposal.

## Slide 03 — Our armory: "What we already bring to the fight"

Subtitle: *Built up over decades, and hard for anyone else to copy.* Five assets, each with a role, a strength and a weakness on its own:

| Asset | Role | Scale / nature | Strength | On its own |
|---|---|---|---|---|
| Rule engines | Decide | Deterministic — policy encoded as executable logic, the same answer every time | Precise, repeatable, audit-ready | Slow and costly to author from policy text |
| NLP | Extract | 28.6M charts/month; 12.5M-chart training corpus | Clinical extraction at production volume | Narrow; each new task means new engineering |
| Taxonomy | Ground | 1.9M+ medical concepts · 7.6M+ relationships, curated for 20+ years | "Our source of medical truth" | Today it mostly serves NLP |
| ML models | Score & prioritize | $45.2M from post-pay models alone in 2025 | Finds patterns; ranks and routes at scale | Needs structured features; can't read charts or notes |
| GenAI / LLM | Read & reason | Agentic — LLM concept extraction, reasoning over charts, policies & contracts | Understands almost any text, no task-specific build | Non-deterministic; can't audit it alone |

Closing line: *Each one is strong, but none of them is enough by itself.*

Note the taxonomy figures (1.9M concepts / 7.6M relationships) differ from Reva's "~20M concepts / 40M relationships" from Oct 14 — different counting (curated core vs. everything) or one of them is loose; don't quote either as fact without checking with the taxonomy team.

## Slide 04 — Tied together: "Combined the right way, they unlock far more"

Subtitle: *Neural extraction, symbolic decisions, monitored and self-improving.* Breadcrumb on the next slide: Neural extraction → Grounded evidence → Symbolic decisions ↻ Self-improving.

The diagram, left to right:
- **DATA** — Unstructured (charts, notes, policies, contracts) and Structured (claims, eligibility, provider).
- **EXTRACT · NEURAL** — GenAI/LLM: reads context, abstracts and reasons; turns policy text into logic. NLP engine: primary entity extraction at production volume.
- **Evidence graph** — *clinical truth graph: typed, cited evidence for each date of service*; **Taxonomy** grounds every concept in medical truth ("grounds" arrow).
- **DECIDE · SYMBOLIC** — Rule engine: deterministic policy enforcement, versioned and reproducible. ML models: confidence, prioritization & routing to humans.
- **Auditable decision** — evidence, policy citation, reasoning and confidence.
- Side arrows: "policies & guidelines → executable rules" (LLM into the rule engine — policy-to-logic); "cleansing & features" (structured data into ML); feedback loop along the bottom: "human review & outcomes → new training & evaluation data".
- **Unlocks:** Autonomous coding · Policy-to-logic · Clinical truth graph · Rx rule discovery · Contract review · NLP + ML ensembles · Taxonomy review (last chip cut off).

For ARIA: this is Reva's architecture drawn at company level — neurosymbolic (neural extract, symbolic decide), the CTG as the evidence graph in the middle, taxonomy as grounding (the CCDM-wraps-taxonomy direction), policy-to-logic feeding the rule engine, ML for routing (CoPilot vs AutoPilot), human review feeding the golden dataset. The data hub is the DATA box plus the storage/versioning behind the evidence graph and the feedback loop — nothing on the slide names it, which is the gap the data-artifact blueprint fills.

## Slide 05 — Platform: "A platform layer speeds up innovation everywhere"

Subtitle: *Build it once, reuse it everywhere. Each new use case builds on the last.*

Use cases listed per business line (top of slide):
- Payment Accuracy: Research AI · Revenue leakage · Principal Dx · Post-pay & pre-pay models
- COB: Working-status change · Duplicate detection · COB TPL
- Coding & Billing: Appeal review · Billing anomalies · Coding accuracy
- **Risk Adjustment: Autonomous coding · Chart review · Suspecting engine** (+ one more, "…")
- Quality: Quality suspecting · Quality gap NLP
- Rx & Retail: Contract review · Rx AI rule platform
- Cross-business: Knowledge assistants (RAG) · Member & provider 360 · Ask your data (chatBI)

**Shared platform layer — "Unified AI platform": 90% of GenAI use cases standardized on a single agentic platform.** Principles: Unified infrastructure · Central governance · Build once, use N · Simplified approval.
- Core AI services (the armory): Rule engine · NLP · Taxonomy · ML & feature store · LLM & agents.
- Shared building blocks: RAG & knowledge base · Semantic layer · Policy-to-logic · Evidence & citation retrieval · Chart comprehension · Human-in-the-loop review · MLOps, evals & monitoring · Governance & audit.

For ARIA: "Autonomous coding" and "Chart review" under Risk Adjustment are ARIA (AutoPilot / CoPilot). Policy-to-logic, evidence & citation retrieval, human-in-the-loop review and governance & audit are named as shared building blocks — i.e., what Reva's components and the data hub produce are meant to be reused by the other lines, which is the argument for a managed data hub rather than ARIA-only tables. The next slide ("Click to lay the foundation") is presumably the data/platform foundation — the one most relevant to the Data area; capture it if it comes up.
