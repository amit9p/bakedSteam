# Cotiviti Medical Record Coding — the public product page (read Oct 22, 2026)

Source: https://www.cotiviti.com/solutions/risk-adjustment/medical-record-coding (public marketing page; figures are Cotiviti's own claims). Why it matters: this is the business ARIA sits inside. CIS is the application behind it; the coders it describes are the coders who will see ARIA's recommendations.

## What the page says

- Purpose: "Accurately capture and document risk-adjustable conditions." Part of the Risk Adjustment suite, sold to health plans (national and regional, Medicare Advantage).
- How: machine learning and NLP to make coding efficient, plus expert leadership and multi-layered QA. "100% of coded charts and NLP findings are reviewed by our coders." All coders are AAPC- and AHIMA-certified employees. QA: real-time feedback, daily audits, ongoing training, continuous performance monitoring. Guidelines and quality frameworks tailored per client. The NLP is described as "transparent and explainable".
- Add-ons: Second Level Review (an extra review of already-coded charts); Retrospective Review (a platform for plans that run coding in-house).
- Claimed numbers: >97% average coding accuracy across lines of business; >10M charts coded annually; >$2B appropriate incremental risk-adjustment revenue delivered to MA clients annually; 100% project completion; >25 years serving health plans.

## What it means for ARIA

- Scale: tens of millions of charts a year. The hub's per-chart jobs, storage and retention assumptions should be sized for that, not for a pilot's hundreds.
- Today's quality bar is >97% accuracy with every NLP finding reviewed by a certified coder. ARIA's evaluation targets (precision and recall ≥ 90% provisional, false-accept ≤ 2%) are the pilot's first-pass bars, below what the product already claims; the pilot's value is coder time per chart and audit defensibility, not raw accuracy. Useful framing if leadership asks "why is 90% good enough".
- "100% reviewed by coders" is exactly CoPilot mode. AutoPilot, where a code goes without a coder, changes a public promise; that is why the evaluation page gates it on shadow-mode evidence.
- "Transparent and explainable" NLP is already a sales claim; ARIA's explain API and decision package are what make it checkable per code.
- Second Level Review is a natural second consumer of the hub's gold and evidence tables: a reviewer of an already-coded chart needs the same walk-back.
- Vocabulary for slide 1: "risk-adjustable conditions", "lines of business", "appropriate incremental revenue".
