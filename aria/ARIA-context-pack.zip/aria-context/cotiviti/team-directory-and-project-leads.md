# Cotiviti AI org — people, distribution lists, and project → DE lead map

Living directory. Add to it as names show up. Source for the handoff table: Rutvi Mistry's farewell/handoff email, Wed Sep 23, 2026 2:55 PM (photo shared by Amit in chat; copy at claude_output\attachments\2026-09-23_rutvi-handoff-email.jpg).

## Rutvi's move (Sep 2026)

- Rutvi Mistry's last day on the data engineering team: **Friday, Sep 25, 2026**. She stays at Cotiviti, moving to the **RCA AI Product group** (hands-on principal product manager role). Happy to be contacted for help.
- She had supported RCA, CCV, PPM and Early Intervention AI/ML workloads for ~7 years.
- Rule from her email: for questions on any of the projects below, start with the data engineer project lead.

## Project → DE lead (handoff list, Sep 23, 2026)

| Project | DE lead |
|---|---|
| EI Adj Avoidance | Sriram Pureti |
| EI DM / Prepay RX | Sriram Pureti |
| EI COB | Sriram Pureti |
| RCA – COB Newborn | Vivek Veldi |
| RCA – Spotcheck (Main) | Vivek Veldi |
| RCA – Change in Working Status (CWS) | Sriram Pureti |
| RCA – Summary Plan Document (SPD) | Vivek Veldi |
| RCA – Post Pay Contract Compliance (PPCC) | Vivek Veldi |
| RCA – COB Subrogation / Accent TPL and Reporting (Main) | Vivek Veldi |
| RCA-14 GDF Mapping | Neelima Kappa |
| PPM-OI | Sriram Pureti |
| RCA-RX Pharmacy | Sriram Pureti |
| Synthetic Data Platform (SDM, SDP) | Vivek Veldi |
| RCA – Spotcheck Reporting Pipeline | Vivek Veldi |
| RCA – COB Subrogation Reporting Pipeline | Vivek Veldi |
| RCA – COB Newborn Reporting (happens through KPI) | Vivek Veldi |
| RCA – ACE Reports | Vivek Veldi |
| PPM Smart Search | Nicholas (surname not shown) |
| LLMOps – Observability | Pushkar (surname not shown) |

("Sriram P" in the first three rows is the same Sriram Pureti named further down.) EI = Early Intervention; RCA = Retrospective Claims Analysis; PPM = Payment Policy Management; OI = Opportunity Intelligence; COB = coordination of benefits; TPL = third-party liability.

## Distribution lists seen

- AI Solutions Team · AI Platform · OAI_DataOps (the email's To: line, alongside Surya)

## People (AI org and neighbours)

| Name | Role / what we know | Source |
|---|---|---|
| Surya Vadlamani | Amit's manager; leads data engineering group under the AI org | — |
| Cloud Xia | Head of the AI group; Surya's boss; Amit's skip-level | — |
| Reva (Revadigar Sharanbasappa) | Architect; owns the agentic hub vision and Project ARIA | — |
| Nikhil Shivalkar | Director, Data Ingestion & Architecture; building the AWS lakehouse and new ingestion platform | meet-and-greet 9/16 |
| Yeshwanth "Yesh" Jagini | Manager Data Eng AI (AI Initiatives); informal Databricks platform team; access/platform questions | meet-and-greet 9/16 |
| Rutvi Mistry | Manager Data Eng AI → RCA AI Product group from Sep 28, 2026 | email 9/23 |
| Sriram Pureti | DE lead — EI projects, RCA CWS, PPM-OI, RCA-RX Pharmacy | email 9/23 |
| Vivek Veldi | DE lead — most RCA projects, Synthetic Data Platform, reporting pipelines | email 9/23 |
| Neelima Kappa | DE lead — RCA-14 GDF Mapping | email 9/23 |
| Nicholas | DE lead — PPM Smart Search | email 9/23 |
| Pushkar | DE lead — LLMOps Observability | email 9/23 |
| Matthew Grant | Developer named in the Databricks CI/CD Confluence page (OAIP dbx-ovaledgeprofiler repo); cc'd on Rutvi's email | Confluence, email 9/23 |
| Matthew Herbein, Gautam Khera, Britney Henline, Sanket Zanwar, Deeksha Joshi | cc'd on Rutvi's email (roles unknown yet) | email 9/23 |
| Faviana Noronha | MLOps team; wrote the Bitbucket↔Databricks and Model Inventory Governance POC pages | Confluence |
| Kaige Feng | Owner of an example Databricks job in the Confluence retry page | Confluence |
| Jordan Bruckner | Presented the benefits orientation (HR/benefits) | orientation 9/17 |
