# How Coding Moves Money — the business behind ARIA

Explainer written Oct 15, 2026 for Amit (new to healthcare). Visual version with three diagrams: artifact "How Coding Moves Money" (https://claude.ai/artifact/AnpznYZ7EnJ9xQCmSscY8D); disk copy `claude_output\aria\how-coding-moves-money.html`. One worked example (Mrs. Rao, 72) runs through all of it.

## 1. The loop

Medicare Advantage: CMS (the government) pays a private health plan a fixed amount per member per month. The amount is scaled by how sick the member is (the risk score). CMS learns how sick a member is from the diagnosis codes the plan submits, and the codes come from the doctor's chart.

Loop: plan covers the member → member visits the doctor (face to face) → doctor writes the chart → coder reads the chart and assigns diagnosis codes (ICD-10 → HCC → risk score) → plan submits the codes to CMS → CMS pays base × risk score. CMS can audit (RADV) any code back to the chart. The coder and ARIA work on the "codes" step.

## 2. One chart, line by line

A code is a standard label for a diagnosis (ICD-10-CM). Some codes map to an HCC in the CMS model (V28) and raise the risk score; most do not. A code counts only if a face-to-face visit note this year supports it with MEAT (monitored, evaluated, assessed or treated).

| The doctor wrote | ICD-10 | HCC (V28) | Counts? | Effect |
|---|---|---|---|---|
| "Type 2 diabetes with diabetic nephropathy. A1c 8.1. Continue metformin." | E11.22 | HCC 37 | Yes — monitored and treated | raises risk score |
| "CKD stage 3, eGFR 48. Recheck in 3 months." | N18.30 | HCC 329 | Yes — evaluated | raises risk score |
| "BP 150/92, hypertension. Increase lisinopril." | I10 | none | Valid code, no weight | $0 |
| "History of breast cancer, 2015. No recurrence." | Z85.3 | none | History only, not active | $0; coding active cancer here is an audit finding |
| "Possible heart failure. Echo ordered." | — | (I50.9 → HCC 226) | "Possible" never counts | $0 until confirmed |

Illustrative money: risk score 1.00 (demographics) + 0.17 (HCC 37) + 0.13 (HCC 329) = 1.30. Payment $1,000 → $1,300 per month, +$3,600 a year for one member. Real V28 weights vary by segment; a plan has tens or hundreds of thousands of members.

## 3. Where the coder and ARIA sit

Plans pay Cotiviti to get the codes right in both directions:
- ADD: supported conditions nobody coded (Mrs. Rao's CKD) → the plan is paid what it is owed. Revenue; the main reason plans buy the service.
- DELETE: codes the chart does not support (active cancer coded from "history of") → removed before CMS finds them. In a RADV audit CMS reverses the payment and can extrapolate the error across the plan's sample.

Flow: plan sends charts → CIS NLP highlights candidate conditions and text spans → ARIA builds the truth graph, applies the coding rules, returns a verdict per code (codeable / coder queue / drop) with evidence → the coder accepts or overrides → back to the plan as codes to add and codes to delete, each with evidence. Coder decisions feed back into the rules.

ARIA does not replace the coder. It turns "here is a highlighted sentence" into "this code is supported by this evidence under this rule", so the coder reads less, decides consistently, and every decision is traceable.

## 4. Where Amit's work sits

All of the above produces data that has to be kept properly: the chart as the system understood it (CCDM silver), the truth graph, the recommendations (gold), the policy documents and every version of the rules compiled from them, and the coder's feedback. An audit question years later ("why did you recommend E11.22 for this chart in 2026?") is answered by replaying exactly that data at exactly those versions. That store, with versioning, access control and APIs, is the data hub.

## Glossary

- Medicare Advantage — private plans CMS pays to cover Medicare members, per member per month.
- CMS — Centers for Medicare & Medicaid Services; sets the rules, pays the plans, audits them.
- ICD-10-CM — the diagnosis code set (letter, two digits, up to four more after a dot).
- HCC — Hierarchical Condition Category; groups of ICD-10 codes that carry weight in the CMS risk model (V28). Most codes map to none.
- Risk score (RAF) — demographic base plus HCC weights; multiplies the base payment.
- MEAT — Monitored, Evaluated, Assessed, Treated; at least one must be in the note for a condition to count.
- RADV — Risk Adjustment Data Validation; CMS's audit of charts behind submitted codes.
- Coder — certified medical coder who reads charts and assigns or validates codes.
- CIS — Cotiviti's chart intake and NLP system; will feed ARIA via S3.
- CCDM — Common Clinical Data Model; the one vocabulary every ARIA component speaks.
- Truth graph (CTG) — what the chart actually says as nodes and edges: condition, evidence span, assertion, MEAT link.
