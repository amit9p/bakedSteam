# ARIA box-by-box walkthrough (Oct 24, 2026)

Markdown copy for the knowledge base. Written for someone new to ARIA; walks slide 5 of the design-review deck (architecture v6) with example data at every handoff. Example chart CH-8841 is synthetic; HCC numbers and rule ids are illustrative.

## The whole picture

Four lanes: 1 CIS (external; boxes 1 and 8), 2 data hub (Amit; bronze 2, silver 3, CTG store 5, gold + publish 7, Explain API), 3 AI components (Reva; Abstractor 4, Auditor 6, P2L, PRM), 4 rules/reference/feedback (golden dataset, reference data, CCDM registry, policy tables copy, feedback + eval 9). Numbers 1–9 follow one chart; letters A–H follow one guideline. Two doors: Lookup API, Explain API. Key note 3 of Reva's P2L guide: "the data hub (lakehouse) is the logical home of all data." Reva's components compute; the hub keeps.

## Jobs the data hub runs (13)

| # | Job | Trigger | Reads | Writes | Status |
|---|---|---|---|---|---|
| J1 | Ingress (bronze) | S3 event from CIS | the ZIP | `bronze.chart_events` + raw ZIP; re-send = new row | built |
| J2 | Silver (CCDM) | after J1 | bronze; CCDM registry; codes via Lookup | six `ccdm.*` tables; `ccdm.quarantine` | built (2 tables); 6 next |
| J3 | Quality report | daily | quarantine | report per feed version + reason to CIS/NLP team | built |
| J4 | Export for components | after J2 | six silver tables | one CCDM JSON per chart in handoff folder (30 d) | next |
| J5 | CTG load | Abstractor output lands | Abstractor JSON | `ctg.node`, `ctg.edge`, graph_version per run | next |
| J6 | Gold load | Auditor output lands | Auditor JSON | `gold.determinations` | next |
| J7 | Publish | after J6 | gold | results JSON per chart to S3 `out/` + event; always one | next |
| J8 | Feedback load | CIS sends decisions | file or API | `feedback.coder_actions` linked to gold row | next |
| J9 | Eval | per release | gold + feedback + golden set | metrics per HCC/code/DOS | next |
| J10 | Replay / regression | every release + rule promotion | bronze, pinned versions | both runs + diff of flipped dispositions | next |
| J11 | Reference loads | yearly | CMS codes, crosswalk per model, RAF, CCL, taxonomy | `ref.*`, old versions kept | constants now |
| J12 | Policy bridge (Stream H) | nightly; manual first | PRM Postgres + S3 | `policy.*` copy keyed by digest + fingerprint | after PRM schema frozen |
| J13 | Decision package export | on request | gold + CTG + evidence + policy copy | frozen package per (chart, code) | next |

J1–J7 are one chain per chart; boxes 4 and 6 sit between J4→J5 and J5→J6 and, for November, read/write files in the handoff folder.

## Box 1 — what CIS drops on S3

One ZIP per chart: `<chart_id>.pdf` + `<chart_id>.json` (NLP output, encounter-nested). CIS QA bucket (name and account in `aria/stack-options.md`), prefix TBD, event to SQS/SNS. The JSON carries chart (ids, mode, facility_type, payer_id, hcc_model_version, attending_npi, nlp/feed version), encounters with DOS, notes (signer, credential, cosigner, authentication, service_ts, signature_ts, addendum), mentions (text, page, start/end, section, assertion, severity, confidence, code_candidates[]), relationships (TREATS/EVALUATES/MONITORS/INDICATES/COMPLICATES), meat (M/E/A/T spans). Full example in `aria/aria-cis-contract-v0.2.md`. Real exports today lack signer/credential (largest gap), facility, payer, model version; confidence −1..412; three flags not six assertion states; one winning code; uncoded meds dropped.

## Box 2 — ingress + bronze (J1)

ZIP copied untouched; one row per receipt: chart_id, client_id, source_msg_id, event_ts, received_at, feed_version, nlp_version, mode, zip_path, payload. Append-only, PHI, pipeline SP only, kept years. Purpose: replay without asking CIS to resend.

## Box 3 — silver (J2)

Six CCDM tables: `chart` (ids, mode, facility, payer, hcc_model_version, versions), `note` (signer, credential, npi, cosigner, authentication, service/signature ts, addendum, author_type), `mention` (text, page, offsets, section, six-state assertion, severity, event_date, confidence), `code_candidate` (all candidates with confidence, rank), `relationship`, `meat_evidence`. Latest copy per chart; ccdm_version + nlp_version on every row. No decisions, no HCC in silver. Quarantine with reason_code + owner: CONF_OUT_OF_RANGE, CODE_NOT_SPECIFIC, NO_OFFSETS, ASSERTION_UNKNOWN, NOTE_NO_SIGNER, ZIP_UNREADABLE (whole chart → "not processed"). J3 reports daily per feed version.

## The handoff — CCDM JSON export (J4)

The Abstractor is Reva's code; it reads a file, not our tables. J4 writes one CCDM JSON per chart to `/Volumes/aria/handoff/ccdm/<chart_id>/<run_id>.json` (or an S3 prefix): same shape as the CIS JSON after cleaning, registry field names, quarantined rows removed, a `versions` block. Not a record; 30-day retention. Open point: match the Abstractor's expected field names, or Reva adds an input adapter.

## Box 4 — Clinical Abstractor

Turns NLP hits into facts you would stake your name on. Per mention: real? (assertion), current? (DOS), who said it and does it count? (signer, credential, signed, timing → provenance), managed this visit? (MEAT), how do facts connect? (relationships), which specific code? (candidates + severity). Keeps historical items marked historical. Does not decide codeable, does not apply rules, does not know HCC. Output: CTG JSON to `/Volumes/aria/handoff/ctg/<chart_id>/<run_id>.json`.

## Box 5 — CTG store (J5)

`ctg.node` (condition, evidence span, provider, encounter, meat item, medication/lab) and `ctg.edge` (SUPPORTED_BY, DOCUMENTED_BY, OCCURRED_IN, HAS_MEAT, COMPLICATES, TREATS, EVALUATES). One graph per chart per run; append-only; chart_id, graph_version, model_version, ccdm_version on every row. Why a graph: each Auditor gate is one hop; Explain API walks code → condition → evidence → signer; evaluation wants one causal chain per code.

## Box 6 — Symbolic Auditor

Deterministic rules engine; six fail-fast gates per candidate code. Inputs: CTG, candidates, payer/LOB/DOS, active ruleset from PRM (step H), crosswalk + CCL via Lookup.

| Gate | Check | On fail |
|---|---|---|
| L1 | valid ICD-10 + maps to HCC under the chart's model version | drop |
| L2 | condition active | coder queue |
| L3 | DOS in coding year | coder queue |
| L4 | provenance ≥ 0.75 | coder queue |
| L5 | MEAT evidence present | coder queue |
| L6 | payer policy rule (CRL) satisfied | coder queue |

L1 is where the HCC first appears in the data (one crosswalk lookup per code). On CH-8841: E11.22 and N18.32 CODEABLE; I50.9 coder queue, first failed gate L2 (historical). Output: determinations JSON per chart with disposition, first failed gate + reason, confidence per HCC + sub-factors, rule id + snapshot digest + fingerprint, claim verdicts, evidence refs, "what would clear it". Routing lane: shadow / HITL / autonomous; pilot = all HITL.

## Box 7 — gold + publish (J6, J7)

`gold.determinations`: one row per (chart, encounter, code, DOS, run): code, hcc, hcc_model_version, disposition, routing_lane, first_failed_gate, reason, what_would_clear_it, confidence + sub-factors, rule_id, snapshot_digest, fingerprint, evidence_refs, claim_verdicts, all version keys, coder_action + reason_code (filled by J8). Write-time checks: citations exist verbatim in silver; every non-accept names its gate. Append-only, never hand-edited. Publish: one results JSON per chart to `s3://<bucket>/<prefix>/out/<client>/<yyyy>/<mm>/<dd>/<chart_id>.json` + event; failures as `not_processed` + reason; 90 days.

## Box 8 + Explain API

CoPilot: coder accepts/rejects/overrides with a reason code in the CIS app; AutoPilot later. Explain API: `GET /explain?chart_id&code&run_id` → one causal chain: evidence + signer → link → MEAT → gates passed → rule text + guideline citation; for a queued code, ends at the failed gate with what would clear it. Only human-facing reader of PHI tables.

## Box 9 — feedback + eval (J8, J9, J10)

Feedback columns: coder_action, override_code, reason_code, time_on_chart_sec, shadow_disposition, linked to the gold row. Eval per HCC (DM/CKD/CHF), code and DOS: precision, recall, false-accept (≤2%; 0% on the nine exceptionally acute without MEAT), coder time (21 min from 30), override rate (≤12% over two cycles), reproducibility (100% on the 256-chart golden set). Confirmed errors become permanent golden test cases; replay must flip zero previously-correct charts.

## The policy lane — PRM, P2L, policy tables

The PDF never touches the hub. PRM (Reva, AF-1: Postgres + S3 + authenticated API) is the store of record; P2L is a job runner inside PRM; CIS's Rule Review App calls PRM's API; the Auditor fetches the active ruleset and compiled rules from PRM's API at run time. The hub's `policy.*` tables are a nightly copy (J12) for the Explain API, eval and audit walk-back; the Auditor does not read them.

| Step | What | Lands in |
|---|---|---|
| A Register | engineer uploads guideline PDF via PRM API; content_hash + policy_id; draft job queued | S3 policy-sources; Postgres |
| B Draft | P2L job: Textract → DOM → chunks → policy graph → CRL rule per chunk (CCDM registry fields); hours | S3 staging/ |
| C Store | PRM compiles (rule-transpiler), fingerprints each rule, immutable snapshot by digest | S3 snapshots/; Postgres |
| D Quality checks | automatic checks; failures to engineering, rest to coders with clinical-judgment questions | Postgres |
| E Review | coders in CIS Rule Review App approve/reject/revise via PRM API; review bound to fingerprint | Postgres (reviewer_token) |
| F Revise | new snapshot; only changed items return; until converged | S3 + Postgres |
| G Promote | second sign-off; active-ruleset pointer (tenant, payer, LOB, DOS period) → digest; API-enforced | Postgres (control data) |
| H Use | Auditor asks "active ruleset for ARIA, AETNA, MA, DOS?" → digest → compiled rules; gold records digest + fingerprint | via API; gold |
| nightly | J12 copies PRM records to `policy.*`; registers PRM buckets in catalog; later LAKE-API-1 (hub-owned, undated) | hub |

Why not store rules in the hub: a coder's save needs an instant consistent answer and the lakehouse write API does not exist; tactical (Postgres truth, nightly copy) → bridge → strategic (lake truth). Hub's job in every phase: schema, catalog, lineage, retention for policy datasets from day one.

## The two doors and reference data

Lookup API (silver, Abstractor, Auditor, P2L): codes, crosswalk per model version, CCL per payer/DOS period, RAF weights, taxonomy, CCDM registry. Explain API (CIS at coder time): gold, CTG, evidence, policy copy. v6 picture draws the Lookup bar only under silver and the Abstractor; it should extend under the Auditor and P2L (L1 crosswalk, L6 CCL). Reference datasets: ICD-10/CPT/PCS code sets, ICD-10→HCC crosswalk per model version (exists at Cotiviti), RAF weights (not held yet), CCL, clinical taxonomy copy, our additions, CCDM registry, golden dataset (256 charts).

## Still undecided

Abstractor input field names (J4 must match) · who resolves the HCC (Auditor via Lookup, or J4 pre-resolves) · file handoff acceptable for November · CIS pre-runs NLP vs Hub calls the ensemble · sample ZIP from CIS with present/can add/not available per field · HCC model version per chart (CIS adds, or hub derives) · coder decisions format + reason codes · golden dataset 200 vs 256 and who holds it · PRM schema freeze and what LAKE-API-1 is on Databricks · platform (Databricks on AWS vs AWS-native).

## Sources

`aria/aria-architecture-v6.md`; deck slide 5; `aria/aria-cis-contract-v0.2.md`; `aria/aria-data-blueprint.md`; `confluence/aria-architecture-reva-loop-page.md`; `confluence/p2l-rule-review-design-and-build-guide-reva.md`; `confluence/aria-evaluation-methodology.md`; `confluence/nlp-extraction-requirements-reva.md`; `aria/aria-pipeline-starter.md`.
