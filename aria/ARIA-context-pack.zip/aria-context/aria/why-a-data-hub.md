# Why a data hub between CIS and the Agentic Hub (one page, Oct 21, 2026)

Written for the question Binod asked on Oct 20: "I thought it was direct communication between two services. What are we trying to achieve by putting the data in Databricks or any platform?" The answer is in his language first, then in Reva's and leadership's words, then what it costs.

## Binod's picture and ours

Binod's picture: CIS sends a chart to Reva's service, gets a recommendation back, shows it to the coder. Two services, a queue in between, nothing kept.

Our picture is the same handshake with one difference: everything that passes through is kept, versioned and reportable. CIS still drops a file and gets a file back. The hub is not a detour for the chart; it is where the record of what happened lives.

## Five things only a kept record gives

1. **Replay.** CIS's feed will change (Reva found nine gaps in it; the NLP team will fix them over months). With the original ZIP kept, we rerun old charts on the new feed or the new rules without asking CIS to resend. Without it, every improvement means a resend.
2. **Reproducibility.** Reva's evaluation page makes "same chart + same rules → same disposition" a 100% requirement and "a rule change flips zero previously-correct charts" a gate on every promotion. Both need the inputs and both outputs stored with their versions. A queue cannot answer "what did we decide last March, and why".
3. **Audit defence.** A RADV audit comes years after the code was submitted. Reva's Commitment 6: every decision artifact must survive independently of ARIA, locked and timestamped, readable by a third party with no access to the codebase. That is a data store with retention, not a service response.
4. **The numbers leadership will judge the pilot by.** Precision, recall, false-accept rate, override rate, time per chart, Kappa in shadow mode, all at diagnosis-code and date-of-service grain within each HCC. Every one of those is a join between what ARIA said and what the coder did, across thousands of charts and several versions. That join lives in the hub.
5. **A quality report back to CIS.** The hub is the one place that sees every chart in the shape the components need. Per feed version it can say which of the nine gaps are closed ("feed v3: 0% of mentions have offsets, CPT absent, 40% of codes at category level"). Today that knowledge is a Loop page written by hand.

## In Reva's and leadership's words

Reva's P2L build guide, key note 3: "The data hub (lakehouse) is the logical home of all data. Schemas, catalog, governance, lineage and retention for every dataset are defined by the lakehouse standards from day one." His architecture page has the hub nowhere because it is the component view; his data plan has it everywhere.

The Agentic Hub PRFAQ, layer 5 of the stack: "Data Mesh / Clinical Lake, MLOps & Governance: the essential data, security and governance rails that allow the Hub to scale safely within a healthcare environment." And "Shadow and Prove": the Hub runs in parallel with the incumbent NLP and is compared. Comparing means keeping both.

## What the hub does not do

It does not improve the chart or the NLP output; it keeps every version, rejects nothing silently, and reports what is missing. It does not own the policy tool; that is Reva's PRM with CIS's screen in front, and the hub keeps a copy. It does not sit on the demo's critical path: for November the file handoff is enough, and the hub runs in parallel.

## What it costs

Storage is small and write-once. Compute is a few jobs per chart. The real cost is the one Reva names in his explainability page: ablation re-runs and blind re-reviews, which are not hub costs. The hub's own cost is the platform decision, which is the design review's question.
