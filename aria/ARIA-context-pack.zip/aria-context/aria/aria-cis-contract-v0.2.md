# ARIA ↔ CIS data contract — draft v0.2 (Oct 21, 2026; for CIS to correct)

Status: still Amit's draft, not agreed. v0.1 (Oct 19) guessed the shape. v0.2 adds what Binod said on Oct 20 (one ZIP per chart, encounter-nested JSON; bucket, account and roles), Reva's two Loop pages on what the NLP feed must contain (`confluence/nlp-extraction-requirements-reva.md`), and the mode from Reva's architecture page. Purpose unchanged: give CIS something concrete to say yes or no to, field by field. The first real correction comes from one sample ZIP.

## 1. Ingress — what CIS drops, what ARIA picks up

**Mechanism (Binod, Oct 20).** A CIS service taps the existing NLP output, bundles it, and copies it to an S3 bucket with an event notification. Known so far: AWS QA account 981971132015; bucket `cis-nxt-gen-data-qa`; prefix for ARIA to be named by Binod; event to SQS or SNS, CIS's choice; SFTP (Transfer Family `cis-nxt-gen-sftp-qa`) also exists but S3 + event is the path.

**Unit: one ZIP per chart.** Inside: the chart PDF, and one JSON. Assumed key: `s3://cis-nxt-gen-data-qa/<aria-prefix>/<client_id>/<yyyy>/<mm>/<dd>/<chart_id>.zip`. A re-send of the same `chart_id` is allowed; ARIA keeps every version and processes the latest by `event_ts`. ARIA keeps the ZIP as received (bronze) so any chart can be replayed when the feed improves.

**Assumed JSON shape (encounter-nested, as Binod described it).** Field names are ours; CIS's names win.

```json
{
  "chart": {
    "chart_id": "CH-8841", "client_id": "CLIENT-A", "member_id": "M-0042",
    "mode": "COPILOT",
    "chart_pdf": "CH-8841.pdf", "source_system": "cis", "document_id": "DOC-77",
    "page_count": 16, "document_format": "scanned",
    "facility_type": "outpatient", "facility_id": "FAC-9", "payer_id": "AETNA",
    "hcc_model_version": "V28",
    "attending_npi": "1234567890",
    "nlp_version": "nlp_v3", "feed_version": "aria_feed_1",
    "source_msg_id": "k-7f3a9c1e", "event_ts": "2026-10-21T15:02:11Z"
  },
  "encounters": [
    {
      "encounter_id": "ENC-1", "dos_start": "2026-03-14", "dos_end": "2026-03-14",
      "notes": [
        {
          "note_id": "N-1", "note_type": "physician_progress_note",
          "signer": {"id": "P-12", "credential": "MD", "npi": "1234567890"},
          "cosigner": null, "authentication": "signed",
          "service_ts": "2026-03-14T10:00:00Z", "signature_ts": "2026-03-14T18:30:00Z",
          "addendum": null, "amendment": null,
          "author_type": "physician", "specialty": "internal_medicine",
          "pages": [3, 4]
        }
      ],
      "mentions": [
        {
          "mention_id": "M-7", "note_id": "N-1", "entity_type": "diagnosis",
          "text": "Type 2 diabetes with kidney complications",
          "page": 3, "start": 412, "end": 454, "section": "ASSESSMENT_PLAN",
          "assertion": "active", "severity": null,
          "event_date": null, "confidence": 0.94,
          "code_candidates": [
            {"system": "ICD-10-CM", "code": "E11.22", "confidence": 0.94},
            {"system": "ICD-10-CM", "code": "E11.9", "confidence": 0.41}
          ]
        }
      ],
      "relationships": [
        {"type": "TREATS", "from": "M-9", "to": "M-7", "confidence": 0.8,
         "text": "continue lisinopril for hypertension", "page": 4, "start": 120, "end": 156,
         "note_id": "N-1", "section": "ASSESSMENT_PLAN"}
      ],
      "meat": [
        {"mention_id": "M-7", "category": "A",
         "text": "A1c 8.2, uncontrolled; continue metformin", "page": 4, "start": 210, "end": 252,
         "note_id": "N-1", "section": "ASSESSMENT_PLAN", "dos": "2026-03-14", "confidence": 0.7}
      ]
    }
  ]
}
```

## 2. Field list — must-have vs nice-to-have (from Reva's requirements)

Orange in Reva's page = must-have (M); purple = nice-to-have (N). "Today?" is what Reva found in real exports (his nine gaps), to be confirmed on the sample.

### Chart level

| Field | M/N | Why ARIA needs it | Today? |
|---|---|---|---|
| chart_id, client_id, member_id | M | keys; re-send detection; the member is who the risk score is for | present |
| mode (COPILOT / AUTOPILOT) | M | which output CIS expects back (ranked candidates vs filled codes) | new; CIS to add, default COPILOT |
| chart PDF (in the ZIP) + document_id, source_system | M / N | explain API and audits need the page; ids for traceability | PDF yes |
| page_count, document_format (native / scanned) | N | OCR confidence context | ? |
| facility_type (inpatient / outpatient), facility_id | M | decides CPT vs ICD-10-PCS; gate input | absent in every file Reva checked |
| payer_id | M | which ruleset (payer, LOB) the auditor fetches | absent |
| hcc_model_version for the DOS | M | code → HCC mapping; which CMS rules apply | absent |
| attending_npi | M | provenance gate (L4) | only as the words "Provider NPI:" in a header |
| nlp_version, feed_version | M | stamped on every silver row; the quality report is per feed version | ? |
| source_msg_id, event_ts | M | ordering, de-duplication, audit | — |

### Encounter level

| Field | M/N | Why | Today? |
|---|---|---|---|
| encounter_id, dos_start / dos_end | M | every mention must tie to its encounter and DOS (gate L3; metrics are per DOS) | one DOS exists; per-mention tie absent |

### Note level (every note an entity or MEAT evidence came from)

| Field | M/N | Why | Today? |
|---|---|---|---|
| note_id, note_type (progress, nursing, radiology, lab, discharge, operative, other) | M | source-type rules (radiology/lab not acceptable sources) | section-level only |
| signer id, credential (MD, DO, NP, PA, RN…), npi | M | eligibility gate before any clinical content | absent |
| cosigner (present, id, credential) | M | resident notes need an attending co-signature | absent |
| signature_ts separate from service_ts | M | late-entry flag | absent |
| addendum / amendment (exists, when, by whom, what changed) | M | eligibility and audit | absent |
| authentication (signed / unsigned / modified) | N | unsigned notes not eligible | absent |
| author_type, specialty | M | provenance and acceptable-provider rules | absent |

### Mention level (every clinical finding, diagnosis, condition, medication, lab result, procedure — not only those with a code)

| Field | M/N | Why | Today? |
|---|---|---|---|
| mention_id, note_id, entity_type | M | keys; uncoded medications/labs must still arrive (MEAT Treatment evidence) | uncoded entities dropped |
| text, page, start, end (character offsets in the document) | M | the evidence span; "show me the exact sentence" | section/document level only |
| section (A/P, HPI, PMH, Medications, Labs, Radiology Impression…) | M | source rules; explain API | partly |
| assertion: active / historical / resolved / family_history / negated / uncertain | M | gate L2; six states, not three flags | three true/false flags; family history unreliable |
| severity / stage with its span (CKD stage, diabetes complication type, HF ejection fraction class) | M where applicable | decides the specific code and payment category for the pilot conditions | free text only |
| event_date (onset / event) | N (new) | "acute within N days" rules | absent |
| confidence (0–1) | M | kept as source confidence; a value outside 0–1 is quarantined | −1 to 412 observed; a raw match count |
| code_candidates[]: system (ICD-10-CM / CPT / ICD-10-PCS), code at full specificity, confidence, all candidates not just the winner | M | the auditor and the coder need the runner-up and why; CMS pays only the specific code | category-level codes; CPT never present; one winner only |

### Relationships (where detected)

| Field | M/N | Why | Today? |
|---|---|---|---|
| type: TREATS, EVALUATES, MONITORS, INDICATES, COMPLICATES; from/to mention ids; confidence; text span with offsets; note_id, section | M | rules like "a causal link may be assumed"; MEAT evidence | "not seen in any exports" |

### MEAT evidence (where the system tracks it)

| Field | M/N | Why | Today? |
|---|---|---|---|
| mention_id, category (M/E/A/T), text span with offsets, note_id, section, dos, confidence | M | gate L5; the MEAT classifier's input | ? |

### Provenance per mention and per MEAT sentence

Must: page, start/end offsets, section label, note type, author type and specialty. Nice: OCR confidence for the page; native digital vs scanned.

## 3. What ARIA does with it

Bronze keeps the ZIP as received, every version. Silver loads six tables (chart, note, mention, code_candidate, relationship, meat_evidence) in the CCDM. Rules that send a row to quarantine, each with a reason code and an owner: confidence outside 0–1; a code at category level where a specific code exists; a mention without page and offsets; a "medication" whose term is a verb; an assertion value outside the six; a note without a signer where the note type needs one; an unreadable ZIP (whole chart). A quarantined mention does not stop the chart; a whole-chart failure returns "not processed, reason X" in the results file. A daily quality report by feed version and reason goes to CIS and the NLP team; this is how Reva's nine gaps become numbers and get closed.

## 4. Egress — what ARIA gives back

One JSON per chart received, always, at `s3://<bucket>/<aria-prefix>/out/<client_id>/<yyyy>/<mm>/<dd>/<chart_id>.json`, with an S3 event. Per code: the disposition (codeable / flag / coder queue / drop), the first failed gate and what would clear it, confidence with its sub-factors, the evidence spans (page, offsets, text), the rule id + snapshot digest, model and schema versions, a reference to the chart. In AutoPilot mode (later): filled codes with the audit trail. Whole-chart failures: "not processed" with the reason. At coder time: the Explain API, "why this code?". Coder decisions come back to ARIA with a structured reason code (format to agree: a decisions file on S3, or an API call).

## 5. What ARIA needs from CIS, in order

1. One sample ZIP for two or three charts (synthetic or de-identified), by Teams. This draft gets corrected from it.
2. The ARIA prefix in `cis-nxt-gen-data-qa` and the event choice (SQS or SNS), so cross-account read can be set up from our platform.
3. For every must-have above, one of: present / can add / not available. Especially the note- and chart-level metadata, assertion states, CPT, and all code candidates.
4. How the coder app wants the results (file + event, or API) and how coder decisions come back.

## 6. Timeline on ARIA's side

Bronze and silver on the real ZIP about one week after items 1 and 2; the quality report in the same week. The rest of the pipeline keeps running on synthetic data in this shape meanwhile.
