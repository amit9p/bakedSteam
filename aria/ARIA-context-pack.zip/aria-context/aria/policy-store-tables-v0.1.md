# Policy store — the five tables, v0.1 (proposal for Reva to confirm)

Written Oct 19, 2026. These tables are the inside of the "Policy Store" box in the bottom band of the architecture (rules, reference data, feedback). They live in the same catalog as bronze and silver. Status: Amit's proposal; the rule columns (table 4) depend on the format Reva's policy-to-logic tool produces and need his confirmation.

## Where the PDFs live

A policy document is a PDF (CMS's ICD-10-CM Official Guidelines, CMS risk-adjustment guidance, or a client's own coding policy). The file stays a file; the table holds the record about it.

- Files are kept in a Unity Catalog Volume, next to the chart landing folder: `/Volumes/<catalog>/<schema>/aria/policy/documents/<policy_doc_id>/<filename>.pdf`
- New files arrive in `/Volumes/<catalog>/<schema>/aria/policy/landing/` together with a small sidecar JSON of the same name that carries the metadata a file name can't (source, client, year, version, effective dates).
- Today (dev): Amit's Volume `amit_prasad.personal`, path `/Volumes/ai_engineering_dev_catalog_1688890232235261/amit_prasad/personal/aria/policy/`. Sources of the first PDFs: Reva's POC documents; the CMS guidelines are also public downloads.

## The five tables

### 1. `policy_document` — one row per document version

| Column | Example | Notes |
|---|---|---|
| policy_doc_id | PD-0001 | key |
| title | ICD-10-CM Official Guidelines for Coding and Reporting FY2027 | |
| source_org | CMS | CMS, PAYER or COTIVITI |
| client_id | null | null for CMS documents; a client id for a payer policy |
| payment_year | 2027 | |
| doc_version | FY2027 | the publisher's version label |
| effective_from / effective_to | 2026-10-01 / null | |
| file_uri | /Volumes/…/policy/documents/PD-0001/CMS_ICD10CM_Guidelines_FY2027.pdf | |
| file_sha256 | 9f2c… | detects re-uploads of the same file |
| page_count | 120 | optional |
| status | ACTIVE | ACTIVE or SUPERSEDED |
| registered_by / registered_at | reva / 2026-10-21T15:00Z | |

**How it is filled:** a job (`register_policy_document`) scans the landing folder, reads each PDF + sidecar JSON, computes the checksum, inserts the row, moves the PDF to `documents/<policy_doc_id>/`. Run by hand today; later the review tool can register documents through the same job.

Sidecar example, `CMS_ICD10CM_Guidelines_FY2027.json`:
```json
{"title":"ICD-10-CM Official Guidelines for Coding and Reporting FY2027","source_org":"CMS","client_id":null,"payment_year":2027,"doc_version":"FY2027","effective_from":"2026-10-01"}
```

### 2. `rule_set` — one row per rulebook (client + year)

| Column | Example | Notes |
|---|---|---|
| rule_set_id | RS-DEFAULT-2027 | key |
| client_id | DEFAULT | DEFAULT = applies to all clients; else a client id |
| payment_year | 2027 | |
| model_version | CMS-HCC V28 | which payment model the rules target |
| name | Default risk-adjustment rulebook 2027 | |
| created_by / created_at | amit / 2026-10-21 | |

**How it is filled:** an identity row only, no rule content. Seeded by a small insert today (one DEFAULT row per year, one per client that has its own policy). Later, the policy tool creates the row the first time it generates rules for a new client-year.

### 3. `rule_set_version` — one row each time rules are (re)generated

| Column | Example | Notes |
|---|---|---|
| rule_set_version_id | RSV-DEFAULT-2027-001 | key |
| rule_set_id | RS-DEFAULT-2027 | → table 2 |
| version_no | 1 | |
| status | DRAFT | DRAFT → REVIEWED → APPROVED → RETIRED |
| generated_by | policy_to_logic 0.3 | tool and its version |
| generated_at | 2026-10-22T09:12Z | |
| source_policy_doc_ids | [PD-0001, PD-0002] | which documents the rules were generated from |
| ccdm_version | 0.1 | the vocabulary the rules were written against |
| approved_by / approved_at | null / null | set when status becomes APPROVED |
| notes | first generation from FY2027 guidelines | |

**How it is filled:** policy-to-logic writes its output as one JSON file to `/policy/rules/landing/`; a load job (`load_rule_set_version`) inserts one row here and the rules into table 4. Status changes come from the review tool (or a hand update today).

### 4. `rule` — one row per generated rule inside a version

| Column | Example | Notes |
|---|---|---|
| rule_id | R-000017 | key |
| rule_set_version_id | RSV-DEFAULT-2027-001 | → table 3 |
| rule_code | E11.22-CODEABLE-MEAT | stable key that survives across versions, so reviews can be compared |
| scope_icd10 / scope_concept_id | E11.22 / C001 | what the rule is about |
| rule_kind | CODEABILITY | CODEABILITY, EXCLUSION, HIERARCHY, DOCUMENTATION |
| rule_text | IF E11.22 is asserted ACTIVE in a face-to-face note in the payment year AND at least one MEAT criterion is met THEN E11.22 is CODEABLE | human-readable |
| rule_crl | {…} | the machine form in Reva's clinical rule language, stored as text |
| source_policy_doc_id | PD-0001 | → table 1 |
| source_citation | p. 14, section I.A.19 | where in the PDF |
| created_at | 2026-10-22T09:12Z | |

**How it is filled:** same load job as table 3, from the policy tool's output file. One output file → one version row → many rule rows. Column names in this table are the ones that most need Reva's confirmation.

Output file shape the load job expects (to agree with Reva):
```json
{"rule_set_id":"RS-DEFAULT-2027","generated_by":"policy_to_logic 0.3","ccdm_version":"0.1",
 "source_policy_doc_ids":["PD-0001"],
 "rules":[{"rule_code":"E11.22-CODEABLE-MEAT","scope_icd10":"E11.22","rule_kind":"CODEABILITY",
           "rule_text":"IF … THEN …","rule_crl":{},"source_citation":"p. 14, I.A.19"}]}
```

### 5. `rule_review` — one row per coder verdict on one rule

| Column | Example | Notes |
|---|---|---|
| review_id | RR-000301 | key |
| rule_id | R-000017 | → table 4 |
| rule_set_version_id | RSV-DEFAULT-2027-001 | → table 3 |
| reviewer_id | coder-priya | |
| verdict | APPROVE | APPROVE, REJECT, CHANGE_REQUESTED |
| comment | matches guideline; add 'in the payment year' to text | |
| suggested_rule_text | … | optional |
| reviewed_at | 2026-10-24T14:03Z | |

**How it is filled:** by coders through the review tool, which writes via the SQL endpoint (service principal) or, later, the data hub API. Today: a few hand-inserted rows to test the shape. Never updated or deleted; a changed mind is a new row.

## The example, end to end

1. Reva drops `CMS_ICD10CM_Guidelines_FY2027.pdf` + sidecar into the landing folder → `register_policy_document` → **PD-0001** (table 1).
2. Seed **RS-DEFAULT-2027** (table 2).
3. Reva runs policy-to-logic on PD-0001; it writes `rules_RS-DEFAULT-2027_20261022.json` to the rules landing folder → `load_rule_set_version` → **RSV-DEFAULT-2027-001**, status DRAFT (table 3) and 40 rows in `rule`, among them **R-000017** for E11.22 (table 4).
4. Coder Priya reviews R-000017 in the review tool → **RR-000301**, APPROVE (table 5). When every rule has a verdict and none is REJECT, the version's status becomes APPROVED.
5. The auditor, running on Mrs. Rao's chart, reads the APPROVED version of RS-DEFAULT-2027 and applies R-000017; the gold row records `rule_set_version_id = RSV-DEFAULT-2027-001`.
6. CMS publishes revised guidelines → PD-0002 → a new run → **RSV-DEFAULT-2027-002** (DRAFT). Version 001 stays, so every gold row from before still points at the rules that produced it.

## What is needed from Reva

- His policy PDFs (or their public sources) for the first registrations.
- One real output of policy-to-logic, to settle the columns of `rule` and the output file shape.
- A yes/no on the names above.
