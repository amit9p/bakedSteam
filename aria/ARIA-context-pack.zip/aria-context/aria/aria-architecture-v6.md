# ARIA architecture v6 — Oct 21 revision

Picture: artifact "ARIA Architecture v6" (https://claude.ai/artifact/PbGZi8k1ZmqpexouA9mNGi, version 2); disk copies `claude_output\aria\aria-architecture-v6.html` and `aria-architecture-v6.png` (for the deck). Same four lanes and style as v5. This is the one architecture for the design review; the zoom-ins are appendix pages. Revised on Oct 21 against Reva's Loop pages (P2L build guide, ARIA Architecture, P2L overview, evaluation methodology, Show Don't Tell, extraction requirements).

## The four lanes

1. CIS — the existing coding application (external): box 1 (one ZIP per chart: PDF + NLP JSON, plus the mode, on S3 with an event) and box 8 (coder review in the CIS app: CoPilot now, AutoPilot later). CIS's rule review app, the policy tool front end, talks to PRM's API directly, not through the hub; it is named in the lane, not drawn as a box.
2. Data hub (we build): bronze (2), silver in six CCDM tables (3), CTG store (5), gold + publish (7), the Explain API door, and the stores in lane 4.
3. AI components (Reva's; PRM runs in Reva's AWS account): Clinical Abstractor (4), Symbolic Auditor with six gates (6), Policy-to-logic (steps B, C, F), PRM, the policy store of record (steps A, D, E, G).
4. Reference data, golden dataset, policy copy, feedback: golden dataset (256 charts, next), reference data (CMS codes, HCC crosswalk, CCL, RAF weights, clinical taxonomy, our additions), CCDM registry, policy tables (nightly copy of PRM), feedback + eval (9). The Lookup API door sits between lanes 3 and 4.

## Follow the numbers — one chart

1. CIS runs NLP, drops one ZIP per chart (PDF + JSON, mode) on S3; the S3 event reaches us.
2. Land the ZIP as received (bronze); every version kept.
3. Clean into the shared schema (silver: mention, code candidate, relationship, MEAT evidence, note, chart); anything bad goes to quarantine with a named reason, reported back to CIS per feed version.
4. The Clinical Abstractor decides what's real, current, who said it, and proven by MEAT; each fact cites page and sentence.
5. Facts stored as the Clinical Truth Graph, one record per chart, versioned per run.
6. The Symbolic Auditor runs six fail-fast gates per code (valid code + HCC map, assertion active, DOS in coding year, provenance ≥ 0.75, MEAT evidence present, CRL policy rule) with the active rule set fetched from PRM. Deterministic: same in, same out.
7. Gold: per code, the disposition (codeable / flag / coder queue), the first failed gate, confidence, rule id + snapshot digest, all version keys; one results file per chart back to S3.
8. Coder reviews in the CIS app (CoPilot); "why this code?" goes to the Explain API.
9. Coder decisions with reason codes and shadow-mode dispositions stored; evaluation per HCC, code and date of service.

## Follow the letters — one guideline (Reva's eight steps)

A. Register: a guideline PDF goes into PRM through its API. B. Draft: a policy-to-logic job builds the rules (hours; Textract + LLM). C. Store: PRM keeps them as an unchangeable snapshot with a digest. D. Quality checks. E. Review: coders approve, revise or reject in CIS's rule review app through PRM's API; each verdict is tied to the rule's fingerprint. F. Revise: a new snapshot; only changed rules return. G. Promote: second sign-off; PRM marks the active ruleset. H. Use: the auditor fetches the active ruleset and compiled rules. The hub copies PRM's tables nightly (manual export first).

## The two doors

Lookup API: codes, concepts, synonyms, vocabulary, HCC crosswalk, CCL, RAF weights; silver, abstractor, auditor and P2L ask it. Explain API: CIS asks at coder time "why this code?"; reads gold, the graph and the evidence.

## Handshake with CIS

In: one ZIP per chart (PDF + NLP JSON, mode) on S3 with an event. Out: results per chart on S3 with an event; always an answer per chart, including "not processed, reason X". At coder time: the Explain API. Policy tool: CIS ↔ PRM's API directly.

## What changed on Oct 21

1. PRM, Reva's Policy Rules Manager, replaces our five-table policy store as the system of record (Postgres + S3 + API in Reva's account); the hub keeps a nightly copy for audit and analytics. `aria/policy-store-tables-v0.1.md` is superseded; `aria/policy-store-flow.html` is retired.
2. CIS's rule review app talks to PRM's API directly, not through the hub.
3. Box 1 carries one ZIP per chart and the mode (CoPilot | AutoPilot); box 8 is CoPilot now, AutoPilot later.
4. The auditor is the Symbolic Auditor with six fail-fast gates; gold records disposition, first failed gate, confidence, rule id and snapshot digest.
5. Silver grows to six tables per Reva's extraction requirements; quarantine reasons are named and reported back to CIS.
6. Golden dataset (256 charts) moves from phase 2 to next because it gates every release: same input + same rules → same answer; a rule change flips zero previously-correct charts. Reference data adds the HCC crosswalk, CCL and RAF weights.
7. Feedback carries reason codes and shadow-mode dispositions; evaluation is per HCC, code and DOS.

## Positioning for the design review

Reva's "ARIA Architecture" page is the component view (who computes what); v6 is the data view (where every artifact lives, who writes and reads it, how it is versioned and replayed). His P2L build guide joins them: "the lakehouse is the logical home of all data." Zoom-ins kept as appendix pages: policy lane with PRM (eight steps), data blueprint, taxonomy page, contract v0.2, evaluation metrics mapped to gold.
