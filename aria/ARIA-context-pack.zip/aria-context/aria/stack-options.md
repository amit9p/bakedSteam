# Where the data hub runs — platform options for the design review (Oct 21, 2026)

Reva's point 6 and Surya's ask on Oct 15: write up the options with pros and cons and a recommendation, and let Nikhil (AWS lakehouse) and Yesh (Databricks) weigh in. This page is the input; the decision is theirs and Surya's. The architecture and the blueprint are platform-neutral on purpose: every row holds on either option.

## What is fixed, whatever we choose

CIS is on AWS: account 981971132015, bucket `cis-nxt-gen-data-qa`, Kubernetes, Aurora. Reva's components run on Kubernetes on AWS; PRM (the policy store) will be Postgres + S3 in his account. The chart handshake is S3 in and S3 out with events. The ARIA pipeline today runs on Databricks (workspace `ai-engineering-dev`, Unity Catalog, serverless jobs, Asset Bundles, synthetic data). Cotiviti's GCP account is expected around the end of October; no environment exists yet, so GCP is not an option for this slice.

## The two options

| Question | Databricks on AWS (today's path) | AWS-native (Nikhil's lakehouse pattern) |
|---|---|---|
| Where the tables live | Unity Catalog: catalog per environment, schemas per lane (bronze, ccdm, ctg, gold, policy, ref, feedback), Volumes for files | S3 + Glue catalog (or Nikhil's lakehouse catalog), Iceberg/Delta tables, Athena/EMR/Glue jobs |
| Reading the CIS bucket | Cross-account read from the workspace's instance profile to `cis-nxt-gen-data-qa`; CIS adds our role to the bucket policy; Yesh sets it up | Same bucket policy; the role lives in whichever AWS account the hub runs in; if the hub is in the same org account, simpler |
| S3 event trigger | File-arrival trigger on the external location, or SQS → job trigger | S3 → SQS/EventBridge → Lambda/Step Functions → job; Nikhil's team has JSON + event patterns already |
| PHI governance | Unity Catalog row filters, column masks, audit log, lineage out of the box; the workspace must be approved for PHI (question for Yesh) | Lake Formation permissions, CloudTrail; lineage needs tooling; Nikhil's lakehouse already holds product data under existing controls |
| Reva's components (Kubernetes on AWS) | File handoff for the demo (Volume ↔ S3); later they read/write through the doors (SQL warehouse endpoint, REST) | Same S3 handoff; components and hub in the same cloud, possibly the same account: fewer hops |
| Lake copy of PRM (Reva's Stream H) | Nightly job reads PRM's Postgres (JDBC) and S3 into Delta tables; buckets registered as external locations | Glue/EMR job into the lakehouse; PRM's buckets catalogued in place |
| The lakehouse write API Reva assumes (LAKE-API-1) | SQL Statement Execution API over a warehouse for batch; for a coder's "save review" with immediate consistent reads, Lakebase (managed Postgres registered in Unity Catalog) would let PRM's Postgres live inside the lakehouse; whether Cotiviti has it: question for Yesh | A service in front of the lake (API Gateway + Lambda) writing to Iceberg, or records stay in PRM's Postgres and the lake holds copies only |
| The two doors (Lookup, Explain) | SQL warehouse endpoint on day one; Databricks Apps or a small service for REST later | API Gateway + Lambda/ECS over Athena or a serving store |
| Repo and CI | Asset Bundles + Jenkins (the Confluence SOP exists); tests run on serverless | Terraform/CDK + Jenkins; Nikhil's team's pipeline standards |
| Who runs it | Yesh's team (informal Databricks platform team under Surya) | Nikhil's team (Data Ingestion & Architecture) |
| Time to first real chart | Days: the pipeline exists; needs the bucket policy and a PHI-approved workspace | Weeks: rebuild the slice on the new stack, then the same access work |
| Risk | ARIA's data becomes another lakehouse beside Nikhil's ("five AWS instances holding five datasets", his words on Sep 16); mitigated by registering ARIA's catalog in his inventory and sharing via Delta Sharing / external tables | Rebuild cost now; Surya's group is on Databricks; the AI org's tooling (Unity AI Gateway, Claude Code) is on Databricks |
| Cost | Serverless jobs per chart; a SQL warehouse for the doors; storage in S3 either way | Glue/EMR/Lambda per chart; storage in S3 either way |

## What does not depend on the choice

The CIS contract, the CCDM schema and the six silver tables, the gold determination record, the quarantine rules and quality report, the golden dataset and replay job, the evaluation metrics, the blueprint's four rules, the PRM copy's shape. These are being built now on Databricks against mock data and carry over; only the glue (triggers, jobs, catalog registration, the doors' endpoints) changes.

## Recommendation to put on the table

Stay on Databricks on AWS for slice 2 and the November demo, because the pipeline exists there and the people who can give access are in this room; register ARIA's catalog and buckets in Nikhil's inventory from day one so it is not a fifth island; revisit at the GCP milestone, when the company decides where lakehouses go. The decision we need from this review is not "forever", it is "for the next two slices", and the four things that must be settled either way are below.

## Decisions needed from this review

1. Platform for slices 2–3: Databricks on AWS, or AWS-native in Nikhil's lakehouse.
2. Access: cross-account read from the hub to `cis-nxt-gen-data-qa` (who sets it up, which role), and a PHI-approved workspace or account for real charts.
3. Where the lake copy of PRM lands (schema `policy`), and who owns the lakehouse write API Reva has pencilled against the data engineer, with a target date or an explicit "not yet".
4. Whether AF-1 (Reva's account for PRM and the components) is provisioned by the same platform people as the hub; if so, one account plan instead of three.
