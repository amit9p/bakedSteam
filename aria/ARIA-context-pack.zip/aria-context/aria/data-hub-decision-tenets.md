# ARIA data hub — decision tenets and how we choose a platform

Draft v0.1, Nov 10, 2026. Owner: Amit. For: Reva, Nikhil, Yesh, Surya. Written after the Oct 29 design review.


## Why this page

There is no perfect platform; every option has cons. So before we compare Databricks, AWS-native or GCP, we write down what the data hub must guarantee, and what we are willing to trade. The platform that keeps the guarantees with the fewest trades wins. The guarantees come from the requirements (audit, PHI, evaluation, the CIS handshake), not from tool preference.

## Tenets — what the hub guarantees, on any platform

1. **Nothing that feeds a decision is ever overwritten.** Reruns create versions; corrections are new rows. Bronze, silver, the truth graph and gold are append-only.
2. **Every decision can be reproduced, years later.** Each gold row carries its version keys: rule snapshot digest and fingerprint, graph version, model, CCDM and taxonomy versions, feed version. Replay from bronze with the same versions gives the same answer.
3. **Every piece of evidence has a source.** A code points to a graph fact, the fact to a sentence (page and offsets) in silver, the sentence to the ZIP in bronze, the rule to its PRM snapshot and guideline page. No hop is inferred at audit time.
4. **PHI is read by jobs, not people.** Pipeline, components and the Explain API read PHI tables; humans get masked views unless they are auditing. Every PHI location has its own key and its own role.
5. **Other systems come through the doors.** Lookup and Explain APIs, or the S3 handoffs. Nobody reads our tables directly, and we never write to PRM; PRM is the policy store of record and we keep a copy.
6. **Same input plus same rules gives the same answer,** and a rule change flips zero previously-correct charts. Both are release gates, checked against the golden dataset.
7. **Bad data is kept and reported, not dropped or fixed.** Quarantine holds the row with a reason and an owner; the counts go back to CIS as a daily number.
8. **The data layer is portable; only the plumbing is platform-specific.** Tables are Delta/Parquet on object storage, jobs are PySpark, paths and endpoints are configuration. Triggers, catalog, roles and the doors' endpoints are the only things that change with the platform.

## Trade-offs we accept

- A rebuild of the plumbing if the company's hyperscaler decision moves us; not a rebuild of the data layer.
- A file handoff with the components for the demo instead of APIs.
- Days of lead time for cross-account access and PHI approval, rather than sharing a bucket or a workspace.
- The hub does not improve data quality. It keeps, flags and reports.

## Dimensions — what we score each platform on

Each comes from a tenet or a fixed fact. Score 1–3 (3 is best) with a one-line reason; no weights until we have scored once.

| # | Dimension | Comes from | What "good" looks like |
|---|---|---|---|
| D1 | Versioning and lineage | T1, T2, T3 | Append-only tables, time travel, lineage captured by the platform, not by hand |
| D2 | PHI controls | T4 | Row/column masking, audit log, per-location keys, an approved PHI environment exists or has a date |
| D3 | Reproducibility and replay | T2, T6 | Pinned-version reruns are cheap; both runs kept side by side |
| D4 | Fit with CIS and the components | fixed facts | CIS is on AWS S3; components and PRM run on Kubernetes/Postgres in AWS; fewest cross-cloud hops |
| D5 | The two doors | T5 | A SQL/REST endpoint the components and CIS can call with a role, day one |
| D6 | Time to first real chart | timeline | Pipeline exists; only access work remains |
| D7 | Portability | T8 | Data layer moves unchanged; plumbing is small and known |
| D8 | Who runs it and at what cost | org | A named platform team, existing CI/CD track, per-chart cost understood |
| D9 | Fit with the company direction | hyperscaler decision | Does not create another island; registered in the lakehouse inventory |

## Scoring sheet (facts as of Nov 10; scores to be filled after the hyperscaler decision)

| Dimension | Databricks on AWS (today) | AWS-native lakehouse | GCP (no environment yet) |
|---|---|---|---|
| D1 Versioning and lineage | Delta + Unity Catalog lineage out of the box | Iceberg/Delta on S3; lineage needs tooling | — |
| D2 PHI controls | Row filters, masks, audit log; PHI-approved workspace not confirmed | Lake Formation + CloudTrail; existing product-data controls | — |
| D3 Replay | Serverless reruns with pinned versions | Glue/EMR reruns | — |
| D4 Fit with CIS/components | Same cloud; cross-account roles | Same cloud, possibly same account | Cross-cloud to CIS, components and PRM |
| D5 Doors | SQL warehouse endpoint day one; REST later | API Gateway + Lambda to build | — |
| D6 Time to first chart | Days (pipeline exists) | Weeks (rebuild plumbing) | Months (environment + rebuild) |
| D7 Portability | Data layer portable; Unity-specific pieces avoided by design | Same | Same |
| D8 Who runs it / cost | Yesh's team; Asset Bundles + Jenkins | Nikhil's team; Terraform + Jenkins | Unknown |
| D9 Company direction | Register catalog in the lakehouse inventory | Native | Depends on the decision |

The decision is for Surya, Nikhil and Yesh once the hyperscaler direction is known.

## What does not change with the platform

The CIS contract, the six silver tables and quarantine, the truth graph store, the gold table, the golden dataset and replay job, the evaluation metrics, the policy copy, and the four rules in Part 2. All of it is being built now on Databricks against synthetic data and carries over.
