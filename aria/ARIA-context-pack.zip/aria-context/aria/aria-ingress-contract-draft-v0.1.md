# ARIA ↔ CIS data contract — draft v0.1 (assumed, for CIS to correct)

Status: Amit's assumption, written Oct 19, 2026 from what Reva and Binod have described and from the pipeline that already runs on synthetic data. Nothing here has been confirmed by CIS. Purpose: give CIS something concrete to say yes/no to, instead of an open question.

## 1. Ingress — what CIS drops, what ARIA picks up

**Mechanism (as Binod described it):** a CIS service extracts the NLP output for a processed chart and publishes it to an S3 bucket; S3 emits an event notification; ARIA's pipeline is triggered by that event.

**Assumed layout**

- One object per chart, JSON, UTF-8. Key pattern: `s3://<cis-bucket>/aria/in/<client_id>/<yyyy>/<mm>/<dd>/<chart_id>.json`
- The chart document (PDF or image bundle) stays where CIS keeps it; the JSON carries a reference to it (`chart_pdf_uri`). ARIA does not need to open the chart for slice 1.
- A re-send of the same `chart_id` is allowed; ARIA keeps the latest copy (by `event_ts`) and never double-counts.
- Event notification: S3 `ObjectCreated` on the `aria/in/` prefix, delivered to a queue or topic ARIA can subscribe to (SQS, SNS or EventBridge — CIS to say which; any of the three works).

**Assumed JSON, one chart**

```json
{
  "chart_id": "CH-8841",
  "client_id": "CLIENT-A",
  "member_id": "M-0042",
  "dos": "2026-03-14",
  "provider_id": "NPI-1234567890",
  "mode": "COPILOT",
  "chart_pdf_uri": "s3://cis-charts/2026/03/CH-8841.pdf",
  "source_msg_id": "k-7f3a9c1e",
  "event_ts": "2026-10-14T15:02:11Z",
  "nlp_version": "nlp_v3",
  "nlp_output": [
    {
      "text": "Type 2 diabetes with kidney complications",
      "page": 3,
      "start": 412,
      "end": 454,
      "code_candidates": ["E11.22"],
      "assertion": "present",
      "section": "ASSESSMENT_PLAN",
      "confidence": 0.94
    }
  ]
}
```

**Field by field**

| Field | Required | What ARIA does with it | Question for CIS |
|---|---|---|---|
| chart_id | yes | key for everything downstream; re-send detection | is it unique per chart across clients? |
| client_id | yes | which plan the chart belongs to | — |
| member_id | yes | links the chart to the member (risk score is per member) | which identifier, and is it the same one CIS submits to CMS? |
| dos | yes | date of service of the visit; "this payment year" rules | one date, or a range for multi-day encounters? |
| provider_id | wanted | "acceptable provider" rules later | NPI available? |
| mode | optional | COPILOT vs other review modes, if CIS has them | does this exist? |
| chart_pdf_uri | yes | reference for the explain API and audits | where will the chart live, and can ARIA read it? |
| source_msg_id, event_ts | yes | ordering, de-duplication, audit trail | — |
| nlp_version | wanted | stamped on every silver row for replay | does CIS version the NLP output? |
| nlp_output[] | yes | one entry per mention; becomes `condition_mention` | — |
| text, page, start, end | yes | the evidence span; page ≥ 1, start < end, offsets within the page text | character offsets into what: the page text, the whole document, OCR text? |
| code_candidates[] | yes | first = NLP's best ICD-10-CM; rest kept for the coder | ordered by confidence? |
| assertion | yes | present / history / negated / possible → CCDM ACTIVE / HISTORY / NEGATED / SUSPECTED | what is the full list of values NLP emits? |
| section | wanted | which part of the note (Assessment/Plan, HPI, Problem list, Meds, Labs…) | what values exist? |
| confidence | wanted | kept as source confidence, not used for decisions | scale 0–1? |

Anything that fails a rule (bad code, unknown assertion, missing page, bad span) goes to a quarantine table with the reason; the rest of the chart flows on.

## 2. Egress — what ARIA gives back (sketch only)

One object per chart, JSON, dropped to `s3://<bucket>/aria/out/<client_id>/<yyyy>/<mm>/<dd>/<chart_id>.json`, with an S3 event CIS can subscribe to. Content per code: the verdict (codeable / coder queue / drop), the evidence spans (page, offsets, text), the rule that fired and its version, model and schema versions, and a reference back to the chart. Later: an explain API for coder-time questions ("why no evidence for this code?").

Question for CIS: how does the coder application want to consume this — poll the bucket, subscribe to the event, or call an API?

## 3. What ARIA needs from CIS, in order

1. A de-identified sample JSON for two or three charts (any shape; this draft gets corrected from it).
2. The bucket name, the AWS account it lives in, and the event mechanism, so our platform team can set up read access.
3. The list of assertion and section values the NLP emits.
4. A sample of what the coder app would like to receive back.

## 4. Timeline on ARIA's side

Ready to land real CIS JSON into bronze and silver about one week after items 1 and 2 arrive. The pipeline already runs end to end on synthetic data in this shape.
