# ARIA data hub — data-artifact blueprint (Oct 21 revision)

Reva's point 5: every kind of data the hub keeps, with its rules. Page: artifact "ARIA Data Blueprint" (https://claude.ai/artifact/Te7Af147SzWF1x1jYLLaih, version 2); disk `claude_output\aria\aria-data-blueprint.html`. Platform-neutral. Revised against Reva's Loop pages: PRM is the policy store of record, silver follows his extraction requirements, gold carries the auditor's determination, the evaluation page sets the metric grain. Status: built = runs today on synthetic data · next = slice 2 (through December) · later = 2027.

## Chart path

| Data | What | Written by | Read by | PHI | Changes | Versioning | Storage | Access | Keep | Status |
|---|---|---|---|---|---|---|---|---|---|---|
| Bronze chart events | CIS's ZIP per chart (PDF + NLP JSON + mode) as received + file/event metadata + feed version | ingress job | silver; replay | yes | every chart | append only; re-send = new row | table by receive date + raw ZIP archive | pipeline SP only | years (replay source) | built |
| Silver — six CCDM tables | `chart` (patient, encounters, DOS, facility type, payer, HCC model version); `note` (signer, credentials, co-signature, authentication, signature vs service time, addenda); `mention` (entity, page + offsets, section, note type, author, DOS, six-state assertion, severity/stage); `code_candidate` (all candidates with confidence, supporting mentions); `relationship` (TREATS / EVALUATES / MONITORS / INDICATES / COMPLICATES with span); `meat_evidence` (M/E/A/T, span, section, DOS) | silver job | abstractor, auditor gates L1–L4, explain API, analysts | yes | every chart | latest copy per chart; ccdm_version + nlp_version on every row | one table per entity | row-level by client; masking for non-coders | years | built (two tables); six next |
| Quarantine | failed mentions or whole charts with a named reason code and owner (CIS, NLP team, hub, CCDM registry); whole-chart failures also returned to CIS as "not processed" | silver job | DEs; CIS + NLP team via a daily report by feed version and reason | yes | every chart | append only; resolves when a replay passes | table | pipeline + DEs | 1 year | built |
| Export for components | CCDM JSON per chart for the abstractor (demo handoff) | export job | abstractor | yes | every chart | regenerated; not a record | folder | component SP | 30 days | next |
| Clinical truth graph | ctg.node, ctg.edge: one deduplicated record per chart, condition → evidence → provider, assertion, MEAT, DOS; an instance of the CCDM | abstractor (load job now, direct later) | auditor, explain API, auditors | yes | every chart | append only; graph version per run; model + CCDM versions | two tables | components + explain API | years | next |
| Gold determinations | one row per (chart, encounter, code, DOS, run): disposition (codeable / flag / coder queue), first failed gate L1–L6 + reason, routing lane (shadow / HITL / autonomous), confidence per HCC with four sub-factors, rule id + snapshot digest + fingerprint, claim verdicts with quoted spans, evidence refs, "what would clear it", coder action + reason code | auditor (load job now); coder action from CIS | publish job, explain API, CIS, eval, decision-package export | yes | every chart | append only; rerun = new version; all version keys; write-time checks: citations verbatim, every non-accept names its blocking check | table | CIS via API/file; never hand-edited | years | next |
| Results file to CIS | per-chart JSON: dispositions + evidence + versions; always one per chart received, incl. "not processed, reason X" | publish job | CIS app | yes | every chart | derived from gold | S3 prefix + event | CIS role read-only | 90 days | next |
| Coder feedback on codes | accept/reject/override with structured reason code; time per chart; blind re-review results; shadow-mode comparison for Kappa | CIS app; eval job | eval, Reva's team (rejections by root cause), analysts | yes | every reviewed chart | append only; linked to gold row; confirmed errors → golden dataset | table | eval + DEs | years | next |
| Decision package export | one standalone artifact per (chart, code): evidence spans with page/line, rule + snapshot, gate results, reasoning chain, coder action; readable with no access to ARIA (Commitment 6) | export job from gold + CTG + evidence | compliance, external auditors, QA leads | yes | on request + sampled | locked, timestamped, pinned to the rule version active at execution | write-once store | compliance role | years | next |

## Policy lane — PRM is the system of record (Reva's); the hub keeps the copy

| Data | What | Written by | Read by | PHI | Changes | Versioning | Storage | Access | Keep | Status |
|---|---|---|---|---|---|---|---|---|---|---|
| PRM records (Reva's) | policy documents (content_hash, policy_id, payer, edition, dates), rule snapshots (digest; CRL + DRL), review items (rule, value set, claim code set) with fingerprints, coder reviews (approve / minor edits / revise / reject, structured reason, reviewer_token), quality-check results, active-ruleset pointer (tenant, payer, LOB, DOS period → digest) | PRM: P2L jobs; CIS's rule review app via PRM's API | auditor (via API), CIS's app, Reva's team | no | per edition; during reviews | snapshots immutable; review binds to one fingerprint; nothing live unapproved (API-enforced) | Postgres + S3 in Reva's account | PRM's API only; tenant-isolated | forever | next; PRM does not exist yet |
| Policy tables (lake copy) | nightly copy of PRM's records, reconciled against Postgres; PRM's buckets registered in the catalog; later the records move here via the write API | data-bridge job (Reva's Stream H; data engineer); manual export first | explain API, eval, analysts, audit walk-back | no | nightly | append per digest; keyed by fingerprint | schema `policy` + catalog entries | all read; bridge job write | forever | next; after PRM's schema is frozen |
| Lakehouse write API (LAKE-API-1) | the write path Reva's plan assumes for the strategic phase (PRM writes records to the lake with immediate consistent reads); date and shape undecided: SQL endpoint, Lakebase, or records stay in Postgres | data hub (owner per Reva: the data engineer) | PRM | no | — | — | — | — | — | later; exit criteria in Reva's Appendix B |

## Reference data

| Data | What | Written by | Read by | PHI | Changes | Versioning | Storage | Access | Keep | Status |
|---|---|---|---|---|---|---|---|---|---|---|
| CMS code sets | code_reference: ICD-10-CM (+ CPT / ICD-10-PCS), the ICD-10 → HCC crosswalk per model version (exists), RAF weights (needed for the RAF-delta metric; not held yet) | yearly load | silver, auditor, explain API via lookup door | no | yearly | one set per model version; old kept | table | all read | forever | built as constants; table next |
| Payer reference lists | condition_category_list: chronic / acute / not listed per code and DOS period, per payer; the nine exceptionally acute conditions; loaded directly, not through P2L; rules query them at decision time | load job per payer edition | auditor (CRL rules), eval, via lookup door | no | yearly per payer | new year loaded beside the old, never overwritten | table keyed by payer, code, DOS period | all read | forever | next |
| Clinical taxonomy copy | concept, concept_synonym, concept_relationship, concept_code_map | extract load (manual; API later) | all components via lookup door | no | when NLP team publishes | extract version on every row | four tables | all read | current + previous | next (mocked first) |
| Our additions | concept_augmentation with who/why/when | DEs with Reva | same | no | rarely | append only | table | named editors | forever | next |
| CCDM registry | vocabulary, source_map, schema version; co-owned with Reva; a request path for new CCDM facts | DEs with Reva | silver, P2L, all | no | when CCDM changes | minor = add, major = rename/remove; rule sets record the version | two tables + design doc | named editors | forever | built as constants; tables next |

## Quality and operations

| Data | What | Written by | Read by | PHI | Changes | Versioning | Storage | Access | Keep | Status |
|---|---|---|---|---|---|---|---|---|---|---|
| Golden dataset | 256 real, de-identified charts with coder-confirmed decisions (200 on the architecture page: confirm); gates every phase; confirmed errors added as permanent test cases | coders + DEs; eval job | replay job, eval | yes (de-identified) | grows with every confirmed error | versioned set; releases record the version passed | tables + files | restricted | forever | next |
| Replay / regression runs | reproducibility (same chart + rules → same disposition) and regression safety (new snapshot flips zero previously-correct charts, every promotion); ablation samples | replay job from bronze with pinned versions | release checks, Reva's team, QA | yes | every release; monthly samples | both runs kept; the diff report is the record | tables | all read | years | next |
| Evaluation metrics | the evaluation page's component and end-to-end metrics at diagnosis-code + DOS grain within each HCC, by chart complexity and size, per version; HITL time/override/automation-bias; shadow-mode Kappa | eval job | Reva's team, leadership (drill-down), QA | no | per release / review cycle | one set per version; never one aggregate | table + dashboard | all read | forever | next |
| Run and lineage records | job runs, inputs, outputs, version keys | every job | ops, auditors | no | every run | append only | job system + lineage | all read | years | built (platform) |

## Four rules for every row

1. Nothing that feeds a decision is overwritten; reruns create versions, corrections are new rows.
2. Every decision row carries its version keys: rule snapshot digest and fingerprint, graph, model, CCDM, taxonomy extract, release.
3. PHI tables are readable only by the pipeline, the components and the Explain API; humans get masked views unless auditing.
4. Other systems reach data through the two doors or the S3 handoffs, never by reading tables directly. PRM is the policy store of record; the hub holds a copy and never writes to it.

## Discovery

Every table registered in the catalog with owner, PHI flag, retention and the rules as tags. One schema per lane: bronze, ccdm, ctg, gold, policy, ref, feedback. Design docs live with the code.

## The audit question

"Why did you recommend E11.22 on this chart in 2026?" → gold row (disposition, gate, confidence) → rule fingerprint + snapshot digest → rule + PDF citation (PRM copy) → graph version → evidence span (page, offsets) → silver row → bronze ZIP. Every hop is a kept, versioned row; replay from bronze with the same versions reproduces the answer. The decision package export is this walk, frozen.

## What changed on Oct 21

Silver: two tables → six (chart, note, mention, code_candidate, relationship, meat_evidence), from Reva's extraction requirements. Quarantine: reason codes with owners, daily report to CIS, whole-chart "not processed" returned. Gold: renamed "determinations"; carries disposition, first failed gate, lane, confidence sub-factors, snapshot digest + fingerprint, claim verdicts, "what would clear it", reason codes; write-time citation and blocking-check checks. New rows: decision package export (Commitment 6), PRM records (Reva's), policy tables lake copy (Stream H), lakehouse write API (later), payer reference lists (CCL), replay/regression runs. Policy documents / rule sets / coder reviews rows removed (they are PRM's). Golden dataset: later → next, 256 charts. Evaluation metrics: later → next, with the evaluation page's grain. Reference data: HCC crosswalk, CPT/PCS, RAF weights.
