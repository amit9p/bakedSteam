# Where the Taxonomy Lives — CCDM, Group A/B and the lookup door

Explainer written Oct 16, 2026 after Reva's point 4 ("CCDM wraps the existing taxonomy"). Visual version: artifact "Where the Taxonomy Lives" (https://claude.ai/artifact/FehUq6eT88E26mboXqS6qz); disk copy `claude_output\aria\where-the-taxonomy-lives.html`.

## Who is who

- **NLP team** (William is one of its leaders): builds the NLP engine that reads a chart and extracts concepts and candidate codes, and owns the **taxonomy** — an in-house clinical dictionary in an Oracle database, ~20M concepts and 40M relationships: concept ids, preferred names, synonyms, types (condition, lab, drug, procedure), links between concepts (is_a, treats, measures, complication_of) and maps to codes (ICD-10-CM, RxNorm, LOINC). No API today; visible only through the NLP team's own tools.
- **CIS team** (Binod): builds the coder-facing application on top of the NLP engine and is our feed partner. The JSON CIS drops on S3 is the NLP engine's output for a chart.
- **Data hub** (ours): tables + pipelines + the doors other systems use to reach the data.
- **AI components** (Reva, Kubernetes): abstractor + MEAT, auditor, policy-to-logic.

## The picture in words

NLP engine → CIS app → S3 (JSON + chart, event) → bronze → silver (Group B) → abstractor → CTG → auditor → gold → back to CIS (results per chart on S3 + explain API). The taxonomy reaches us once, into the Group A reference tables (today: extract and refresh; later: the NLP team's API behind the same door). A **CCDM API, the lookup door**, sits in front of Group A; abstractor, auditor and policy-to-logic ask it for names, synonyms, codes and links instead of keeping their own copies.

## Group A and Group B — still there

- **Group B** (per-chart, PHI, filled every run): encounter, condition_mention, quarantine; later provider, evidence_span. Unchanged.
- **Group A** (reference, loaded rarely, no PHI): source changes from hand-typed CSVs to the taxonomy, and it grows:

| Table | Holds | Status |
|---|---|---|
| vocabulary | allowed values: assertion, section, meat_criterion, disposition | exists (slice 1) |
| source_map | NLP's words → CCDM words (present → ACTIVE, …) | exists (slice 1) |
| code_reference | valid ICD-10-CM → HCC (V28) | exists (slice 1) |
| concept | one row per clinical idea: id, preferred name, type | new, from the taxonomy (mocked first) |
| concept_synonym | other names for the same idea | new |
| concept_relationship | is_a, treats, measures, complication_of | new |
| concept_code_map | concept → ICD-10-CM, RxNorm, LOINC | new |
| concept_augmentation | our additions to any of the above, with who/why/when | new, ours to own |

Example rows: C001 "Type 2 diabetes mellitus with diabetic nephropathy" (condition) → E11.22; C002 "Chronic kidney disease stage 3" → N18.30; C003 Metformin (drug, RxNorm 6809) treats C001; C004 eGFR (lab, LOINC 33914-3) measures C002. Synonyms of C001: "diabetic nephropathy", "T2DM with CKD".

## Where each table is used

silver: synonym + code_map to normalise what NLP sent · abstractor: synonyms to match chart text · policy-to-logic: is_a + code_map to expand a guideline phrase into codes · auditor: treats / measures for MEAT · explain API: preferred names.

## "The data hub exposes the taxonomy through an API" — plainly

Today every component keeps its own copy of the dictionary (Reva pulled the top-50-HCC concepts from Oracle; we typed a vocabulary CSV). Instead: one governed copy in Group A and one small lookup service in front of it. If the NLP team ships their own API later, our door calls theirs and the copy goes away; nobody else changes.

## Mocking it

Build the four concept tables from public code sets (ICD-10-CM, RxNorm, LOINC) for the conditions in the sample charts. Same shapes, same door; swap contents for the real extract when access arrives. For the design review: one slide, this picture, with the sentence "mocked now from public code sets, swapped for the real taxonomy behind the same API later."
