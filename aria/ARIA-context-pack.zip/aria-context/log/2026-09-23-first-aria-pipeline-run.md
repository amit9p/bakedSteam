# 2026-09-23 — First ARIA pipeline run (Volume, starter copied, aria_hello_pipeline on serverless)

## What we did, in order

1. **Created the Volume** in SQL Editor: `CREATE VOLUME IF NOT EXISTS ai_engineering_dev_catalog_1688890232235261.amit_prasad.personal;` A Volume is the Unity Catalog place for *files* (tables are for rows). The pipeline uses it for `/Volumes/…/amit_prasad/personal/aria/landing` (synthetic CIS event files, `.jsonl`) and `…/aria/checkpoints` (Auto Loader's memory of which files it already processed).
2. **Copied the starter into the office-laptop project** `C:\Users\amit.prasad\dev\aria\aria_data_pipeline\`: replaced the template's `resources\` and `src\` with the starter's, overwrote `databricks.yml`, added `tests\`, `pytest.ini`, `Jenkinsfile`, `CLAUDE.md`. Kept the template's `.databricks`, `.venv` (Python 3.12.4 via uv), `.vscode`, `fixtures\`, `AGENTS.md`, `pyproject.toml`. `bundle.name` set to `aria_data_pipeline` locally so the existing dev deployment state is reused — the template's `sample_job` shows as **"deleted after deploy"** in the Bundle Resource Explorer; that is expected (it is removed from the workspace on the next deploy).
3. **YAML error on deploy** (`databricks.yml: line 32: did not find expected key`): a stray quote inside the `generate_samples` variable description in the master. Fixed in master and locally; `bundle validate` clean.
4. **Deploy and Run `aria_hello_pipeline`** (serverless, job parameters → notebook widgets):
   - `generate_sample_events` ✅ wrote one `.jsonl` file (4 events: CH-8841 twice — second copy adds E78.5 —, CH-8842, CH-8843 with a bad code `XYZ` and assertion `maybe`).
   - `bronze_chart_events` ✅ Auto Loader landed the 4 rows into `amit_prasad.chart_events`.
   - `silver_ccdm` ❌ `[NOT_SUPPORTED_WITH_SERVERLESS] PERSIST TABLE is not supported on serverless compute (SQLSTATE 0A000)`. Cause: `events = … .cache()` in `silver.run`. Serverless does not allow `cache()`/`persist()`.
   - **Fix:** removed `.cache()` (`src\aria\silver.py`, `run()`); master copy, zip and project mirror updated; the 5 local tests still pass. Amit applies the one-line edit in his local copy → Save → Deploy and Run (cancel the pending retry of the old run).

5. **Re-run after the fix: all three tasks green** — run 201202913316971, 1 m 29 s on serverless (generate 25 s, bronze 32 s, silver 30 s). Lineage on the run page: 1 upstream table (`chart_events`, read by silver), 4 downstream tables (`chart_events`, `encounter`, `condition_mention`, `quarantine`). First end-to-end ARIA slice-1 run in ai-engineering-dev.

## What is now proven

- Auto Loader (`cloudFiles`, text format, `availableNow`) reading from a Volume works on serverless; the checkpoint also lives in the Volume, so a re-run only picks up new files.
- Job parameters defined in `resources\aria_hello_pipeline.job.yml` reach the notebooks as widgets (`Settings.from_widgets(dbutils)`), so the same code runs in dev / mvp / prod with different catalog, schema and Volume values.
- The `_add_src_to_path()` bootstrap in the notebooks finds `src\aria` from the deployed bundle folder (`/Workspace/Users/amit.prasad@cotiviti.com/.bundle/aria_data_pipeline/dev/files`).
- Serverless caveats so far: no `cache()`/`persist()`; use `spark.sql` DDL + Delta MERGE (works), no cluster to start or pay for between runs.

## Expected after the fixed run

| Table (`ai_engineering_dev_catalog_1688890232235261.amit_prasad.…`) | Rows | Why |
|---|---|---|
| `chart_events` | 8 | run 1 landed 4; the new run writes a second sample file and lands 4 more (bronze is append-only, the replay record) |
| `encounter` | 3 | one row per chart: CH-8841, CH-8842, CH-8843 (latest copy of CH-8841 wins) |
| `condition_mention` | 8 | valid mentions from the latest copy of each chart |
| `quarantine` | 2 | CH-8843's `XYZ` code (`icd10_invalid`) and `maybe` assertion (`assertion_not_in_vocabulary`) |

Run it a third time: `chart_events` 12, the three silver tables unchanged (idempotent: delete-then-MERGE per chart, stable `mention_id`). Catalog Explorer → the table → **Lineage** tab shows `chart_events` → `condition_mention` and the job that wrote it.

## Still open

- Confirm the counts above in Catalog Explorer / SQL Editor, then a second run for idempotency.
- Local venv: `python -m databricks.connect test` (serverless), `pytest` (needs `pyspark` or `databricks-connect` installed in `.venv` with `uv pip install --native-tls …`).
- Bitbucket: HTTP access token, personal sandbox repo, Git for Windows (no admin → user-level installer), `git config --global http.sslBackend schannel`; get the reference repo's Jenkinsfile (Rutvi) to replace our placeholder; Jenkins `Databricks_Migration` onboarding + webhook.
- Zscaler cert → `NODE_EXTRA_CA_CERTS`; Claude Code extension once the PAT permission arrives (David); Claude SSO login ticket.
- Email to Reva (cc Surya): presentation slot, Bitbucket project for ARIA, Jenkins onboarding.
- Master `databricks.yml` still says `bundle.name: aria-pipeline`; local copy says `aria_data_pipeline` — align when the real repo is created.
- Slice 2: CCDM reference tables (`vocabulary`, `source_map`, `code_reference`) as real tables, `provider`, `evidence_span`, HCC lookup; later CTG / gold stubs and the Kafka reader.
