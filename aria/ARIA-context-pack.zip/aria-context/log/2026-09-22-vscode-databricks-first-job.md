# 2026-09-22 — Environment setup: VS Code ↔ Databricks, first job run

## What we did, in order

1. **Read the Confluence pages** Amit photographed (33 photos): "Databricks + VS Code + Claude Code" (Sanket Zanwar), "Claude Code on Databricks" (Jonathan Dehdari), the Zscaler SSL fix, the Windows VS Code docx, the Claude Code pilot page. Transcribed to `confluence\databricks-vscode-claude-code.md`; Windows follow-along guide in `guides\setup-guide-vscode-databricks-claude-code-windows.md`.
2. **Token blocked.** Databricks refuses to create a personal access token for Amit's user ("contact your administrator"). Email sent to David Munoz (cc Surya, Yesh) asking for the "Can use" token permission in ai-engineering-dev. The token is needed **only for Claude Code** (its `ANTHROPIC_AUTH_TOKEN`); the VS Code extension works with OAuth.
3. **Explained the platform:** Bitbucket Server (code) → Jenkins `Databricks_Migration` (bundle validate/deploy as `dab-sp-prod`) → dev/mvp/prod workspaces; Jira is tickets, not deployment; Claude Code edits local files only. Who creates what: job from `resources/*.yml` via Jenkins, job cluster per run, personal cluster by hand, tables by code, catalog/schema/grants by platform. Published as the "ARIA Pipeline Blueprint" artifact + `guides\aria-pipeline-blueprint.html` + `guides\cotiviti-databricks-dev-workflow-explained.md`.
4. **Built the ARIA starter repo** (`aria\aria-pipeline-starter\`, zip alongside): slice 1 of Amit's own architecture — synthetic CIS events (his ingress JSON) → `bronze.chart_events` → CCDM v0.1 `encounter`, `condition_mention`, `quarantine`. Asset Bundle layout (`databricks.yml` at root, `resources/`, `src/aria`, `src/notebooks`, `tests/`), Jenkinsfile placeholder, CLAUDE.md. Tests pass on local Spark 3.5 (5 tests; expected counts 3 charts / 8 mentions / 2 quarantined). Dev defaults: catalog `ai_engineering_dev_catalog_1688890232235261`, schema `amit_prasad`, Volume `personal`.
5. **VS Code on the work laptop:** installed the Databricks extension → Configure Databricks → OAuth (user-to-machine) → profile `dbx_profile`. Accepted the extension's "create new project" (`databricks bundle init`): template default-python, name `aria_data_pipeline`, ETL pipeline no, wheel no, serverless yes, catalog default, personal schema yes.
6. **First deploy + run** from Bundle Resource Explorer: job `[dev amit_prasad] sample_job` created in ai-engineering-dev and ran on serverless. First run failed — `SCHEMA_NOT_FOUND …amit_prasad` (the wizard assumed the personal schema existed). Amit created it in SQL Editor (`CREATE SCHEMA IF NOT EXISTS …amit_prasad`) — so he has CREATE SCHEMA on the dev catalog — and re-ran: **Succeeded**. The notebook set catalog/schema and read `samples.nyctaxi.trips` (Databricks demo data); it wrote nothing.

## What is now proven

- Laptop → `bundle deploy` → job created → run on serverless → success, **without** a PAT, without Python on the laptop, without a cluster.
- The extension ships its own Databricks CLI (`%USERPROFILE%\.vscode\extensions\databricks.databricks-2.18.0-win32-x64\bin\databricks.exe`); no separate install needed.
- Amit owns a personal schema `amit_prasad` in the dev catalog; jobs in dev mode get the `[dev amit_prasad]` prefix and paused schedules — isolation works as designed.
- Jobs list shows only what Amit has permission to view (4 jobs); other jobs run as service principals `model_register_sp`, `rca-scoring-sp`.

## Still open

- Python 3.11 not installed (the extension's own `uv python install` download fails behind Zscaler); Git for Windows not installed; Bitbucket not yet touched (HTTP token, personal sandbox repo). Zscaler cert variables not yet set.
- Claude login via AD group still failing (ticket open); PAT permission pending (David).
- Email to Reva (cc Surya): presentation slot + which Bitbucket project owns ARIA + Jenkins onboarding.

## Next session

1. `CREATE VOLUME IF NOT EXISTS ai_engineering_dev_catalog_1688890232235261.amit_prasad.personal;`
2. Get `aria-pipeline-starter.zip` onto the work laptop (email/OneDrive), replace the template's `resources/` and `src/` with it (overwrite `databricks.yml`).
3. Deploy and Run `aria_hello_pipeline`; expect `chart_events` 4 rows, `encounter` 3, `condition_mention` 8, `quarantine` 2; second run leaves silver unchanged.
4. Then Python, Git, Bitbucket sandbox repo, Zscaler cert; Claude Code once the token arrives.
