# ARIA Evaluation Methodology — Loop page (read Oct 21, 2026)

Source: photos 41–63 and 82–104 (a second pass of the same page) of `D:\Cotiviti\confluence\additional_info_aria-10-21-2026-item1\Photos-1-001` (08:40–08:42 and 08:46–08:48, Oct 21). Read-only Loop page (Recent list: Oct 1; author not shown). Sections 1–8 plus Appendix A (tenets in full) and B (glossary) were captured. The glossary refers to Appendix C (the golden dataset) and Appendix F (IoU), but the page ends after the glossary (confirmed by Amit, Oct 21): Appendices C–F are referenced, not yet written. Linked from "ARIA Architecture" §3.

## 1. Purpose

"ARIA assists risk-adjustment coders by extracting candidate diagnoses from a clinical chart, checking whether each is properly supported, and presenting a recommendation for a coder to review. This document exists to answer one question precisely, for each part of the system and for the system as a whole: **how do we know it's good enough to trust with the next increment of responsibility, and what exactly is that trust based on?**" Callout: "Confident is not the same as correct!"

## 2. Tenets (ordered; when two conflict, the earlier wins)

1. We choose lost revenue over audit risk, even when both are real money. (A missed code costs what it costs, chart by chart, often recoverable next cycle; a wrongly accepted code can be extrapolated across an entire audit population and carry legal exposure no single chart's revenue justifies.)
2. We trust a recommendation because it's traceable, not because it sounds confident, even at the cost of speed. ("A decision that cannot be reconstructed for an auditor is not a decision this system is allowed to make on its own.")
3. Autonomy is earned on evidence, not assumed from accuracy. (A stage takes on more independent decision-making only after demonstrating, on real charts with real coders, that it deserves it, including evidence that coders still catch its mistakes.)
4. We report what we know, and name what we don't, even when the honest answer is unflattering. (Every number states its own evidence: measured, computable from data we have, blocked on a missing input, or not yet built.)
5. We look for where quality breaks, not just whether it holds on average. (Every metric that matters is reported by risk category and condition type.)

## 3. ARIA risks (plain terms, each tied to a tenet and a control)

1. A handful of mistakes can turn into a much larger financial exposure: CMS audits sample a few charts and apply the error rate across the whole population of payments for that contract. (Tenet 1)
2. A wrong answer can look completely convincing: a confident, well-cited recommendation that is still wrong. (Tenet 2; groundedness checks in 5.2/5.6)
3. We may not be able to explain, months later, why the system did what it did: AI models are not guaranteed to give the same answer twice; a decision has to survive a CMS audit long after the fact. (Tenet 2; reproducibility in 5.5)
4. The system can become less safe as it gets more accurate: people check less closely right when the remaining mistakes matter most. (Tenet 3; §7)
5. One design flaw can repeat on every chart it touches: a wrong rule or biased model repeats at whatever volume the system runs. (Tenet 3; 5.4)
6. We might believe something is proven when it's untested, or assume last quarter's result still holds: models update, policies change. (Tenet 4)
7. A good overall number can hide a dangerous weak spot. (Tenet 5)
8. Our own yardstick isn't perfect: historical decisions come from one reviewer's judgment per chart, not a panel. (Tenet 4)

## 4. System overview

Same build-time / run-time stack as the architecture page; "one of the core disciplines we adopt is the use of ensemble (or Mixture of Experts) modeling at every critical decision-making stage": code and entity extraction, MEAT classification and rule authoring each run as an ensemble. Glossary in Appendix B.

## 5. Component quality (six components; invariant 100% targets are correctness properties, a miss is a bug; "provisional" targets are first-pass bars to be replaced by real measurement once a baseline exists)

| Component | What it does | Metrics → targets | Why it matters |
|---|---|---|---|
| 5.1 Code & entity extraction | Reads the chart, proposes candidate diagnoses with ICD-10 codes; nothing downstream can recover a finding this stage never proposed | Recall vs coder-confirmed codes ≥95%; full-specificity match rate ≥95% (CMS requires full specificity to credit an HCC) | A missed candidate is unrecoverable, invisible revenue loss; recall gets the strictest bar; precision is enforced downstream |
| 5.2 MEAT attribution | For every candidate, checks whether the chart documents Monitoring, Evaluation, Assessment or Treatment; three-source ensemble (one built, two planned), voting per criterion | Evidence groundedness 100% (invariant); evidence redundancy rate ≤2%; per-criterion M/E/A/T F1 ≥0.85 (prov.); token-level span IoU vs a human's span >0.75 (prov.); token-level span F1 ≥0.85 (prov.); inter-source span agreement >0.7 = converged, <0.3 = conflicting, flag for review (prov.) | A false "supported" verdict is the most direct path to audit exposure; groundedness is a hard invariant. "Groundedness is not the same question as faithfulness": a citation can be real and still not be why the classifier decided |
| 5.3 CTG construction | Consolidates extraction and MEAT output into one clean, deduplicated record per chart | False-merge rate ≤1%; false-split rate ≤5%; code-mapping precision ≥95%; specificity match rate ≥95%; ICD-10 hierarchy/exclusion violations 0 (invariant; not yet scoped) | A false merge deletes a real finding without a trace; a false split is cheap by comparison |
| 5.4 Policy-to-Logic compiler | Converts policy documents into the executable logic run against every chart; built once per policy; includes CCL-dependent rules keyed to a DOS period | Internal logical-consistency pass rate 100% (invariant); clause coverage 100% of codifiable clauses; SME sign-off on promoted rule sets 100%; regression safety: re-running the golden dataset against a new rule version flips 0 unreviewed previously-correct charts; rule-chain cyclomatic complexity flagged above a threshold (not set) | A wrong rule compounds (Risk 5): the highest-leverage place to spend reviewer time; regression safety is the build-time version of drift |
| 5.5 Rule validation and gating (Symbolic Auditor) | Applies 5.4's rules to one chart's 5.3 record; per code: codeable / needs a coder / drop; deterministic | Reproducibility (same input, same output) 100% (invariant); defined-check implementation coverage 100%; disposition agreement with coder decisions ≥90% (prov.) | Deterministic, so proving it correct is a bounded engineering problem |
| 5.6 ARIA coding recommendation | What the coder sees: a ranked list and top recommendation with evidence | Groundedness/relevance 100% (invariant); Top-1 precision ≥80% (prov.); MRR tracked | What stakeholders judge the pilot by; an unvalidated top recommendation biases coders toward whatever is shown first |

## 6. End-to-end quality ("the strictest specification in this document, not the loosest": a composite of 5.1–5.6, never a single black-box score; a wrong final disposition must trace to the component responsible)

| # | Metric | Target |
|---|---|---|
| 1 | Precision (of the codes ARIA recommends, the share the coder confirms) | ≥90% (prov., first-pass bar) |
| 2 | Recall (of the codes the coder confirms, the share ARIA surfaced) | ≥90% (prov.) |
| 3 | Specificity (of the codes that should stay uncoded, the share ARIA leaves alone) | ≥90% (prov.; guards against over-coding) |
| 4 | Specificity match rate (right code family at full ICD-10 specificity), measured on ARIA's final recommended code | ≥95% |
| 5 | False-accept rate | ≤2% (prov.; "the primary compliance-risk headline, Tenet 1") |
| 6 | False-reject rate | tracked separately, no ceiling; a revenue question, not a compliance one |
| 7 | False-accept rate on the nine Exceptionally Acute conditions | 0% without grounded MEAT evidence (invariant; already enforced in 5.4/5.5) |
| 8 | Auto-accept rate (codes shown pre-accepted, still reviewable, never submitted unreviewed) | tracked |
| 9 | Coder-queue rate (codes routed to "needs a coder's judgment") | tracked; a rising rate is a drift signal |
| 10 | Citation accuracy (every recommended code carries a citation that verifiably exists in the chart) | 100% (invariant; "the client's own term" for groundedness) |
| 11 | RAF score delta (agent's RAF-weighted output vs the coder's) | not yet computable; needs a RAF weight table; the ICD-10-to-HCC crosswalk is confirmed to exist |
| 12 | Reproducibility (same chart, same rules, same disposition) | 100% (invariant) |

Required reporting grain, "per the client's own stated requirement": every metric at the diagnosis-code and date-of-service level, within each HCC category, not only per chart. A full run must produce every metric broken out by HCC category (DM/CKD/CHF for this pilot), chart complexity and chart size, never one aggregate; a per-component attribution for every wrong disposition (a punch list); precision, recall, specificity and false-accept/false-reject stated together, never collapsed into "accuracy". Quality gate: the pipeline earns the next increment of trust only once every target is cleared on the full 256-chart set at that grain.

6.1 System-level explainability: one causal chain per code, not six separate justifications; nodes for the cited evidence spans, the MEAT verdicts built from them, each of the six checks (code/HCC validity, assertion active, coding-year window, provenance threshold, MEAT evidence present, rule match) and the final disposition, with edges showing what supported or gated what. Three questions: plausibility (does the path look like how a coder would reason), faithfulness (if an upstream node changed, would the disposition change), ensemble explainability (do independent sources converge on the same path, not just the same answer).

## 7. Human-in-the-loop efficiency

Time per chart before/after: 21 min (30% reduction from a 30-min baseline). Override rate ≤12% sustained over two review cycles (client-defined). Override trend: declining or flat; a rising trend triggers root-cause analysis before the threshold. Automation-bias miss rate (blind re-review weighted toward the auto-accepted bucket): ≥90% of ARIA's real errors caught by coders. "Efficiency gains are never reported without this safety metric alongside them."

## 8. Path to autonomous coding

Every recommendation today goes to a coder before it counts, including pre-accepted codes; "pre-accepting a code and operating autonomously are not the same thing." Autonomous submission is a separate, harder trust decision evaluated on its own evidence. Shadow-mode agreement: Cohen's Kappa >0.85 between ARIA's shadow disposition and the coder's (not raw percent agreement). Violations of the Exceptionally Acute invariant during the shadow period: 0. Quality gate: autonomy, even in limited scope, only once shadow agreement clears its target *and* §7's automation-bias miss rate shows coders are still catching ARIA's errors.

## Appendix B: glossary (selected)

Automation bias; causal-chain graph (shape adapted from a working PoC, `sentinel-loop`, built for a different coding use case); CCL; Clinical Abstractor (the doc refers to 5.1 and 5.2 instead of the name); CTG; Cohen's Kappa; disposition (codeable / needs a coder / drop); ensemble; Exceptionally Acute conditions (nine condition types that, per Aetna's substantiation guide, always require documented MEAT support regardless of chart section); F1; **golden dataset ("the 256 real, de-identified charts with human-coder-confirmed accept/reject decisions that ARIA's accuracy is measured against", Appendix C)**; groundedness; IoU (Appendix F); MRR; precision; RAF; recall; shadow mode; specificity; Symbolic Auditor.

---

## What this means for the data hub (Amit's reading)

1. **The eval tables in our blueprint were a placeholder; this page is their spec.** Every §5 and §6 metric must be computable from our tables at diagnosis-code + date-of-service grain, within HCC category, by chart complexity and chart size, per version. That fixes the gold schema: one row per (chart, encounter, condition/code, DOS, run), with disposition, first failed gate, lane, confidence, coder action and override reason, plus all version keys. The eval job is a data-hub deliverable.
2. **Two 100% invariants are replay requirements on the hub:** reproducibility (same chart + same rules → same disposition) and regression safety (a new rule version flips zero previously-correct charts, checked on every promotion). Both need the golden dataset stored with its coder-confirmed decisions, a replay harness, and a diff report. "Golden dataset" moves from phase 2 to "next" in v6.
3. **Golden dataset facts:** 256 real, de-identified charts with coder-confirmed accept/reject decisions (the architecture page says 200 — ask which); it gates every phase; confirmed errors become permanent test cases, so it grows from the feedback table.
4. **Feedback needs structure:** override reason codes, cycle-over-cycle override rate, blind re-review results (automation-bias miss rate), shadow-mode dispositions logged alongside coder decisions for Kappa. The feedback table in our blueprint gets those columns; shadow-mode means gold stores a disposition even when it is not shown to the coder.
5. **Reference data again:** the RAF weight table is missing today ("not yet computable; needs a RAF weight table") and the ICD-10-to-HCC crosswalk "is confirmed to exist". Both belong in our reference group behind the Lookup API; RAF delta is the one business metric leadership will ask for.
6. **Shadow mode is a data question, not a UI question.** Running ARIA silently next to coders and comparing means the hub keeps ARIA's would-be disposition and the coder's real decision side by side for every chart, from day one of the pilot.
