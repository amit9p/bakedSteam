# P2L Rule Review Design and Build Guide — Reva's Loop doc (read Oct 20, 2026)

Source: 37 phone photos in `D:\Cotiviti\confluence\Photos-1-001-Aria-Reva-doc-policy-store` (10:07–10:12 AM, Oct 20). Photos 1–24 are Reva's Loop page **"P2L Rule Review Design and Build Guide"** (Author: Reva · Status: Draft · Date: 10/19/2026 · Target audience: Engineering), shared in the Teams group chat at 10:05 AM: "My service call is still ongoing… just connected temporarily here… Not sure what you all talked about but am sharing a doc that goes over rule review design and build." Photos 25–36 are a second Loop page, "PRFAQ: Agentic Hub" (see `confluence/prfaq-agentic-hub.md`). Photo 37 is Binod's 10:11 AM Teams message to Reva (added to `meetings/2026-10-20-binod-call-notes.md`).

Sections 1–7 were expanded in the photos and are condensed below, close to Reva's wording. Appendices A–L were collapsed (titles only). The last section, "What this means for the data hub", is mine.

## 1. Introduction

Policy-to-Logic (P2L) reads a payer's coding guideline PDF and produces executable IF/THEN rules, each with a citation to the exact page and text it came from. Coders review those rules. Their feedback improves the next version, and this repeats until the rules converge.

### 1.1 Glossary (Reva's terms; use these from now on)

| Term | Meaning |
|---|---|
| Rule | One IF/THEN statement with plain-English text, a citation (page and verbatim sentence) and machine-checkable logic |
| CRL | The rule format (Clinical Rules Language), the same for every rules engine. Stored as a JSON file (`rules.crl.json`) |
| DRL | The rules engine's own format (Drools Rule Language), generated from CRL by the transpiler. Derived, never edited by hand |
| Snapshot | An unchangeable set of rules produced from one policy document. A revision is a new snapshot, never an edit. Identified by its digest (a content fingerprint, so equal content means equal digest) |
| Fingerprint | A short hash of one review item's content: a rule's logic, a value set's definition and wording, or a claim code set's wording and proposal. A review is tied to it, so a changed item no longer carries the old approval |
| Policy document | One guideline PDF, identified by `content_hash` (sha256 of its bytes). A new edition is a new document. `policy_id` is a stable slug for a guideline family (values in `data/policy_ids.json`) |
| Review item | Something a coder is asked about. Three kinds: a `rule`, a `value_set`, a `claim_code_set`. All three change what a ruleset does, so all three are reviewed in PRM |
| Review | A coder's decision on one review item at one fingerprint (approve, reject, revise, or the codes of a set). Recorded with a pseudonymous `reviewer_token` |
| Reviewed inputs | The approved value sets and claim code sets a snapshot was built with. They are part of the snapshot's content: approving one produces a new snapshot |
| Candidate | A snapshot that has not been promoted |
| Value set | A class of codes a policy mentions but never lists ("the associated organ dysfunction"). Until a clinical reviewer lists the member codes, any check using it is unknown |
| Claim | A statement about a chart that a rule depends on ("the provider documents rheumatoid arthritis"). Today a language model reads the chart to answer it |
| Claim code set | A coder-approved list of diagnosis codes (ICD-10-CM) that answers a claim directly, so no model is needed |
| Decisive rule | A rule the engine can both flag as violated and confirm as satisfied. Unknown parts make a rule less decisive |
| Active ruleset | Which snapshot is in production for a tenant, payer, line of business and date-of-service period. A pointer from those four things to a snapshot digest. It has nothing to do with which coder reviewed what: the reviewer is recorded on each review as a pseudonymous `reviewer_token` |
| Converged | The latest candidate passes the promotion gate (§5.3): every in-scope rule approved, no unresolved inputs, no coder change pending |
| Pilot HCC | The risk-adjustment categories of the first pilot: diabetes, chronic kidney disease and heart failure |
| Tenant | A product or team using P2L (ARIA first) |

## 2. Key notes (verbatim; these are the rules of the game)

1. Agentic Hub owns the data and the backend. CIS builds the coder-facing application in an AWS account (`CIS-1`) and uses coder-review backend API.
2. P2L is a platform service, not an ARIA feature. It lives in atomic-foundations, runs in AWS account (`AF-1`) and serves any product that needs rules extracted from policy documents. ARIA is tenant one.
3. The data hub (lakehouse) is the logical home of all data. Schemas, catalog, governance, lineage and retention for every dataset are defined by the lakehouse standards from day one. Physically, the data starts in PostgreSQL and S3 and moves behind `LAKE-API-1` in stages.
4. A review binds to the exact rule version the coder saw (its content fingerprint). A rule changes, its approval does not carry over.
5. Nothing reaches production unapproved. The API enforces it; it is not a procedure.

What today's code has: the synthesis pipeline, the snapshot and the fingerprint logic, the feedback logic that turns reviews into actions, and scripts for triage. All of it is file-based, local and unauthenticated. What needs building: the PolicyRulesManager service (shared store, authenticated API, job orchestration), a job-only runner around the existing P2L engine, small changes to common clinical data model and rule transpiler, containers and deployments, and migration of the existing Aetna data.

## 3. Architecture (the diagram)

Three AWS accounts, left to right:

- **`CIS-1` (CIS):** the Rule Review App, used by coders/SMEs. Talks to PRM's API.
- **`AF-1` (atomic-foundations):** **Policy Rules Manager (PRM)** — API; stores (policy, rules, feedback, etc.); job orchestration — with **Postgres (PRM schema)**. PRM enqueues jobs on **SQS `p2l-jobs` (+ DLQ)**; the **P2L Engine (job-runner: draft | revise | triage | parse)** reads policy PDFs from **S3 `policy-sources`** and writes staging output to **S3 `staging/` and `work/`** (P2L's); job result, triage result, fetch feedback + parent go back to PRM; PRM promotes `staging/` to **`snapshots/` (PRM only)**. PRM calls the **Rule Transpiler** to validate + compile + digest (compile + rules-digest).
- **`DH-1` (data hub):** **Lakehouse** and **Lakehouse API**. Postgres → "nightly export" → Lakehouse; S3 → "catalog" (dashed) → Lakehouse; PRM → "after cutover" → Lakehouse API.

### 3.1 The three parts

| Part | What it does | Status today |
|---|---|---|
| PRM | The one API: register policies, ask for drafts and revisions, run quality checks, take coder reviews, enforce the approval gate, say which ruleset is in production. System of record | Does not exist |
| P2L engine | Writes the first draft, revises it from coder feedback, runs quality checks. Runs as short-lived jobs | Works on a laptop; no service wrapper |
| rule-transpiler | Compiles rules into the rules engine's format; the authority on rule fingerprints (digests) | Works; needs one new endpoint |

Key terms recap (Reva's): a snapshot is an unchangeable set of rules from one guideline; a revision is a new snapshot, never an edit. A fingerprint (digest) is a hash of content, so equal content means equal fingerprint. The active ruleset is the snapshot currently in production for a given payer and period.

## 4. Where the data lives: tactical now, strategic later

"Data falls into three classes. Only one moves."

| Class | Examples | Now (tactical) | Later (strategic) |
|---|---|---|---|
| Files | Guideline PDFs, rule files, working files | S3 | Same S3, registered in the lakehouse catalog. Does not move |
| Records | Reviews, rule index, quality-check results, review questions | PostgreSQL | Lakehouse tables, written through its API (`LAKE-API-1`). This is what moves |
| Control data | Which ruleset is in production, jobs, promotion requests | PostgreSQL | Stays in PostgreSQL. Needs instant, consistent reads |

Why not wait for the lakehouse? "Its write API does not exist yet, has no date, and a coder's review save needs an immediate, reliable answer. We build behind store interfaces, copy records to the lake nightly so analytics work from day one, then move in three steps: **Tactical** (PostgreSQL is the source of truth, nightly copy to the lake), **Bridge** (write to both and compare), **Strategic** (the lake is the source of truth). Each step has exit criteria (Appendix B). If no `LAKE-API-1` date exists when the tactical phase is done, we escalate; otherwise 'tactical' quietly becomes permanent and we have two sources of truth."

## 5. How it works

1. **Register.** An engineer uploads the guideline PDF to PRM. PRM queues a "draft" job.
2. **Draft.** A P2L job builds the rules (Textract and Bedrock) and reports the result to PRM.
3. **Store.** PRM checks that the rules compile, fingerprints them and stores them as an unchangeable snapshot.
4. **Quality checks.** Another job runs automatic checks. Rules that fail go to engineering. The rest go to coders, along with questions that need clinical judgment (a class of codes the guideline never lists, or which codes mean "documented").
5. **Review.** Coders, in the CIS application (which calls PRM), approve, reject or revise each item.
6. **Revise.** P2L applies the feedback and produces a new snapshot. Only changed items go back to coders. Repeat until every in-scope item is approved.
7. **Promote.** A second person signs off and PRM marks the snapshot as the one in production.
8. **Use.** ARIA asks PRM which ruleset is active and fetches the compiled rules.

## 6. Why this is harder than it looks ("Read this before estimating anything")

1. None of the three existing components is production-grade. P2L, rule-transpiler and clinical-commons run on local files with no authentication, and none is in a shared repository. Every engineer starts blocked until the code push is done.
2. The rules come from a language model, so "just re-run it" is dangerous. Output varies from run to run. A fix must be proven with at least two re-runs. A past full re-run lowered measured rule faithfulness from 79% to 73% because rules that were already settled got re-drawn. Runs are slow and cost real money.
3. A decision must be reproducible years later. That needs exact fingerprints of rules, unchangeable snapshots, and stored compiled rules (not stored today). Mistakes here are silent and found late.
4. Policy prose is not written to become rules, and there is no recipe to copy. The ones that cost most: soft words vs hard rules ("may be coded" is a permission, not a requirement), exceptions and negatives ("unless", "except", "not sufficient" are easy to lose), time and sequence ("counts as acute for 28 days", "at the same visit") that the rule language can't yet express, dozens of cross references unable to resolve, one in five rules needing human review for faithfulness.
5. Policy text is licensed. Verbatim sentences sit inside every rule file. A legal restriction would change P2L, not just the new service.
6. Three components must change together. clinical-commons, rule-transpiler and P2L depend on each other in one direction. Changing how rules are fingerprinted touches all three, and each has its own tests.
7. Key pieces do not exist yet, so there is nothing to estimate them against: PRM itself, the job runner, the step that turns approved code sets into rules, and the lakehouse write API (date unknown, owned by the data engineer).

## 7. How the work is divided

**7.1 Prerequisite: the code push.** The three repositories must reach a shared remote before any other engineer can contribute. Reva is working on it with Security and Legal. Streams that need no code (contracts, infrastructure, Clinical Ops decisions) can start on day 1.

**7.2 Milestones (exit criteria, not dates)**

| Milestone | Exit criteria |
|---|---|
| M0 Foundations | Code is in the shared remote and a new engineer can clone, install and run the tests. The four contracts are frozen: API specification, job message schemas, store interfaces, access and configuration matrix. CIS can start against a mock |
| M1 PRM in dev | PRM runs in a dev environment with the Aetna rules and reviews loaded. Authentication and tenant-isolation tests pass. CIS can list rules and submit a review against the real API |
| M2 The loop works in dev | Draft, quality checks, review and revise run end to end on a small test policy, and a retried job gives identical output. The integration test is green nightly |
| M3 First real cycle | Coders review the pilot-category items of one guideline (Aetna) through CIS. A revised snapshot is produced with no unreviewed regression. Clinical Ops confirms the review experience is usable |
| M4 Production use | The approval gate passes with real approvals, ARIA reads the active ruleset in production, and a past decision replays identically |

On dates (Reva): about 65 engineer-days of focused effort across the work packages (Appendix K). The longest chain that cannot run in parallel is about 30 working days (roughly six weeks): code push, packaging, storage, API, data migration, hardening. That is a floor, before integration problems, rework and review. M3 and M4 depend on coders' time, legal clearance and quality evidence, which engineering does not control, so no date is committed for them.

**7.3 Streams** ("each stream can be owned by one person and runs independently once its inputs exist. Streams meet at agreed contracts, not at each other's code")

| Stream | Work | Skills | Starts when | Delivers |
|---|---|---|---|---|
| A. Code home | Push the three repos, clean history, licensing clearances | Reva | Day 1 | A shared remote with clean repos |
| B. Contracts | API spec, job schemas, store interfaces, access matrix | Backend lead | Day 1 (documents only) | Four frozen contracts |
| C. Platform | Environments, queue, database, buckets, deploy pipeline | Infrastructure | Day 1 | Dev, stage, prod environments |
| D. Commons and compiler | Packaging, shared digest function, new compile endpoint, stored compiled rules | Python | After A | Versioned shared library; updated transpiler |
| E. PRM service | Storage, API, migration of existing Aetna data | Backend, PostgreSQL | After A and B | PRM running in dev with real data |
| F. P2L engine | Job runner, quality checks, applying reviewed inputs | Python, LLM | After A and B; builds against a fake PRM | Runner image, quality checks, applier |
| G. CIS enablement | Mock, examples, dev tenant, weekly integration checks | Backend, liaison | After B | CIS building against the mock, then dev |
| **H. Data bridge** | **Nightly copy to the lake; later the move to the lake** | **Data engineer** | **After E's schema exists** | **Reconciled lake tables** |
| I. Clinical Ops and Product | Sign-off model, reason codes, which items coders review first, coder time | Clinical Ops, Product | Day 1 | Decisions; coders ready for M3 |
| J. Hardening | Load, restore, alarms, threat-model review | Infrastructure, backend | After C, E, F reach dev | Evidence for M4 |

Work-package map (hand-drawn diagram): A Gate, code-only push → D Commons + compiler (WP1, WP2) → F P2L engine (WP5, WP6, WP7). B Contracts (WP0c) → C Platform (WP9), E PRM service (WP3, WP4, WP8), G CIS enablement (WP11b). E → H Data bridge (WP10; WP12 later). C, E, F → J Hardening (WP11a). I Clinical Ops + Product decisions feed E and F.

**7.4 What more people can and cannot do.** Parallelizes: platform, commons and compiler, P2L engine, CIS enablement and the data bridge. Does not: the main chain (code push, packaging, storage, API, integration) and coder review; adding engineers does not shorten either. Useful team size: about three engineers (backend; Python and language-model work; infrastructure) plus the data engineer on the bridge. "Do not divide the total effort by headcount."

**7.5 Scope.** Never cut: the approval gate and its enforcement; unchangeable snapshots and fingerprint-tied reviews; authentication and tenant isolation; the shared contract tests; keeping secrets, licensed documents and chart data out of repositories and logs. Cut first, if we must: the rejection-pattern view; the nightly lake copy (a manual export is acceptable at first); the step that turns approved code sets into rules (claims keep being answered by the model, as today); Humana (Aetna first). "Scope goes before quality or safety does."

**7.6 Working agreements.** Work to exit criteria, not dates; raise a slip the first time it is visible. Contracts first; a contract changes only when both sides agree. Every work package ships with its tests; "done" means the Appendix K acceptance criteria pass. Never hand-edit a rule (fix the generator). No secrets, licensed PDFs or chart data in git. Never disable authentication to make a test pass. Ask before large model runs. When something is unclear, ask Reva early; several parts of the codebase are subtle.

## 8. Appendices (collapsed in the photos; titles only)

A Glossary · B Tactical and strategic data plan (detail) · C Architecture (detail) · D How a review stays tied to what the coder saw · E Lifecycle (diagrams and steps) · F How feedback reaches P2L · G Data model · H API · I Deployment · J Security and licensing · K Work packages and execution streams (detail) · L What exists in code today.

To read next, in this order: G (data model: the tables the lake will copy), B (exit criteria for tactical → bridge → strategic), H (API), K (work packages, incl. WP10/WP12 for the data bridge).

---

## What this means for the data hub (Amit's reading, Oct 20)

**1. The policy store is Reva's, not ours.** In this design the system of record for policies, rules, reviews and "which ruleset is live" is **PRM**: Postgres + S3 in account `AF-1`, behind an authenticated API. CIS's Rule Review App calls that API. Our five tables (`policy_document`, `rule_set`, `rule_set_version`, `rule`, `rule_review`) with data-hub register/load jobs and the review tool writing table 5 through a SQL endpoint describe a different system. Keep `aria/policy-store-tables-v0.1.md` as our thinking; do not build it as the system of record.

**2. Our part is Stream H, "Data bridge".** A nightly copy of PRM's records (reviews, rule index, quality-check results, review questions) into lake tables, reconciled against Postgres; later the move of those records to the lake (Strategic). It starts "after E's schema exists", so it waits for Reva's PRM schema (Appendix G) to be frozen in Stream B. Reva's own cut-first list allows "a manual export at first". Until the schema exists, our job is key note 3: define the lakehouse standards (schema and table naming, catalog registration of the S3 buckets, governance, lineage, retention) for the policy datasets, from day one.

**3. `LAKE-API-1` is ours and it is new.** "The lakehouse write API (date unknown, owned by the data engineer)." Reva says he will escalate if it has no date when the tactical phase ends. We have never discussed building a write API, and on Databricks it is not obvious what it is: the SQL Statement Execution API over a SQL warehouse works for nightly copies but not for a coder's "save review" that needs an immediate, consistent answer; Databricks' managed Postgres (Lakebase) registered in Unity Catalog could let PRM's Postgres live inside the lakehouse, so tactical and strategic become the same thing (check with Yesh whether the workspace has it); or Records stay in Postgres and the lake only ever holds copies (the "two sources of truth" Reva wants to avoid). This is a design-review question, not one to answer alone.

**4. Our version keys change.** A gold row must record the **snapshot digest** and the **rule fingerprint** (plus the active-ruleset pointer: tenant, payer, line of business, date-of-service period), not a `rule_set_version` id and an APPROVED flag. Our DRAFT → REVIEWED → APPROVED → RETIRED model becomes candidate → converged → promoted (active), with immutable snapshots. The auditor (box 6) gets the active ruleset and the compiled rules from PRM's API (step 8, "Use"), not from our tables.

**5. Three things in v6 are wrong now** (not changed yet; see proposal in the chat): the "Policy Store · 5 tables" box in our lane should become "PRM: policy store of record (Reva, `AF-1`: Postgres + S3 + API)" in the AI-components lane, with a "nightly copy" arrow into a "policy lake tables (copy)" box in our lane; the "Policy tool (D)" box should become "Rule Review App (CIS, `CIS-1`)" in the CIS lane, calling PRM's API; the letters A–E should become Reva's eight steps. `aria/policy-store-flow.html` (setup/register/load jobs) should be retired in favour of the eight-step flow; `aria/policy-store-tables-v0.1.md` gets a "superseded by PRM's data model" note and the mapping below.

**6. What stays true.** The chart path 1–9, bronze/silver/gold, the CTG store, the Explain API and the Lookup API over reference data are untouched by this doc. Key note 3 is also the best answer to Binod's "why a data hub": the lakehouse is the logical home of all data, with schemas, catalog, governance, lineage and retention defined there even when the bytes start in Postgres and S3.

**7. Dates.** Reva commits to exit criteria, not dates: about 65 engineer-days, a six-week floor on the main chain, PRM "does not exist", M3/M4 undated. Binod's "data before October 30" can only be met by M0 (frozen contracts + the Stream G mock), not by real rules from PRM. That is Reva's call to make with Binod; in the data-side task inventory our policy line should read "lake copy of PRM's policy tables: after PRM's schema is frozen; manual export first, nightly job later".

### Mapping: our v0.1 tables → Reva's design

| Ours (`policy-store-tables-v0.1.md`) | Reva's |
|---|---|
| `policy_document` + PDF in a Volume folder | Policy document: `content_hash` (sha256), `policy_id` slug (`data/policy_ids.json`); PDF in S3 `policy-sources` |
| `rule_set` (client, payer, year → current version) | Active ruleset: pointer (tenant, payer, line of business, DOS period) → snapshot digest. Control data; stays in Postgres |
| `rule_set_version` (DRAFT → REVIEWED → APPROVED → RETIRED) | Snapshot: immutable, identified by digest; candidate → converged → promoted. S3 `snapshots/` + Postgres index; compiled DRL stored too |
| `rule` (one row per rule in a version) | Review items: `rule` (CRL, fingerprint) + `value_set` + `claim_code_set`; reviewed inputs are part of the snapshot |
| `rule_review` (verdict per coder per rule) | Review: bound to one fingerprint; approve / reject / revise / codes of a set; `reviewer_token` |
| register job, load job (data hub) | PRM API (Register) → P2L job-runner (Draft, Revise, triage, parse) → PRM (Store, Promote) |
| policy tool writes table 5 via SQL endpoint | CIS Rule Review App → PRM API → Postgres |
| Volume `policy/{landing, documents/<id>, rules/<id>}` | S3 `policy-sources`, `staging/`, `work/` (P2L), `snapshots/` (PRM only) |
| (nothing) | Stream H: nightly copy of Records to lake tables; `LAKE-API-1`; catalog registration of the S3 buckets |
