# PRFAQ: Agentic Hub — leadership's framing of the platform ARIA sits in (read Oct 20, 2026)

Source: photos 25–36 of `D:\Cotiviti\confluence\Photos-1-001-Aria-Reva-doc-policy-store` (10:10–10:11 AM, Oct 20). A read-only Loop page "PRFAQ: Agentic Hub" (listed under Recent pages as Sep 9), next to "ARIA Architecture" (Oct 12), "ARIA Evaluation Methodology" (Oct 1) and Reva's P2L guide. Amazon-style PRFAQ: a press release dated April 12, 2027, contact "Cotiviti AI Innovation Team", then internal and customer FAQs and two appendices. Author not shown. Quotes attributed to **Sundararaman Shenbagam, CTO of Edifecs** and **Cloud Xia, VP in AI Innovation** (Surya's boss). Internal portal named: https://innovation.cotiviti.com/agentic-hub.

Why it matters to us: this is the vocabulary leadership (Sundar, Cloud) uses for the whole programme. ARIA is one "kit" built from the Hub's "engines"; the data hub is the "Data Mesh / Clinical Lake" box at the bottom of the stack. It is also leadership's own answer to Binod's "why a data hub?".

## Press release (condensed)

"Cotiviti Unveils 'Agentic Hub': The Foundational AI Platform Powering the Future of Clinical and Payment Integrity." A suite of foundational AI services to move the company from "data-extractive" NLP to "autonomous" clinical workforces. Built on the internal AI Innovation Platform; lets Business Units (BUs) deploy agent-led workflows that identify errors in the healthcare ecosystem and resolve them with minimal human intervention. The industry's "reading charts post-payment" model has diminishing returns (administrative friction, recovery leakage); the Hub provides "digital hands and brains" to act on clinical insights immediately.

Dual-layered architecture: **Atomic Foundations** (core, reusable AI engines built once for the enterprise, e.g. the Policy-to-Logic reasoning engine and the Autonomous Clinical Abstractor) assembled into **Composite Business Solutions** (use-case kits, e.g. the Prospective Clinical Chart Validator, CCV). "Shadow and Prove" mandate: the Hub first runs in parallel with incumbent NLP solutions to baseline performance and accuracy; where it proves superior it systematically replaces legacy tools.

The Autonomous Clinical Abstractor is called "a strategic game-changer": a "digital clinician" reasoning through hundreds of pages of fragmented records to build a structured **Clinical Truth Graph**, mastering temporal context ("history of" vs "active diagnosis"). The platform uses **Automated Reasoning** and **Knowledge Graphs** so every clinical determination is explainable and defensible.

Sundar: "Our legacy NLP systems are world-class 'readers,' but the market now demands 'doers'… wrapping them in an autonomous orchestration layer, we are effectively giving our BUs a 10x multiplier on throughput without a 10x increase in headcount." Cloud: "This isn't just a technology upgrade; it's a capital efficiency play."

## Internal FAQ (leadership and stakeholders)

- Q1 Why a centralized Hub instead of BUs enhancing their own NLP? Siloed solutions create redundant "innovation taxes". The Hub is a horizontal utility layer: build foundational services once (ADR automation, medical necessity determination), amortize across BUs, cut time-to-market for new audit types by 60%.
- Q2 Leakage: move Clinical Chart Validation into the pre-payment window; captures 100% of identified value, removes the 90-day recovery lag.
- Q3 Financial justification: 40% improvement in operational leverage; lower COGS through reusability; one clinician oversees the output of a digital workforce.
- Q4 Hallucinations: "Deterministic Orchestration" (predefined paths); "Automated Reasoning" evaluates every agent response against codified policy logic; a violation of a Medicare coverage constraint is flagged before it reaches a human or provider.
- Q5 Explainability: Knowledge Graphs map clinical facts (records) to policy requirements (CMS); a "Chain of Thought" audit trail as a structured graph showing which evidence triggered which rule.
- Q6 Atomic vs Composite: engines (Medical Necessity Reasoning, Policy-to-Logic) built by the Innovation Team; kits (CCV, Dispute Agent) built by combining them.
- Q7 Policy-to-Logic uses Automated Reasoning to convert Medicare policies into executable logic gates; a determination is "a verified outcome", not a guess.
- Q8 Explaining a decision to a resistant BU or provider: the graph shows which clinical fact (Node A) triggered which policy rule (Node B); replaces "black box" AI with a graph-based audit trail.

## Customer FAQ (BUs and providers) and "Legacy integration and BU autonomy"

"Integrate-First": legacy NLP is an "Expert Tool" / "Extractor"; the Hub is the "Executor" ("Wrapping, not Ripping"). Legacy NLP becomes a tool the agent calls and stays the "Source of Truth" for data extraction (example: NLP extracts the ICD-10 code; the Hub looks up the Medicare coverage policy, compares to the notes, writes the appeal letter). The Sentinel Loop gives providers real-time "nudges". BU experts author agent workflows in a "no code" visual interface: "You own the Domain Logic; we provide the Execution Fabric."

## Appendix A: the stack (diagram, top to bottom)

1. **Business Units ("The Value")**: Payment Integrity, Risk Adjustment, Provider Relations, Audit & Compliance. Primary internal customers who own the P&L; they consume the Hub's outputs.
2. **Composite Business Solutions ("The Kits")**: Prospective CCV, Coding Validator, ADR Coordinator, Provider Nudge, Dispute Agent, Trend & Insights Agent.
3. **Atomic Foundations ("The Engines")**: Reasoning & Explainability (Automated Reasoning Engine, Policies, Clinical Knowledge Graph); Policy-to-Logic Engine; Anomaly & Sentinel Loop; Medical Necessity Engine; Sentinel Loop; Autonomous Clinical Abstractor; Compliance & Audit Trail. "Every decision is grounded in clinical truth and strictly conforms to codified payer policies."
4. **Agent Builder ("The Orchestration")**: Workflow, Workforce, Memory, MCP Integration, HITL, Trace/Explainability. The workspace for clinical and technical teams to design, manage and deploy agents; the "plumbing" (workflow logic, memory, MCP integrations that let agents use legacy NLP as tools).
5. **Foundational Infrastructure & Assets**: **Data Mesh / Clinical Lake**, **MLOps & Governance**, **Legacy NLP**. "Provides the essential data, security, and governance rails that allow the Hub to scale safely within a healthcare environment. It integrates our Data Mesh and Clinical Lake with industrial-grade MLOps and secures the connection to our existing legacy NLP investments."

## Appendix B: service catalog

Tier 1, Atomic Foundations (engines):

1. Policy-to-Logic Engine ("The Brain"): policies trapped in large, frequently updated PDFs → Automated Reasoning converts natural-language rules into executable logic gates → 100% standardized application of policy, near-zero lag between a policy change and audit implementation.
2. Autonomous Clinical Abstractor: 500-page charts, legacy NLP misses context ("history of" vs "active") → Knowledge Graphs map clinical entities into a "Truth Graph" preserving temporal relationships → 40% improvement in operational leverage by automating the first pass.
3. Medical Necessity (Reasoning) Engine: a human must hold policy and chart in their head at once → a core reasoning service compares the Clinical Truth Graph (#2) against the logic gates (#1) for a pass/fail determination → 10x reviewer throughput; experts move from "finding" evidence to "verifying" agent findings.
4. Anomaly & Sentinel Loop: outliers found months late → real-time sentinel compares claim streams to Knowledge Graph benchmarks → leakage prevented before funds are dispersed.
5. Compliance & Audit Trail Sentinel (Explainability): "black box" risk → logs the Chain of Thought for every decision, mapping which clinical fact triggered which policy rule → 100% auditability; Explainable-AI requirements met.

Tier 2, Composite Business Solutions (kits):

6. Prospective Clinical Chart Validator (CCV): composite of #1, #2, #3; validates documentation before adjudication; "Debt Collection" → "Transaction Integrity".
7. **Coding Accuracy Validator (ICD/CPT/DRG/HCC)**: legacy NLP tags codes but doesn't reason whether the evidence supports the code level (upcoding, DRG creep) → combines the Abstractor (#2) and Policy Engine (#1) to validate reported codes against clinical evidence and official coding guidelines → fewer overturned appeals, "Audit Defensibility".
8. Dispute & Appeal Agent: uses the Audit Trail (#5) to auto-generate evidence-backed rebuttals citing page and paragraph.
9. ADR & Record Retrieval Coordinator: monitors portals, finds missing pages via OCR, assembles audit-ready packages.
10. Provider "Nudge" & Education Loop: point-of-action nudges using the explainability layer (#5).

## Where ARIA and the data hub sit (my reading, not stated on the page)

ARIA matches kit #7, the Coding Accuracy Validator (HCC): engines #1 (P2L, Reva's) and #2 (the abstractor, Reva's), a #3-style reasoning step (our "auditor"), and #5 (the audit trail: our gold rows, CTG store and Explain API). The data hub is the "Data Mesh / Clinical Lake" box in layer 5, with "MLOps & Governance" next to it. Three lines from this page answer Binod's "why not just two services talking?": the Hub promises a stored, graph-based audit trail for every decision (#5, Q5, Q8); "Shadow and Prove" means running in parallel with legacy NLP and comparing results, which needs the outputs kept; and layer 5 exists to give "data, security and governance rails". None of that works if results only pass through a queue.
