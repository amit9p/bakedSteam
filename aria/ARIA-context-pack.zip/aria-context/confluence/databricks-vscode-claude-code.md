# Cotiviti Confluence — Databricks + VS Code + Claude Code (five documents)

Source: 33 phone photos in D:\Cotiviti\confluence\Photos-1-0012 (taken Sep 22, 2026, ~11:03–11:07 AM CT) of Confluence pages in the MLSA space (`…/wiki/spaces/MLSA/pages/244655276/Databricks+VS+Code+Claude+Code`) and two Word documents linked from them. Transcribed by Claude on 2026-09-22. Small details that were hard to read off the monitor are marked "as best read". A follow-along guide adapted for Amit's Windows laptop is in `guides\setup-guide-vscode-databricks-claude-code-windows.md`.

Documents captured:

1. **Claude Code on Databricks** — Jonathan Dehdari, May 06, 2026 (run Claude Code inside a Databricks web terminal; no local install)
2. **Databricks + VS Code + Claude Code — Complete Unified Workflow Guide for AI Engineering** — Sanket Zanwar, May 05, 2026 (the main local-setup doc; written on a Mac)
3. **Fix SSL Error for Claude Code with VS Code** — Cotiviti Security Engineering, v1.0 April 2026 (Word doc "Claude Code SSL Fix in VSCode.docx"; Zscaler certificate fix)
4. **Integrating Claude Code with VS Code (Windows)** — Word doc "Integrating_Claude_Code_Windows_Final.docx" (VS Code extension + settings.json)
5. **Piloting Claude Code in Databricks** — Alaa Youssef, Jan 30, 2026 (Discovery Week feedback guide + best practices)

Not photographed (titles seen in the sidebar, probably overlapping content): "Claude Code Setup — Windows (Global + Zscaler Fix)", "Claude Code on Native Anthropic Endpoints - MAC", "…extension in VS code - Login Prompt Fix", "Connection Setup Guide", "How do I get Access?".

## Key facts across all five (the short version)

- The AI-engineering workspace is **AWS Databricks**: host `https://dbc-0fa270fd-fb38.cloud.databricks.com/`, workspace name **ai-engineering-dev**, reached via https://sso.cotiviti.com → Databricks icon. (This answers the open question in yesterday's CI/CD notes — the Azure workspace in those 2024 screenshots was a test workspace.)
- Claude Code at Cotiviti talks to **Databricks model serving, not Anthropic's public API**: `ANTHROPIC_BASE_URL=https://dbc-0fa270fd-fb38.cloud.databricks.com/serving-endpoints/anthropic`, header `x-databricks-use-coding-agent-mode: true`, and a Databricks token (`dapi…`) as `ANTHROPIC_AUTH_TOKEN`. The token comes from Serving → Integrate coding agents → Get Started → Other integrations → Claude Code → Generate API key.
- Model endpoint names seen in the docs: `databricks-claude-haiku-4-5`, `databricks-claude-sonnet-4-5`, `databricks-claude-sonnet-4-6`, `databricks-claude-opus-4-5`, `databricks-claude-opus-4-7`. Guidance: start with Haiku/Sonnet, Opus only when needed; switch with `/model`.
- Local dev loop (Sanket): VS Code + Databricks extension (PAT auth, personal single-user cluster, `.venv` with `databricks-connect` matching the cluster DBR, live sync of saves to `/Workspace/Users/<you>/.bundle/<repo>/dev/files`) + code in Bitbucket + Claude Code in the VS Code terminal.
- **Kerberos/HDFS auth must be run in a browser notebook on the cluster, once per session** — it uses Py4J internals that Databricks Connect can't reach. It needs a per-user keytab at `/Volumes/ai_engineering_dev_catalog_1688890232235261/user_<first_last>/personal/<first.last>.keytab`.
- Windows-specific: the Claude Code **VS Code extension** is configured through `settings.json` (`claudeCode.environmentVariables`, `claudeCode.disableLoginPrompt`), Git Bash path may be needed, and **Zscaler** breaks Node's TLS until `NODE_EXTRA_CA_CERTS` points at the exported Zscaler root cert.
- Python 3.10 or 3.11 only (3.12+ has databricks-connect compatibility issues); Node.js 18+ only needed for the CLI install via npm.
- Security expectation: a `CLAUDE.md` in the working directory (the "Sample Claude.md Rules File" from SharePoint; a more routinely updated copy lives in the internal "Cotiviti Github Agents Repo").

## People

- **Sanket Zanwar** (sanket.zanwar@cotiviti.com) — author of the unified workflow guide; AI Engineering; his cluster "Sanket Zanwar's DS_PowerCompute Cluster", profile `SZ_vscde`, repo folder `DBX_bitbucket`.
- **Jonathan Dehdari** — author of "Claude Code on Databricks" (May 2026).
- **Alaa Youssef** — ran the Claude Code Discovery Week (Jan 2026).
- **Mezel Smith** (mezel.smith@cotiviti.com, as best read) — owns `/Workspace/Users/mezel.smith@cotiviti.com/Admin/ai_coding_rules_files/claude/claude.md`, the shared CLAUDE.md rules file.
- Security Engineering team — wrote the Zscaler SSL fix.

---

## Doc 1 — Claude Code on Databricks (Jonathan Dehdari, May 06, 2026)

Sections: Installation Instructions · Security · Models. This is the "no local install" route: Claude Code runs in the web terminal of a Databricks cluster.

### Installation Instructions (verbatim order)

1. Ensure you can access Databricks (see "instructions here" link), then go to https://sso.cotiviti.com and click the Databricks icon.
2. Choose the **ai-engineering-dev** workspace.
3. Left panel, very bottom → **Serving**.
4. Near the top-left, **Integrate Coding Agents** → **Get Started**.
5. **Other Integrations** → drop-down → **Claude Code**.
6. Set the default model as Claude Sonnet to start with (see Models).
7. **Generate API Key**.
8. Click the eye icon to reveal the key in the JSON text; copy the JSON somewhere temporary (e.g. Notepad).
9. (For Claude Code with VS Code on Windows, see `Integrating_Claude_Code_Windows_Final.docx` — Doc 4 below.)
10. Left panel → **Workspaces** → top-right **Create** → **File**.
11. Paste the following into the file (may need "paste as plain text"):

```bash
export PATH="$HOME/.local/bin:$PATH"

export ANTHROPIC_BASE_URL='https://dbc-0fa270fd-fb38.cloud.databricks.com/serving-endpoints/anthropic'
export ANTHROPIC_MODEL='databricks-claude-sonnet-4-6'
export ANTHROPIC_SMALL_FAST_MODEL='databricks-claude-haiku-4-5'
export ANTHROPIC_CUSTOM_HEADERS='x-databricks-use-coding-agent-mode: true'
export CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC=1
export DISABLE_TELEMETRY=1
export ANTHROPIC_AUTH_TOKEN='dapi...'

claude() {
    if which claude >/dev/null 2>&1; then
        command claude "$@"
    else
        curl -fsSL https://claude.ai/install.sh | bash -s 2.1.86 && command claude "$@"
    fi
}
```

12. Replace the `ANTHROPIC_AUTH_TOKEN` value with the token from the JSON (starts with `dapi`).
13. Rename the file (click the "Untitled File…" tab) to **`.bashrc`** — include the leading dot.
14. Left panel → **Compute** → create a compute if you haven't; give it a sensible timeout (30 or 60 minutes).
15. **Workspaces** → **Create** → **Notebook** (can stay empty).
16. Top-right may show **Serverless**; you can instead attach the compute you created. Serverless starts faster and is fine for light work; use your compute for heavy CPU/GPU work.
17. Run the empty notebook (play). If a terminal icon appears near the bottom-right, click it; otherwise click the terminal tab just below the notebook.
18. Install Claude Code (or Opencode, Mistral Vibe, etc.) following the Linux instructions. With the `.bashrc` above, Claude Code installs itself the first time you run `claude`.
19. `mkdir myproject; cd myproject` (or wherever you want to develop).
20. Run `claude`. If it isn't on the PATH, run `~/.local/bin/claude`.
21. It asks for a color scheme (default is fine) and permission to read the working directory (fine).
22. Read the official Quickstart and docs.

SSL fix guide linked here: "Claude Code SSL Fix in VSCode.docx" (Doc 3).

### Security

In your working directory make sure there is a file called `Claude.md`; its contents come from the linked page, section "Sample Claude.md Rules File".

Info box "Periodic Updates to CLAUDE.md": an internal GitHub repo ("Cotiviti Github Agents Repo") holds a CLAUDE.md that is updated more routinely than the SharePoint copy. It may (nothing explicitly stated) make sense to clone that repo into Databricks, pull updates regularly, and have Claude Code use it as the global user-instructions file. Example: add this line inside the `claude()` function in `.bashrc`, before the `if`:

```bash
ln -sf "/Workspace/Users/mezel.smith@cotiviti.com/Admin/ai_coding_rules_files/claude/claude.md" "$HOME/.claude/CLAUDE.md"
```

This points Claude's global `~/.claude/CLAUDE.md` at the version-controlled copy in the workspace. You don't have to keep the repo in that exact place (you likely need a folder you have access to).

### Models

Haiku — fastest, cheapest, fine quality. Sonnet — fairly fast, moderately priced, pretty good quality. Opus — slow, expensive, very good quality. Change the model by editing `ANTHROPIC_MODEL` in `.bashrc` to one of `databricks-claude-haiku-4-5`, `databricks-claude-sonnet-4-6`, `databricks-claude-opus-4-7`, then `source .bashrc` and restart Claude Code. Check the current model inside Claude Code with `/model`.

---

## Doc 2 — Databricks + VS Code + Claude Code: Complete Unified Workflow Guide for AI Engineering (Sanket Zanwar, May 05, 2026)

Table of contents: Prerequisites · Connect VS Code to Databricks · Pull Your Projects from Bitbucket · Cluster Start & Kerberos Authentication · Local Environment (.venv) Setup · Claude Code Setup · The Daily Workflow · Troubleshooting · Quick Reference Card. All example paths are Mac (`/Users/sanket.zanwar/…`, `~/.zshrc`).

### Prerequisites

| Tool | Version | Install |
|---|---|---|
| Python | 3.10 or 3.11 (recommended) | python.org |
| Node.js | 18+ | nodejs.org — required for Claude Code |
| Git | any recent | git-scm.com |
| VS Code | latest | code.visualstudio.com |

Note: Python 3.12+ may have compatibility issues with `databricks-connect`. Stick to 3.10 or 3.11 unless confirmed otherwise.

### 1. Connect VS Code to Databricks

Do this first — before touching Bitbucket or any local files. The VS Code extension is the bridge between your machine and the workspace.

1a. Gather credentials. Host URL = the workspace URL up to and including `.com/`, e.g. `https://dbc-0fa270fd-fb38.cloud.databricks.com/` (nothing after the domain). Personal Access Token: Databricks → Settings > Developer > Access Tokens → Generate New Token (description + expiry) → copy immediately, it is not shown again.

1b. Configure the extension: install the **Databricks** extension from the VS Code marketplace → click the Databricks icon in the sidebar → **Configure Databricks** → enter Host URL and PAT. You then see clusters, workspace files and sync state from VS Code.

### 2. Pull Your Projects from Bitbucket

Flow: Databricks → push to Bitbucket (one-time, in browser) → `git clone` locally → develop in VS Code from now on.

2a. One-time, in the browser: Workspace tab → your project folder → **Add > Git Folder** → provider **Bitbucket**, paste the repo URL (the repo must already exist; create an empty one first if needed) → **Create Git Folder** → use the Git panel to commit and push.

2b. Clone locally: `git clone https://bitbucket.org/your-org/your-repo.git /Users/sanket.zanwar/DBX_bitbucket` then `cd` into it. (The URL is a placeholder — Cotiviti's server is bitbucket.cotiviti.com; copy the real URL from the repo's Clone button.)

2c. Point the extension at the clone: Databricks extension sidebar → **Local Folder Mapping** → path of the cloned repo. From then on every file save is synced to Databricks automatically. "Develop entirely in VS Code. Use `git pull` to get updates, `git push` to share them. The Databricks browser is only needed for Kerberos auth — not for writing code."

What a correctly configured extension panel looks like (screenshot):

```
DATABRICKS › CONFIGURATION
  Local Folder   /Users/sanket.zanwar/DBX_bitbucket
  Target         dev
  Auth Type      Profile 'SZ_vscde'
  Cluster        Sanket Zanwar's DS_PowerCompute Cluster 2026-02-17 11:05:07   [▷ start]
    Cluster ID           0217-160546-bjdk9ats
    Databricks Runtime   16.x.x
    Creator              sanket.zanwar@cotiviti.com
    Access Mode          SINGLE_USER - sanket.zanwar@cotiviti.com
    [x] Override Jobs cluster in bundle
  Remote Folder
    Path        /Workspace/Users/sanket.zanwar@cotiviti.com/.bundle/DBX_bitbucket/dev/files
    Sync State  STOPPED
  Python Environment
    Active Environment: .venv
    Databricks Connect: 16.1.2
```

Things to verify: Local Folder = your clone; Target = `dev` (or your team's environment); Auth Type = your profile name; Cluster = your personal cluster (this is what you click ▷ to start; ■ appears once running); Cluster ID confirms the right cluster; Databricks Runtime should match the `databricks-connect` version in `.venv`; Active Environment `.venv`; Databricks Connect version green/checked; Sync State `STOPPED` at rest, `IN PROGRESS` while syncing a save.

### 3. Cluster Start & Kerberos Authentication

HDFS access (via Kerberos) must be initialized each session. Recommended: start the cluster from VS Code (faster), then run the auth block once in a Databricks browser notebook.

Why the browser: `init_hdfs_kerberos()` calls Java/Py4J internals tied to the active Spark session on the cluster. In a notebook it targets the right session automatically; via Databricks Connect there is no Py4J gateway, so it fails.

Step A — start the cluster in VS Code: Databricks extension → Configuration pane → your cluster → Start → wait for Running.

Step B — in a browser notebook attached to that cluster, run:

```python
import os
import numpy as np
import subprocess

def init_hdfs_kerberos():
    """Initialize Kerberos for HDFS access."""
    gateway = spark.sparkContext._gateway
    hadoop_conf = spark.sparkContext._jsc.hadoopConfiguration()

    hadoop_conf.set("hadoop.security.authentication", "kerberos")
    hadoop_conf.set("hadoop.security.authorization", "true")
    hadoop_conf.set("dfs.namenode.kerberos.principal", "hdfs/_HOST@COTIVITI.COM")
    hadoop_conf.set("hadoop.rpc.protection", "privacy")
    hadoop_conf.set("dfs.data.transfer.protection", "privacy")

    from py4j.java_gateway import java_import
    java_import(gateway.jvm, "org.apache.hadoop.security.UserGroupInformation")
    UGI = gateway.jvm.org.apache.hadoop.security.UserGroupInformation
    UGI.setConfiguration(hadoop_conf)

    current_user = spark.sql("SELECT CURRENT_USER()").collect()[0][0]
    username_part, domain_part = current_user.split('@')
    current_user = f"{username_part}@{domain_part.upper()}"
    username_short = current_user.split('@')[0]
    username_short_underscore = str(current_user.split('@')[0]).replace(".", "_")

    keytab_source = (
        f"/Volumes/ai_engineering_dev_catalog_1688890232235261/"
        f"user_{username_short_underscore}/personal/{username_short}.keytab"
    )
    subprocess.run(["cp", keytab_source, "/etc/"], check=True)

    UGI.loginUserFromKeytab(current_user, f"/etc/{username_short}.keytab")
    print(f"HDFS ready: {UGI.getCurrentUser().getUserName()}")

init_hdfs_kerberos()
```

Expected output: `HDFS ready: sanket.zanwar@COTIVITI.COM`. For Amit the keytab path resolves to `/Volumes/ai_engineering_dev_catalog_1688890232235261/user_amit_prasad/personal/amit.prasad.keytab` and the principal to `amit.prasad@COTIVITI.COM`.

### 4. Local Environment (.venv) Setup

4a. Enable Databricks Connect: VS Code status bar (bottom) → click "Databricks Connect Disabled" → when asked to create a virtual environment choose YES → the extension runs `pip install databricks-connect` inside `.venv/` → wait for "Databricks Connect Enabled". VS Code uses the `.venv` interpreter for all notebooks/scripts in the workspace; don't activate it manually unless you know what you're doing.

4b. Verify in a VS Code terminal: `which python` (should be the `.venv` Python) and `python -m databricks.connect test`.

4c. Project dependencies, if any: `source .venv/bin/activate` then `pip install -r requirements.txt`.

### 5. Claude Code Setup

Claude Code runs locally in the VS Code integrated terminal, reads local files, and its edits reach Databricks through the extension's live sync.

5a. Install (needs Node.js 18+): `npm install -g @anthropic-ai/claude-code`; verify `claude --version`.

5b. Environment variables for Databricks-hosted Claude — Claude Code runs through the Databricks serving endpoint, not Anthropic's public API, so no personal Anthropic key is needed. Set these in the same terminal session where you run `claude`:

```bash
export ANTHROPIC_BASE_URL='https://dbc-0fa270fd-fb38.cloud.databricks.com/serving-endpoints/anthropic'
export ANTHROPIC_MODEL='databricks-claude-sonnet-4-6'
export ANTHROPIC_SMALL_FAST_MODEL='databricks-claude-haiku-4-5'
export ANTHROPIC_CUSTOM_HEADERS='x-databricks-use-coding-agent-mode: true'
export ANTHROPIC_AUTH_TOKEN='<put your Anthropic auth token here>'
export PATH="/root/.local/bin:$PATH"
export CLAUDE_CODE_USE_ENTERPRISE=true
```

Optional: append the same block to `~/.zshrc` (`cat >> ~/.zshrc << 'EOF' … EOF` under a "# Claude Code – Databricks Enterprise Setup" comment) and `source ~/.zshrc` so you don't re-enter them every session.

5c. Start: in the integrated terminal (Ctrl+` / Cmd+`) run `claude` for an interactive session, or one-shot: `claude "explain what LinkedHeader_GlobalModel/00_MSR_data_extraction.ipynb does"`, `claude "find all places where init_hdfs_kerberos is called"`.

5d. `CLAUDE.md` at the repo root — project-level instructions Claude Code reads at the start of every session (conventions, paths, things it should always know). Example:

```markdown
# Project: AI Engineering – Databricks

## Environment
- Python 3.10 in .venv (managed by Databricks Connect extension)
- Cluster start + Kerberos auth must be done in browser before local execution
- Live sync is handled by the VS Code Databricks extension

## Key Paths
- LinkedHeader model scripts: LinkedHeader_GlobalModel/
- LinkedDetail model scripts: LinkedDetail_GlobalModel/
- MSR scripts: MSR/

## Conventions
- All Spark reads go through HDFS (Kerberos-authenticated)
- Don't commit .venv/, *.keytab, or any file with PATs
```

5e. Permissions (optional) — `.claude/settings.json` at the repo root to pre-approve safe commands and cut prompts:

```json
{
  "permissions": {
    "allow": [
      "Bash(git *)",
      "Bash(python *)",
      "Bash(pip *)",
      "Bash(find *)",
      "Bash(grep *)"
    ]
  }
}
```

Adjust to what you run often; never pre-approve destructive commands like `rm -rf`.

### 6. The Daily Workflow

Git Pull → Start Cluster → Kerberos Auth → Claude Code → Develop & Sync → Git Push.

| Step | Where | What |
|---|---|---|
| 1. Pull | VS Code terminal | `git pull origin <branch>` |
| 2. Start cluster | Databricks extension | Start on your cluster in the Configuration pane |
| 3. Kerberos auth | Databricks browser notebook | run the `init_hdfs_kerberos()` block once |
| 4. Start Claude Code | VS Code integrated terminal | `claude` — ask questions, generate code, debug |
| 5. Develop | VS Code editor | edit notebooks/scripts; the extension auto-syncs saves to Databricks |
| 6. Execute | VS Code terminal or notebook | run scripts locally via Databricks Connect, or run cells in the browser |
| 7. Push | VS Code terminal | `git add`, `git commit`, `git push` |

Claude Code + live sync: when Claude Code edits a local file, the extension syncs it to the workspace automatically — just save the file.

### 7. Troubleshooting

Kerberos / HDFS: `FileNotFoundException: keytab not found` → keytab not in the Volumes path; check the path in `subprocess.run` matches your Volumes folder. `GSS initiate failed` → cluster restarted / ticket expired; re-run `init_hdfs_kerberos()` in the browser notebook. `subprocess.CalledProcessError` on `cp` → `/etc/` not writable or wrong source path; the `username_short_underscore` transform must match your folder name. Auth works in browser but not locally → expected; Py4J gateway isn't available locally, auth must always run in the browser notebook.

Databricks Connect: "Databricks Connect Disabled" in status bar → `.venv` not created / connect not installed; click it and choose YES. `AuthError` or 403 on a local run → PAT expired or wrong host URL; regenerate the PAT and re-enter it in the extension. `python -m databricks.connect test` fails → cluster not running; start it from the extension. Version mismatch warning → local `databricks-connect` doesn't match the cluster DBR; `pip install databricks-connect==<cluster-dbr-version>`.

Claude Code: 401/auth error on start → `ANTHROPIC_AUTH_TOKEN` or `ANTHROPIC_BASE_URL` not set; re-export in the same terminal. `claude: command not found` → Node.js missing or npm install failed; re-run `npm install -g @anthropic-ai/claude-code`, check `node --version` is 18+. Cannot reach model endpoint → wrong base URL or VPN/network; confirm the network and that the URL ends in `/serving-endpoints/anthropic`. Env vars reset in a new terminal → they are per-session; add the exports to the shell profile. Claude doesn't know the project → add `CLAUDE.md`. Too many permission prompts → add `.claude/settings.json`.

Git / sync: local changes not appearing in Databricks → auto-sync paused or extension not running; check the extension is active and toggle sync in the sidebar. Merge conflicts on pull → diverged branches; resolve locally, then push. `.venv/` accidentally staged → add `.venv/` to `.gitignore`.

### Quick Reference Card

Every session: the seven `export` lines from 5b → `git pull origin <branch>` → start the cluster in the VS Code extension → run `init_hdfs_kerberos()` in the browser → `claude`. One-liners: `claude "what does this notebook do?"`, `claude "write a unit test for this function"`, `claude "find all HDFS read calls in this repo"`. Checks: `python -m databricks.connect test`, `claude --version`.

---

## Doc 3 — Fix SSL Error for Claude Code with VS Code (Security Engineering, v1.0, April 2026; Internal – Confidential)

Problem: `API Error: SSL certificate verification failed` in the VS Code Claude Code extension. Root cause: Zscaler intercepts HTTPS with its own certificate, which Node.js doesn't trust by default.

1. Export the Zscaler certificate: Win+R → `certmgr.msc` → Trusted Root Certification Authorities → Certificates → find the certificate named "Zscaler" → right-click → All Tasks → Export → "Base-64 encoded X.509 (.CER)" → save as `C:\Users\<your-username>\ZscalerCACert.pem`.
2. Verify in PowerShell: `Get-Content "C:\Users\<your-username>\ZscalerCACert.pem"` — first line must be `-----BEGIN CERTIFICATE-----`.
3. Set the variable: `[System.Environment]::SetEnvironmentVariable("NODE_EXTRA_CA_CERTS", "C:\Users\<your-username>\ZscalerCACert.pem", "User")`; verify with `[System.Environment]::GetEnvironmentVariable("NODE_EXTRA_CA_CERTS", "User")` (prints the path).
4. Fully restart VS Code: `taskkill /F /IM code.exe`, then reopen.
5. Confirm VS Code picked it up: in the VS Code terminal `$env:NODE_EXTRA_CA_CERTS` prints the path.
6. Send a message in Claude Code — the SSL error should be gone.

---

## Doc 4 — Integrating Claude Code with VS Code (Windows) (Integrating_Claude_Code_Windows_Final.docx)

Covers installing and configuring the Claude Code extension for VS Code on Windows: environment variables, login-prompt settings, troubleshooting. Prerequisites: Windows 10/11, current VS Code, access to a Databricks workspace (to generate an API token).

1. Install VS Code from code.visualstudio.com.
2. Extensions (Ctrl+Shift+X) → search "Claude Code" by Anthropic ("Claude Code for VS Code") → Install.
3. File → Preferences → Settings → Extensions → Claude Code. Enable **"Disable Login Prompt"**. Under "Environment Variables" click **"Edit in settings.json"**.
4. Paste this JSON into settings.json (into both the workspace and the user settings.json if you have two; overwriting is fine; save with Ctrl+S):

```json
{
    "claudeCode.preferredLocation": "panel",
    "security.workspace.trust.untrustedFiles": "open",
    "claudeCode.disableLoginPrompt": true,
    "claudeCode.environmentVariables": [
        { "name": "ANTHROPIC_MODEL", "value": "databricks-claude-haiku-4-5" },
        { "name": "ANTHROPIC_BASE_URL", "value": "https://dbc-0fa270fd-fb38.cloud.databricks.com/serving-endpoints/anthropic" },
        { "name": "ANTHROPIC_AUTH_TOKEN", "value": "<YOUR_DATABRICKS_API_TOKEN>" },
        { "name": "ANTHROPIC_DEFAULT_SONNET_MODEL", "value": "databricks-claude-sonnet-4-5" },
        { "name": "ANTHROPIC_CUSTOM_HEADERS", "value": "x-databricks-use-coding-agent-mode: true" }
    ]
}
```

5. Generate a Databricks API token: workspace → (bottom-left) **Serving** → **Integrating Coding Agents** → "Get Started" → **Other Integrations** → drop-down **Claude Code** → generate a new personal access token → paste it into `ANTHROPIC_AUTH_TOKEN` above. Keep tokens secret; never commit them or put them in screenshots. (The dialog also offers tabs for Cursor / Codex / Gemini CLI / Other integrations; the drop-down lists Cursor, Claude Code, Cline; it lets you pick a Default Anthropic Model — the screenshot showed `databricks-claude-opus-4-5` — plus optional default Opus and Sonnet models, and shows a ready-made `~/.claude/settings.json` snippet: `{"env": {"ANTHROPIC_MODEL": "…", "ANTHROPIC_BASE_URL": "…/serving-endpoints/anthropic", "ANTHROPIC_AUTH_TOKEN": "<your_token_will_appear_here>", "ANTHROPIC_CUSTOM_HEADERS": "x-databricks-use-coding-agent-mode: true"}}` with a **Generate API key** button.)

Optional — Git Bash path: if Claude Code prompts for Git Bash, install Git for Windows and add to the same `environmentVariables` array: `{ "name": "CLAUDE_CODE_GIT_BASH_PATH", "value": "C:\\Users\\<your-username>\\AppData\\Local\\Programs\\Git\\bin\\bash.exe" }`.

6. Use it: restart VS Code, open the Claude Code panel (icon in the Activity Bar, "Claude Code: Open" — the orange splash), start a new chat. Toggle panel vs. sidebar via `claudeCode.preferredLocation`. "If the universe wills it (and the configuration is correct), you should now be able to chat with Claude."

Troubleshooting: VS Code Output panel → select "Claude Code" to view logs; make sure settings.json is valid JSON (no trailing commas).

---

## Doc 5 — Piloting Claude Code in Databricks (Alaa Youssef, Jan 30, 2026; labels claude_code, databricks)

Claude Code Discovery Week — evaluating Claude Code in the DBX environments to see where it accelerates workflows; feedback shaped recommendations to leadership. (Feedback form `Claude_Code_Discovery_Week_Feedback_Form.docx`, renamed with initials, uploaded to the OneDrive folder "Claude Testing Feedback"; deadline was EOD Wed Feb 4, 2026 — past.)

Questions the pilot asked people to reflect on: Capability & fit (what Claude handled well / where it struggled; minor tweaks vs. major rework; trust for production vs. drafts). Efficiency & ROI (manual vs. Claude time; did prompt→refine cycles eat the savings; could a more junior person now do it). Technical feasibility (environment, permissions, context-length issues; security/data-access concerns; workarounds). Model selection (was Haiku enough or did you need Sonnet/Opus; quality differences when switching).

Mindful model consumption — token usage = cost. Haiku ($): quick iterations, simple tasks, boilerplate. Sonnet ($$): complex coding, analysis, nuanced tasks. (Opus column cut off.) Cost-saving tips: start with Haiku and upgrade only if needed; keep context lean (snippets, not whole files); be specific upfront; batch similar requests; reuse successful prompts.

Best practices for Claude Code on DBX — prompting: set context first ("I'm in a Databricks notebook using PySpark 3.4"); specify output format ("return only the code" / "add inline comments"); provide schema or sample rows; break complex tasks into steps (read → filter → aggregate); ask for validation (assertions, a test case). Working in DBX: check package availability (not everything is pre-installed); mind the context window (summarize or sample large dataframes/notebooks); test incrementally; review before running, especially writes; document what worked (save effective prompts as comments or in a shared prompt library). Pitfalls: pasting entire notebooks; vague prompts ("make this better"); blindly trusting output; Opus for simple tasks; repeating a failed prompt verbatim instead of rephrasing.

---

## What this means for ARIA / Amit

- Two ways to get Claude Code today: (A) inside a Databricks web terminal on a cluster — nothing to install on the laptop; (B) VS Code on the laptop with the Databricks extension, which is the real dev loop (local files, Databricks Connect, live sync, git).
- Prerequisites to ask the team for: access to ai-engineering-dev, a personal single-user cluster there, a Kerberos keytab placed in `/Volumes/ai_engineering_dev_catalog_1688890232235261/user_amit_prasad/personal/`, a Bitbucket repo for ARIA work, and the shared CLAUDE.md rules file (SharePoint / Cotiviti Github Agents Repo).
- Everything routes through Databricks serving endpoints and Cotiviti's Zscaler — no personal Anthropic key, and the Zscaler cert fix is needed on the Windows laptop before Node-based tools work.
