# Cotiviti Confluence — Databricks CI/CD, Bitbucket, job monitoring, retries, and the Model Inventory Governance POC

Source: 23 phone photos in D:\Cotiviti\confluence\Photos-1-001 (taken Sep 21, 2026, ~5:19–5:22 PM CT) of Cotiviti Confluence pages in the space with key **MLSA** (space name ends in "…ing and Strategic Analytics", probably "Machine Learning and Strategic Analytics"; URL pattern `…/spaces/MLSA/pages/<id>/<Page+Title>`), plus one photo of a printed/one-page poster. Read and transcribed by Claude on 2026-09-21. Screenshots inside the pages were photographed off a monitor, so a few small details are marked "as best read".

Pages captured (in photo order):

1. Connecting Bitbucket to Databricks — by Noronha, Faviana, Feb 23, 2026 (6 photos)
2. Databricks CI/CD Documentation — updated Mar 31 (2026) (10 photos)
3. Databricks Job Monitoring and Logs — by "Former user (Deleted)", Jan 14, 2025 (3 photos)
4. Retry on Pipeline Failure — by "Former user (Deleted)", Jan 09, 2025 (3 photos)
5. Model Inventory Governance POC poster — MLOps Team, Faviana Noronha, April 2026 (1 photo; probably belongs with the "Schema-Enforced Model Inventory Registration System o…" page in the same space, not confirmed)

## The short version (what to remember)

- Source control is **Bitbucket Server (self-hosted) at bitbucket.cotiviti.com**, not Bitbucket Cloud. Databricks connects to it with a Bitbucket **HTTP access token**, and the Git provider chosen in Databricks is "Bitbucket Server". Databricks Git folders (Repos) clone under your user folder (Workspace > Users > you@cotiviti.com).
- The Databricks workspace in the screenshots is **Azure Databricks** (`adb-4383699102043355.15.azuredatabricks.net`, workspace name `cotiviti-databricks-test-2`, Dec 2024 screenshots). One line on the same page says command-line `git clone` works "when using a dedicated compute resource (eg. g4dn.xlarge), but not from the Serverless resource" — g4dn.xlarge is an AWS instance type, so there may be AWS workspaces too. Update 2026-09-22: the AI-engineering workspace **ai-engineering-dev** is AWS Databricks (`https://dbc-0fa270fd-fb38.cloud.databricks.com/`) per the May 2026 Claude Code / VS Code pages (see `confluence\databricks-vscode-claude-code.md`); the Azure one in these screenshots was a 2024 test workspace.
- The **real, working pipeline** (as documented for the "Databricks_Migration" job) is: Bitbucket commit → webhook → **Jenkins** (`gad1dmljenkin01.cotiviti.com/jenkins/job/Databricks_Migration/`) → Jenkins shared library `jenkins-shared-library-oaip-migration` → `runDatabricksPipeline()` → **Databricks CLI + Databricks Asset Bundles (DAB)**: `pip install databricks-cli` → `databricks bundle validate -t <target>` → `databricks bundle deploy -t <target>` → optional integration tests → REST calls to the Dev or Prod workspace, authenticated as service principal **`dab-sp-prod`** (DATABRICKS_HOST + DATABRICKS_TOKEN). Example repo: `bitbucket.cotiviti.com/projects/OAIP/repos/dbx-ovaledgeprofiler` (developer matthew.grant@cotiviti.com).
- **Branch model = dev → mvp → prod**, one Databricks job workflow per branch. Pushing to dev deploys to the dev job workflow; merge request dev→mvp promotes code to the MVP branch (via Bitbucket pipelines) and redeploys the mvp job workflow; merge request mvp→prod does the same for prod. Redeploys are automatic when the job task uses Bitbucket as its source.
- The rest of the CI/CD page is generic Databricks-docs material describing two approaches: (1) Git folders + Repos API (no DAB), (2) DAB with databricks.yml and `databricks bundle deploy/run`, plus GitHub Actions, Terraform (`databricks_repo`), service principals, and Jenkins with OAuth M2M auth.
- Job monitoring: Jobs Runs UI (statuses: Succeeded, Succeeded with failures, Failed, Skipped, Timed Out, Canceled; run states Queued/Pending/Running/Skipped/Succeeded/Failed/Timed Out/Canceling/Canceled), matrix view of run history, job output logs from the run details page, cluster driver logs (stdout/stderr/log4j). Databricks has no built-in detailed job-level run logs, so add structured logging (Python `logging`, Spark log4j).
- Retries: set per task (Data Engineering → Jobs → Create Job → Tasks → Retries): max retries, retry interval, retry on timeout; example 3 retries / 5 min; serverless auto-optimization may add up to 3 retries. Custom retry = try/except loop with `time.sleep` in the notebook.
- Governance POC (Faviana Noronha, MLOps, April 2026): a Python SDK `register_model()` is the only path to register a model in Unity Catalog; it validates 13 governance tags, a service principal `model_register_sp` does the write, an append-only Delta audit log is kept, Teams + email alerts fire, and a live view `vw_governed_models` replaces hourly snapshot jobs. Data scientists are read-only at the catalog level.

## People who show up

- **Faviana Noronha** (faviana.noronha@cotiviti.com) — wrote the Bitbucket↔Databricks page (Feb 2026) and the Model Inventory Governance POC (April 2026); MLOps team. Her Bitbucket token showed PROJECT ADMIN / REPOSITORY ADMIN permissions (as best read).
- **Matthew Grant** (matthew.grant@cotiviti.com) — developer named in the CI/CD example as the one whose commits trigger the Jenkins job.
- **Kaige Feng** ("Feng, Kaige") — owner of the example job in the retry screenshot; "admins" group can manage.
- The Job Monitoring and Retry pages are by a deleted Confluence user (Jan 2025).

## Page 1 — Connecting Bitbucket to Databricks (Feb 23, 2026, Faviana Noronha)

Purpose: step-by-step for generating a token in Bitbucket, adding it in Databricks, and cloning a Bitbucket repo into Databricks. Labels on the page: git, bitbucket.

### 1. Generate a token key in Bitbucket

1. Log in to Bitbucket (bitbucket.cotiviti.com).
2. Profile picture (top right) → **Manage account**.
3. Left menu → **Personal Settings > HTTP access tokens** → **Generate a token**. (URL in the screenshot: `bitbucket.cotiviti.com/plugins/servlet/access-tokens/users/<user>/manage`.)
4. Give it a label (e.g. "Databricks Integration") and pick permissions (Read, Write, or both). Faviana's own token showed PROJECT ADMIN + REPOSITORY ADMIN, created 18 Dec 2024, expiring 18 Mar 2025 — so tokens expire and need renewing.
5. **Create**, then copy and store the token — it cannot be viewed again.

Bitbucket page banner (as best read): a red "ATTENTION: do not store PHI in this application — against company policy" notice; "New user access / need a project? click HERE"; login issues → servicedesk@cotiviti.com; Bitbucket bugs → Atlassian.Support@cotiviti.com.

### 2. Add the token in Databricks

1. Open the Databricks workspace → profile icon (top right) → **User Settings**.
2. Settings → User → **Linked accounts** → Git integration: Git provider = **Bitbucket Server**; Git provider username = your Cotiviti username (e.g. faviana.noronha); paste the HTTP access token; **Save**.
3. The screenshot shows a "Private Git Server — contact your Databricks representative for information on versioning with private Git servers" warning, which is expected for a self-hosted Bitbucket.

Workspace sidebar visible in the screenshot: Workspace, Recents, Catalog, Workflows, Compute; SQL: SQL Editor, Queries, Dashboards, Genie, Alerts, Query History, SQL Warehouses; Data Engineering: Job Runs, Data Ingestion, Delta Live Tables; Machine Learning: Playground, Experiments, Features, Models, Serving; Marketplace, Partner Connect.

### 3. Clone the repository into Databricks

1. In Bitbucket, open the repo → **Clone** → copy the HTTPS URL.
2. In Databricks: Create → (or right-click in Workspace) → **Git Folder**; fill Git repository URL, Git provider, Git folder name → **Create Git Folder**.
3. The Git folder is cloned under your user path (Workspace > Users > you@cotiviti.com). A small icon next to the repo name shows the current branch; use it to change branches, pull and push. The screenshot shows Faviana's user folder with a Git folder (created Dec 18, 2024) and a folder that reads like `lakehouse-retail-c360` (Dec 13, 2024); a second screenshot shows a repo whose name reads like `oaiops-reports` (as best read).
4. Command line: on a **dedicated compute resource** (example given: g4dn.xlarge) you can run a normal `git clone https://bitbucket.cotiviti.com/...`; this does **not** work from Serverless compute.

Neighbouring pages in the same Confluence space (from the left nav, some titles cut off): Welcome 2 Databricks · What does DataBricks Provide? Turn key and read to go! · Data ingestion to Model Deployment · …g and Data Guidelines · How do I get Access? · Databricks Documentations · Change Data Capture on Databricks · Connecting Bitbucket to Databricks · Connecting to HDFS Cluster · Data Dictionary POC · Databricks CI/CD Documentation · Databricks Job Monitoring and Logs · DataBricks Project Status · Retry on Pipeline Failure · Schema-Enforced Model Inventory Registration System o… · Claude Code on Databricks · …bot to Databricks Migration · Databricks CI/CD High Trust · Security Overview · Workspace and Teams + Owners · Connection Setup Guide · …tion Rosetta Stone (CCV) · … – Access, Security, Data, Compliance, Infra Setup, Out… · Claude Code on Native Anthropic Endpoints - MAC · Claude Code Setup — Windows (Global + Zscaler Fix) · …n Prompt Fix · Claude Code (VS C…). Worth photographing later: "Databricks CI/CD High Trust", "How do I get Access?", "Workspace and Teams + Owners", "Claude Code on Databricks", and the Claude Code setup pages.

## Page 2 — Databricks CI/CD Documentation (updated Mar 31, 2026)

### A. The actual Cotiviti pipeline (ASCII flow at the top of the page)

```
STEP 1: BITBUCKET   bitbucket.cotiviti.com/projects/OAIP/repos/dbx-ovaledgeprofiler
  • Stores source code
  • Triggers webhook on commit
  • Runs as: Developer (matthew.grant@cotiviti.com)
      │ HTTP POST (webhook) — payload: commit SHA, branch, author
      ▼
STEP 2: JENKINS     gad1dmljenkin01.cotiviti.com/jenkins/job/Databricks_Migration/
  • Orchestrates deployment
  • Runs as: Jenkins service account
  • Job: Databricks_Migration/dbx-ovaledgeprofiler
  • Loads: @Library('jenkins-shared-library-oaip-migration')
      │ Executes: runDatabricksPipeline()
      │ Uses credentials: bitbucket-credentials, databricks-token
      ▼
STEP 3: JENKINS SHARED LIBRARY   bitbucket.cotiviti.com/.../jenkins-shared-library-oaip-migration
  Pipeline stages:
    1. Setup    → pip install databricks-cli
    2. Validate → databricks bundle validate -t <target>
    3. Deploy   → databricks bundle deploy -t <target>
    4. Test     → run integration tests (optional)
      │ Authenticates as: Service Principal "dab-sp-prod"
      │ Executes: Databricks CLI commands
      ▼
STEP 4: DATABRICKS CLI   github.com/databricks/cli
  • Reads: bundle/databricks.yml
  • Uploads: src/ files to workspace
  • Creates/updates: jobs from resources/*.yml
  • Sets: permissions
  • Auth: DATABRICKS_HOST + DATABRICKS_TOKEN (dab-sp-prod)
      │ REST API calls to Databricks — creates/updates resources as dab-sp-prod
      ▼            ▼
STEP 5A: DEV WORKSPACE    STEP 5B: PROD WORKSPACE
```

Repo layout implied by step 4: `bundle/databricks.yml` (bundle definition), `src/` (code uploaded to the workspace), `resources/*.yml` (job definitions).

### B. "Requirements from platform" (verbatim, the branch/promotion rules)

- Bitbucket notebook → (manual) push to Bitbucket in **dev** branch → code gets deployed to **dev job workflow** (happens automatically if the job's task uses Bitbucket as source).
- On merge request from **dev to mvp** → code gets deployed from Dev branch to **MVP** branch (via Bitbucket pipelines) and redeploy **mvp job workflow** (automatic if the job's task uses Bitbucket as source).
- On merge request from **mvp to prod** → code gets deployed from mvp branch to **prod** branch (via Bitbucket pipelines) and redeploy **prod job workflow** (automatic if the job's task uses Bitbucket as source).

### C. Diagram "CI/CD Workflow with Bitbucket and Databricks"

Flow: Notebook Development → Push to Bitbucket (Dev) → Dev Job Workflow → Merge to MVP → MVP Branch Deployment → MVP Job Workflow → Merge to Prod → Prod Branch Deployment → Prod Job Workflow. Legend: blue = automated step, black = manual step. As drawn, the three "Job Workflow" boxes are the automated steps; everything else (development, push, merges, branch deployments) is drawn as manual — slightly at odds with the text above, which says branch deployment runs via Bitbucket pipelines.

### D. Generic section: "How does Databricks support CI/CD for machine learning?"

Two ways to automate the Databricks pipeline:

1. **Without Databricks Asset Bundles (Git + Repos API)** — use Databricks Git folders (Repos) to sync the workspace with a Git repo; automate updates with GitHub Actions, Jenkins or Azure DevOps by calling the Databricks Repos API to pull the latest code after a merge; jobs reference the latest committed code in the synced repo.
2. **With Databricks Asset Bundles (DAB)** — package notebooks, workflows, dependencies and config in a structured format; define environments (dev, staging, prod) in `databricks.yml`; deploy and run with `databricks bundle deploy` / `databricks bundle run`; good for modular, portable, multi-environment deployments.

#### D1. CI/CD with Git and Databricks Git folders

- What CI/CD gives: code versioning, collaboration without overwriting each other's work, automated deployment to production.
- Development workflow (Step 1, setting up Git in Databricks): clone the repo into Databricks (each user gets their own workspace folder) → create a feature branch → change notebooks/files → commit and push → merge to main when ready. Best practices: everyone works on their own feature branch, no direct changes on main, resolve merge conflicts before pushing.
- Collaboration workflow: clone → feature branch from main (e.g. feature-b) → modify → commit/push → others clone and work on separate branches → merge via the Databricks Git folders UI or directly in Git.
- Running jobs in production, two options: (1) reference a specific Git branch, tag or commit in the job definition so jobs always run stable code; (2) a production Git folder kept in sync, updated automatically after merges via the Repos API.
- Example pipeline with GitHub Actions: feature branch pushed → GitHub Actions triggered on commit → unit tests and linting → merge to main → pipeline updates Databricks Git folders via Repos API → Databricks job runs the latest code. Diagram: Developer → GitHub (push code) → GitHub Actions (CI/CD pipeline) → Databricks Repos API → Production jobs execution.
- Automating Git updates: create top-level Development, Staging and Production folders; only service accounts should have write access to Production; use GitHub Actions or another CI tool to call the Repos API whenever code is merged into main.
- Service principals: let automation tools access Git folders securely; created/authorized via UI or CLI; can be linked to Git credentials.
- Terraform (advanced): `resource "databricks_repo" "example" { url = "https://github.com/user/demo.git" }`.
- GitHub Actions steps: store workspace URL and PAT as GitHub secrets; workflow updates the Databricks repo, builds artifacts, deploys; trigger on every commit.
- Summary: better collaboration, automated production deployments, secure access via service principals, integration with GitHub Actions and Terraform.

#### D2. With Databricks Asset Bundles (DAB)

- DABs describe Databricks resources (jobs, pipelines, notebooks) as source files, enabling source control, code review, testing and CI/CD (links to docs.databricks.com).
- Workflow: 1) project initialization — `databricks.yml` defines jobs, pipelines, notebooks; 2) version control — project files + databricks.yml in Git; 3) continuous integration — CI tool (GitHub Actions or Azure DevOps Pipelines) runs Databricks CLI `bundle` commands to validate and test; 4) continuous deployment — on successful validation, `bundle deploy` to the workspace and run the jobs/pipelines.
- Diagram: Developer → Git repository (push code) → CI tool (Bitbucket / Azure DevOps) → Databricks CLI (validate & deploy bundle) → Databricks workspace (run jobs/pipelines). Framed as infrastructure-as-code.

#### D3. CI/CD with Jenkins on Databricks

- Workflow: 1) repository management (repo in your Git provider, local dev environment connected); 2) develop and test locally, push to the repo; 3) Jenkins pipeline automates build/test/deploy and pulls the latest code; 4) Databricks CLI + DABs build and deploy to the workspace, with Jenkins authenticating via **OAuth machine-to-machine (M2M)** for a service principal; 5) deploy the built artifacts and execute them in Databricks.
- Key considerations: OAuth M2M auth for the workspace; keep Databricks host URL, client ID and client secret in Jenkins environment variables; define clear pipeline stages (build, test, deploy).
- Closing line: "By considering both approaches — Databricks Git folders and Databricks Asset Bundles — we can choose the one that best fits our team's workflow and project requirements." Sources: Databricks docs.

## Page 3 — Databricks Job Monitoring and Logs (Jan 14, 2025)

### Job monitoring

- The Jobs UI gives an overview of all jobs and their status; open it via the **Job Runs** tab under Data Engineering.
- Job statuses: **Succeeded** (all tasks succeeded); **Succeeded with failures** (some tasks failed but all leaf tasks succeeded); **Failed** (one or more leaf tasks failed); **Skipped** (run skipped, e.g. max concurrent runs for the job or workspace exceeded); **Timed Out**; **Canceled** (e.g. a user canceled the run).
- The matrix view shows run history per job including each task (screenshot: job "my_job" with task1/task2/task3 bars, one red failed run among green ones).
- Runs list columns: start time; run ID; trigger (schedule, API request, or manual); elapsed time for a running job or total time for a completed one, with a warning if it exceeds the configured expected completion time; status (Queued, Pending, Running, Skipped, Succeeded, Failed, Timed Out, Canceling, Canceled); error code; run parameters.

### Logs and troubleshooting

- **Job output logs**: in the job run details page, click the start or end time of the run to see its output.
- **Cluster logs**: if a task fails because of a cluster issue, look at cluster-level logs — Compute → cluster (screenshot: "DLT Cluster") → **Driver logs** tab: recent log files filtered by All / stdout / stderr / log4j, with "Auto-fetch logs"; stdout is rotated hourly (files like `stdout--2025-01-10--05-00`). Example output showed a test notebook logging "test notebook is triggered at <timestamp>" every ~2 minutes.
- **Custom logging**: Databricks doesn't include built-in, detailed job-level run logs; workarounds are structured logging in notebooks/jobs with Python's `logging` library or Spark's log4j (rest of the list cut off in the photo).

## Page 4 — Retry on Pipeline Failure (Jan 09, 2025)

1. **Default retry policy**: Databricks lets you configure retries for failed tasks in a pipeline; if nothing is specified there are **no retry attempts**. You set the number of attempts and the delay between them.
2. **Configuring retry in a job**: when creating/editing a job, set retries per task — **Data Engineering → Jobs → Create Job → Tasks → Retries**. Fields: **Max Retries** (e.g. 3), **Retry Interval** (e.g. 5 minutes), **Retry on Timeout** (retry when the task times out). The Retry Policy dialog reads: "Retry at most [3 times (4 total attempts)] and wait [5] [mins] between retries"; checkbox "Retry on timeout"; checkbox "Enable serverless auto-optimization (may include at most 3 retries)"; note that on serverless, automatic optimization can affect retries — to disable all retries, turn off automatic optimization. Task panel shows "Retries: Immediately, at most 3x (4 total attempts)".
   Example: Task 1 (ETL process), retry at most 3 times, interval 5 minutes → if it fails it is retried up to 3 times with a 5-minute gap.
3. **Custom retry logic in notebooks** for finer control:

```python
import time
max_retries = 3
retry_interval = 300  # 5 minutes

for attempt in range(max_retries):
    try:
        # Task execution code (e.g., data processing)
        break  # Exit loop if successful
    except Exception as e:
        if attempt < max_retries - 1:
            print(f"Retrying in {retry_interval} seconds...")
            time.sleep(retry_interval)
        else:
            print("Max retries reached, task failed.")
            raise e
```

Job screenshot side panel: Schedules & Triggers (none), Job parameters, Job notifications, Duration and streaming backlog thresholds, Permissions (owner Feng, Kaige; admins can manage).

## Poster — Model Inventory Governance POC (MLOps Team – Cotiviti, Faviana Noronha, April 2026)

1. **Problem**: models were being registered in Unity Catalog without governance metadata; no enforcement, so data scientists could bypass tagging entirely; stale snapshot tables needed hourly scheduled jobs to stay current; Risk & Legal had no reliable, queryable audit trail.
2. **Solution**: a governed **SDK layer that is the only path to model registration**; validates all **13 metadata fields** before any write; uses a **service principal** to enforce permissions at the catalog level; writes governance tags live to UC registered models; provides a **live compliance view** with no scheduled job.
3. **End-to-end flow**: (1) DS trains model in MLflow and fills the 13 governance widgets → (2) calls `register_model()` in the SDK → (3) validated — blocks on missing/invalid fields → (4) service principal elevates and writes to UC: writes the 13 UC tags and registers the model → (5) audit log appended to an append-only Delta table → (6) Teams + email alert fired to DS and stakeholders → (7) live view refreshed on demand, always fresh.
4. **Permission model**: Data Scientist = READ ONLY (cannot register or tag); `model_register_sp` = CREATE MODEL + MODIFY on `retail_unrestricted_dev`; `ml_unrestricted` = USE CATALOG + USE SCHEMA + EXECUTE. "DS users are blocked at the catalog level — SDK is the only path."
5. **The 13 governance tags** (written to every UC-registered model via the service principal; searchable, queryable and auditable in UC): registration_id, registered_by, model_type, risk_tier, data_sensitivity, business_unit, model_owner, model_owner_email, regulatory_scope, validation_status, deployment_env, use_case, model_status.
6. **Live compliance view**: BEFORE — MLflow client → Delta snapshot → hourly scheduled job → dashboard (stale risk). AFTER — Python function `get_all_governed_models` → MlflowClient live call → temp view `vw_governed_models` → instant query, always fresh. `SELECT * FROM vw_governed_models ORDER BY risk_tier, model_name`. "Always fresh. No job to maintain. No stale data."
7. **Demo results**: rca_poc_logistic_regression (Tier 2, Traditional ML, PII) OK · rca_poc_claims_genai (Tier 1, GenAI, PHI) OK · rca_poc_readmission_llm (Tier 3, LLM, Confidential) OK · ds_direct_registration_test — UNGOVERNED (a DS registering directly was correctly flagged and a Teams alert fired automatically).
8. **Acceptance criteria**: AC1 13 governance widgets — done; AC2 controlled-vocabulary dropdowns — done; AC3 reference data table — partial; AC4 required-field validation — done; AC5 validation error handling + audit trail — done; AC6 governance tags applied in UC via SP — done.
9. **Next steps**: (1) load reference data — client/business-unit list from a governance reference table with automated sync; (2) connect the live view into a Databricks dashboard for Risk & Legal (real-time visibility); (3) extend the governed SDK to additional model catalogs beyond the POC catalog (name reads like `fake_gold` / `lake_gold`); (4) hand off the SDK to DS teams with onboarding docs and best practices.
10. **Future work — live dashboard on Databricks**: `register_model()` writes tags to UC → REST API reads tags live → scalar UDF wraps the API call → permanent view wraps the UDF → SQL dashboard queries the view. Enables a real-time governance dashboard on Databricks SQL, alerting on missing metadata / non-compliance, governance KPIs and trend analysis, executive scorecards for Risk & Legal, and an AI copilot for governance search and insights.
11. **Executive summary**: governed, enforceable model registration path via SDK + service principal; 13 governance metadata fields captured and queryable in UC; always-fresh compliance visibility with no scheduled jobs; automated alerts and audit trail for Risk & Legal. Business impact: stronger governance and auditability, faster reviews and approvals, scalable foundation for enterprise MLOps. Roadmap: live Databricks dashboards → broader catalog coverage → continuous governance automation.

## Why this matters for ARIA / Amit's work

- Any ARIA pipeline code that lands in Databricks will go through Bitbucket Server → Jenkins (Databricks_Migration job family) → DAB deploy with `dab-sp-prod`, with dev/mvp/prod branches mapped to dev/mvp/prod job workflows. Plan repo layout as `bundle/databricks.yml` + `src/` + `resources/*.yml` from day one.
- Models registered from ARIA work will be expected to go through the governed `register_model()` SDK with the 13 tags (risk_tier, data_sensitivity = PHI for claims data, regulatory_scope, etc.), not direct MLflow registration.
- Questions to ask Reva / Yesh / Surya: which workspaces (Azure vs AWS) and catalogs ARIA uses; whether the OAIP Jenkins shared library is the standard for the AI org or only for the OvalEdge migration; who issues service principals; whether Bitbucket pipelines or Jenkins does the branch promotion; whether the governance SDK is already mandatory.
