# ARIA Architecture — Reva's Loop page (read Oct 21, 2026)

Source: photos 28–40 of `D:\Cotiviti\confluence\additional_info_aria-10-21-2026-item1\Photos-1-001` (08:38–08:39, Oct 21). Read-only Loop page "ARIA Architecture" (Recent list: Oct 12; author not shown, Reva by content and style). Four sections: 1 Introduction, 2 Architecture (2.1 high-level, 2.2 low-level, 2.3 components, 2.4 one-click-down view, 2.5 workflow, 2.6 ensembles), 3 Evaluation Methodology (link to the Loop page of that name), 4 Explainability (link to "Show, Don't Tell"). It is the **component** view of ARIA. It has no data-hub, lakehouse, bronze/silver/gold or Databricks/AWS content at all; see the last section for how our v6 relates to it.

## 1. Introduction (near-verbatim)

"Agentic Hub is a platform for AI that reasons over clinical data and produces decisions someone else can actually audit, past the point of NLP that just extracts and hands off." Core layers: Atomic Foundations (reusable reasoning engines built once against a shared clinical data model: the Clinical Abstractor, and the Symbolic Auditor with its Policy-to-Logic compiler) and Composite Business Solutions (use-case applications assembled on top). PRFAQ linked.

"ARIA (Agentic Risk Intelligent Agent) — the Autonomous Risk Adjustment Coder project — is the first business solution built on that foundation. Risk Adjustment coding was chosen deliberately: high-volume, high-stakes, and governed by explicit CMS policy. The Clinical Abstractor turns a fragmented chart into an evidence-backed Clinical Truth Graph; the Symbolic Auditor evaluates that graph against compiled CMS and payer policy and produces a per-condition determination with a citable audit trail. That determination reaches the coder through CIS, the existing coding platform, either as ranked, cited recommendations to review, or confidence- and external-signals-gated autonomous codes with human-in-the-loop handoff." "Some of what's described below is where we're headed; many components are still WIP."

Acronyms: CCDM (Common Clinical Data Model: the shared, typed vocabulary both the Abstractor's output and the Auditor's rules are written against); CRL (Clinical Rules Language, engine-neutral); CTG (Clinical Truth Graph: the structured, evidence-backed picture of one patient encounter; an instance of CCDM); MEAT (Monitoring, Evaluation, Assessment, Treatment: the documented clinical activity CMS requires before a condition is codeable); HCC; CCL (Condition Category List: payer reference data on whether a diagnosis is chronic or acute for a given period); HITL (coder review of a routed determination).

## 2.1 High-level

Two systems sit outside the Hub and call into it:

- **Existing Coding Platform (retrospective)** — the product surface. Two modes: **CoPilot** (coding assistance: coder reviews ranked recommendations) and **AutoPilot** (autonomous coder: confidence-gated, HITL handoff). It sends "chart + mode" and gets back either "ranked HCC candidates, HCC evidence, citations" (CoPilot) or "filled codes + audit trail, reasoning" (AutoPilot).
- **Intelligence Ensemble — best-answer routing per task**: the wrapped legacy stack: NLP Engine (ML, existing, wrapped, primary entity extraction) and Neural System (LLM-based, existing, wrapped, abstraction). The Hub sends it extraction tasks and gets back "entities + assertion status + temporal context + ICD-10 candidates", which the Abstractor reasons over rather than trusting as final.

Inside the Hub:

- **Composite Business Solutions: RA Coding Validator** = Coding Decision Arbitrator (MEAT + provenance + policy → coder queue) + Audit Trail (CMS-defensible). "This is where ARIA's backend itself lives… a thin layer; most of the real work happens one level down." In: "chart + RA config"; out: "per-condition determinations + chain of thought + policy citations".
- **Atomic Foundations (Symbolic Auditor API)**: Autonomous Clinical Abstractor (MEAT classifier, entity reconciler) → produces → Clinical Truth Graph (MEAT evidence; typed edges per DOS) → evidence graph → Symbolic Auditor (doc completeness, MEAT gate, policy enforcement). Policy Store (CMS-HCC model + payer addenda; ICD-10-CM guidelines; version-controlled by payer/year) ← compiled clinical rules ← Policy to Logic (deterministic rules engine) ← policies, guidelines. Everything written against the **Common Clinical Data Model — Cotiviti-wide clinical schema** (bottom bar). "That shared schema is what would let Atomic Foundations serve a second Composite Business Solution someday without a rebuild."

## 2.2 Low-level: build time vs run time

Build time, once per policy version: CMS-HCC model + ICD-10 guidelines + payer addenda → Policy-To-Logic Synthesizer (LLM): policy → CRL → CRL Ruleset. CCDM + Registry (shared typed vocabulary) supplies the "field menu + validation". Run time, one per chart: Clinical Charts (pdf / scan / fax) → Clinical Abstractor (charts → CTG) → CTG (instance of CCDM; "CTG conforms to" CCDM) + CRL Ruleset → Symbolic Auditor → Determination + Audit Trail → HITL Coder Queue + Calibration Loop → overrides → **Golden Dataset — 200 charts (codes · evidence map · negative decisions)**.

## 2.3 Components (verbatim list)

Clinical charts (raw input; messy multi-source PDFs). CMS policy corpus (HCC model + ICD-10 guidelines + payer addenda): source of the rules; fed to P2L. Policy-to-Logic (LLM synthesizer): build-time; converts policy text into CRL rules, validated against the CCDM registry. CRL ruleset: output of build time, input to the Auditor. CCDM + registry: the shared typed vocabulary both sides reference; keeps CRL fields and CTG fields aligned. Clinical Abstractor: reasons over charts to build the CTG; wraps existing NLP and adds temporal/provenance/MEAT. "There are gaps in the existing NLP system that contribute negatively to quality today" — see two more Loop pages: **"Entity/Concept, Code Extraction Pipeline Needs"** and **"Requirements for Code/Entity Extraction"** (read Oct 21; see `confluence/nlp-extraction-requirements-reva.md`). CTG: the structured clinical picture for one patient; the Auditor's facts. Symbolic Auditor: run-time; evaluates CRL rules against the CTG through a cascading set of checks, emitting a determination + audit trail. Determination + audit trail: CODEABLE / FLAG / coder-queue, with a citable reasoning trace. Golden dataset: 200 annotated charts (codes, evidence, negative decisions); measures quality and gates each phase. HITL coder queue + calibration loop: humans review routed determinations; their decisions feed back.

## 2.4 One-click-down view: the six-gate cascade

The Abstractor and the P2L build steps side by side, feeding the Symbolic Auditor's six gates, each fail-fast; a condition reaches CODEABLE only if it clears all six, and which gate it fails at is what the audit trail reports ("a condition that fails at L2 and one that fails at L5 are both 'not coded,' but they're different failures with different fixes").

| Gate | Check | On fail |
|---|---|---|
| L1 | valid ICD-10 + HCC map? | Drop — not codeable |
| L2 | assertion ACTIVE? | Coder queue (reason = first failed gate) |
| L3 | DOS in coding year? | Coder queue |
| L4 | attending provenance (≥ 0.75)? | Coder queue |
| L5 | MEAT evidence present? | Coder queue |
| L6 | HCC policy rule satisfied (CRL)? | Coder queue |
| all pass | CODEABLE + audit trail | |

Diagram details: Abstractor = Evidence Ensemble → MEAT Detection → CTG build; P2L = Extract → DOM → Chunk → Policy Graph → (CCDM + Registry) → Synthesize → CRL (Policy Synthesizer Ensemble); Auditor = Executable Engine (pluggable) + Eligibility Gates → policy.

## 2.5 Workflow, step by step

Build time (policy → CRL): 1 extract PDF → text; 2 parse into a DOM (sections, numbering); 3 chunk into semantic units; 4 resolve graph context (definitions, codes, cross-refs) and build the policy graph; 5 synthesize each chunk → CRL rule (fields from the CCDM registry, then validated). Abstractor (charts → CTG): 6 ingest + normalize the chart (OCR, char offsets); 7 split into sections (A/P, labs, radiology); 8 extract entities (wrap NLP) + temporal / provenance / specificity; 9 detect MEAT evidence; 10 build the CTG. Auditor: 11 execution engine loads CRL rules + CTG facts; 12 run the 6-layer cascade (L1–L5 structural gates, L6 CRL policy rules), fail-fast; 13 emit determination + audit trail; route to autonomous / HITL / coder-queue.

Second diagram: Chart PDF → Code & Entity Extraction → MEAT Classification → CTG → Rule Validation and Gating (Symbolic Auditor; per code: codeable / needs a coder / drop) → ARIA Coding Recommendations (pre-accepted / flagged / by disposition) → Coders: Accept / Reject / Override ("initial: every code lands here") | Autonomous Submission (gated; "removes the coder step entirely"). Policy Documents → Policy-to-Logic Compiler (rule authoring) ← SMEs.

"Routing isn't binary. A confidence score, computed per HCC category, decides which of three lanes a determination takes: logged silently in shadow mode, sent to the HITL coder queue, or filed autonomously. Autonomous coding is a gated future state we earn with internal and external signals."

## 2.6 Ensembles

Three places use more than one source: extracting evidence from the chart, MEAT classification, synthesizing policy into rules; an arbitrator reconciles. "Today, each ensemble has exactly one source genuinely active. The other boxes are where a second and third source plug in once they exist — the arbitrator is an interface contract we're building ahead of the redundancy."

- Evidence ensemble (reusable across Hub use cases): NLP system (in-house, primary entity extraction) · Neural system (LLM-based) · NLP system (external service: AWS, GCP) → Extraction Arbitrator. Domain plug-in for RA: MEAT ensemble = Neural MEAT (LLM-based, primary) · MEAT classifier (ML model) · MEAT classifier (deterministic, in-house NLP-based) → MEAT Arbitrator.
- Policy ensemble: "currently not truly an ensemble yet": the LLM Synthesizer is the one generator turning policy text into candidate CRL (after reducing the text to structured content, not "feed the whole document" naivety); the Symbolic Reasoner and SME validation are independent checks on that output, not competing proposals. Boxes: SME Validations (ground truth) · Symbolic Reasoner (deterministic logic) · LLM Synthesizer (probabilistic rules) → Synthesizer Arbitrator.
- End-to-end picture: Clinical Chart → Clinical Evidence Ensemble [NLP/CIS (entity extraction, MEAT tbd, code candidates) · PDx (LLM-based entity + code extraction) → Clinical Evidence Arbitrator] → CTG (CCDM-aligned) → Symbolic Auditor [Policy Synthesizer Ensemble: Policy-to-Logic (CCDM · CRL · stateless compiler) · "PDx Policy-to-Rules?" → Policy Arbitrator] → Coded Determinations (audit trail · explainability). Client Policy Bundle (CMS guidelines + client supplements, addenda; Aetna, Humana, …) "compiled per client".

## 3–4

Evaluation → `confluence/aria-evaluation-methodology.md`. Explainability → `confluence/show-dont-tell-explainability-reva.md`.

---

## What this means for v6 and the data hub (Amit's reading)

**Positioning for the design review.** Reva's page is the component view: who computes what. Our v6 is the data view of the same system: where every artifact in his picture lives, who writes it, who reads it, how it is versioned and replayed. Every box of his that produces or consumes data lands in one of ours, and his page has no answer for where they live; the P2L build guide's key note 3 gives it: "the lakehouse is the logical home of all data." That is the sentence to open with when Nikhil or Yesh ask "where is the data hub in Reva's architecture?"

**Mapping (his → ours):** Existing Coding Platform → lane 1 (CIS; boxes 1 and 8). Intelligence Ensemble (NLP) → today inside CIS before the S3 drop (the Oct 15 handshake); in his target state the Hub calls it, so box 1 needs a note. Autonomous Clinical Abstractor → box 4. CTG → box 5 (CTG store). Symbolic Auditor → box 6. RA Coding Validator (Coding Decision Arbitrator + Audit Trail) → box 7 gold + publish + the Explain API: this is the box he calls "where ARIA's backend itself lives", so say it that way. Policy Store (version-controlled by payer/year) → PRM (Reva's) with our lake copy. Policy to Logic → B/C. CCDM + registry → our CCDM registry + silver. HITL coder queue + calibration loop → boxes 8 and 9. Golden dataset → our golden dataset box, no longer phase 2.

**Changes to v6 (beyond the four from the P2L guide):**

1. Box 1: the request carries `mode` (CoPilot | AutoPilot) and an "RA config"; add both to the ingress contract. Box 8 becomes two outcomes: CoPilot (coder reviews ranked candidates) now; AutoPilot (confidence-gated, HITL handoff) later. Note that NLP runs inside CIS for now and is called by the Hub in the target state.
2. Box 7 (gold): the determination record must carry disposition (CODEABLE / FLAG / coder-queue), the first failed gate L1–L6 and its reason, the routing lane (shadow / HITL / autonomous), the confidence per HCC category, rule id + snapshot digest + fingerprint, claim verdicts with quoted spans, and every version key. Label the box with his words: "per-condition determination + chain of thought + policy citations".
3. Box 9 (feedback): coder overrides carry a structured reason code; confirmed errors flow into the golden dataset as permanent test cases.
4. Golden dataset: 200 charts (this page) or 256 (evaluation page) with coder-confirmed decisions; it "gates each phase", so it moves from phase 2 to "next", with a replay job beside it.
5. Reference data: add CCL and the HCC crosswalk as versioned tables keyed by DOS period (from the P2L doc).
6. Lane 3 labels: use his names exactly (Autonomous Clinical Abstractor; Symbolic Auditor, six gates; Policy-to-Logic; PRM; RA Coding Validator).
7. One new data-hub job: replay/regression ("same chart + same rules → same disposition" and "a rule change flips zero previously-correct charts", both 100% gates in the evaluation page). The hub stores both runs and reports the flips.

**Questions for Reva before Friday:** does CIS pre-run NLP (Oct 15 handshake) or does the Hub call the Intelligence Ensemble (this page)? Golden dataset: 200 or 256, and who holds it today? The two NLP pages are now read (`confluence/nlp-extraction-requirements-reva.md`); their field list goes into contract v0.2.
