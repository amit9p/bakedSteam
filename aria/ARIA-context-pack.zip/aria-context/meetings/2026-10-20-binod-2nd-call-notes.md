# 2026-10-20 — Binod's second call, 10:37 AM (10 min): "there is an urgency" (meeting notes)

Source: `Voice 261020_103710-binod-2ndcall-10-20-2026_original.txt` (AI transcript; Speaker 1 = Binod, Speaker 2 = Amit). Binod called back an hour after the 9:30 call and after sending his 10:11 Teams message to Reva. Related: `meetings/2026-10-20-binod-call-notes.md` (first call), `confluence/p2l-rule-review-design-and-build-guide-reva.md` (Reva's doc, shared 10:05).

## Outcome in four lines

1. **Binod's goal for the next 2–3 weeks is a demo to internal stakeholders, not production.** His words: "this stage is basically trying to build a pipeline and demonstrate to our internal stakeholders that this is how the application is going to work going forward"; "I'm not saying that this is how it's going to go to production in the next one month"; it is "so that they can start putting some marketing material".
2. **For the policy tool he will take anything.** "All I need to know now is what rules I have to show… if after processing these become a static JSON file or something that can be stored in S3, just let me know and I can pull it, show it, and then we can record the feedback, which I can put in a JSON or dump in my database." The UI (Angular/React, given by Reva) is deployed in CIS's QA cluster.
3. **The CIS → ARIA feed is further along than we thought, and the shape is now known** (below). CIS has started the small service that taps the existing NLP output and pushes it to SFTP/S3 with an event. India team out today; Binod is working on it himself.
4. **The timeline disconnect is now on the table.** Binod was told 2–3 weeks and "assumed Cloud told Reva and Surya the same, because the source is the same". Amit said plainly: the architecture has not been presented to Surya, the platform is not decided, the work has not started, the design review with Nikhil and Yesh is pending, two weeks is not realistic, and the data pipeline does not have to be in the demo; "confirm with Surya and Reva". Binod: "I can send a message to Surya and we can have a sidebar"; "there is nothing wrong in doing what you are doing, it is just that putting it in front of the customer in 2–3 weeks may not be realistic"; "I just don't want to be the guy who said 'get it done' — I was not aware of when you joined the project."

## The CIS feed, as Binod described it (new detail for the contract draft)

- One **ZIP per chart** in the S3 bucket. Inside: (1) the **chart PDF**, (2) a **JSON** with the list of ICD codes plus context for each: which section the code was found in, the sentence, an offset, and the confidence score returned by the NLP engine.
- Structure: a chart has multiple **encounters**; encounters have multiple **codes**; codes have **descriptions**; descriptions contain the **sentence**. CIS is "trying to build a JSON in such a way that you can get all the details based on that encounters".
- Path: existing production pipeline → OCR → NLP publishes → a small new CIS service extracts it → pushes to SFTP / S3 with an event ("we'll bundle it and copy it over there").
- What the coder does today: looks at the NLP output and says "I agree" or "I don't agree". ARIA's job in the demo is to add its recommendation to that view.

This changes `aria/aria-ingress-contract-draft-v0.1.md`: the unit is a ZIP (PDF + JSON), the JSON is encounter-nested, and section/sentence/offset/confidence are confirmed fields. Still open: the bucket prefix, the event target (SQS vs SNS), and a sample file (Venkateshwar).

## Other things Binod said

- Two CIS streams in flight: the data feed ("we are pretty positive we are going to get it done pretty soon") and the policy tool front end; "anything that gets done before this deadline is a great thing for us".
- He is willing to find people: "if we have sufficient people… if not, I can go and talk to you or send a message to figure out from where we can get additional help."
- He knows a data lakehouse exists and has used it: "we have a couple of use cases that we worked on… I'm working on the CIS reporting engine also over there… I don't know if it's an overkill for the ask right now." So his doubt about the hub is about scope for a demo, not about lakehouses in general.
- "You can build a pipeline in parallel" — he is not asking Amit to stop; he is asking that the demo not wait for it.

## What Amit said (for the record)

- Surya and Reva have to be brought in so everyone has the same timeline.
- "I was asked to create my data pipeline surrounding this agentic hub"; "given this timeline… this is a tight timeline, and even I think we should not go with that."
- The design has not been presented to Surya; the platform is not decided; the work has not started; the platform team (Nikhil, Yesh) still has to see the design; two weeks is not realistic; the pipeline does not have to be in the demo; confirm with Surya and Reva.

## What this changes

- **The demo can be done without the data hub.** Binod's own description of the demo is: CIS shows NLP codes to the coder, ARIA's rules/recommendations appear next to them, feedback is recorded. For 2–3 weeks that is a file handoff: rules as a static JSON in S3 (Reva's P2L output) and, if anything on the chart side, a results file per chart. Nothing in that needs bronze/silver/gold to exist first. Say this to Surya and Reva before Binod's sidebar happens, so the answer comes from them.
- **Binod's "static JSON in S3" clashes with Reva's design.** Reva's doc puts the rules and the reviews behind PRM's authenticated API (key note 5: "nothing reaches production unapproved; the API enforces it"). For a demo Binod would accept files; Reva may not. That is Reva's call, but Amit should not be in the middle of it.
- **Our contract draft gets concrete**: ZIP per chart, encounter-nested JSON, confirmed fields. Update v0.1 → v0.2 once a sample arrives.
- **The timeline message to Surya is now simple**: Binod has a 2–3-week internal demo from Tejveer/Cloud; he assumes Reva and Surya were told the same; nobody on our side has confirmed it; the data pipeline should be explicitly out of that demo's critical path.

## Actions

- Amit: tell Surya today that Binod will message him about a 2–3-week demo; give him the one-line position (demo = CIS UI + Reva's rules file + feedback capture; data pipeline in parallel, not in the demo's critical path; design review first).
- Amit: tell Reva that Binod would accept rules as a static JSON in S3 for the demo and will record feedback in his own database — ask whether that is acceptable to him for the demo or whether PRM's API is a must from day one.
- Amit: update the ingress contract draft with the ZIP + encounter-nested JSON shape; ask Venkateshwar for one sample ZIP.
- Binod: sidebar with Surya on the timeline; bucket prefix and event choice "by tomorrow".
