# Design review — short talking notes (all 12 slides)

Deck: `aria\aria-design-review-deck-cotiviti.pptx`. Slides 1 to 7 are the talk, about 18 minutes. Slides 8 to 13 are the appendix; one or two sentences each, only if someone asks. Read each line, pause, next line. The long version with Q&A answers is `design-review-talking-sheet.md`.

---

## Slide 1 — Title (1 min)

"Thanks for joining. This is the design review for the ARIA data pipeline.

I want three things from this hour. Your comments on the design. A decision on the platform. And agreement on what I need from each of you to keep building.

Six slides. Business first, then why the data layer exists, then the architecture, then the platform question, then the two decisions. Stop me anytime."

## Slide 2 — What ARIA does (2 min)

"Quick business picture, so you see what I'm building against.

A chart is the doctor's notes for a visit. A coder turns it into ICD-10 codes. Some codes map to an HCC, a payment category. CMS pays the plan on those. Years later CMS audits a sample and applies the error rate to the whole contract: ten percent of two hundred charts becomes ten percent of the contract's risk payments. So every code needs its proof: which sentence, which page, which rule.

ARIA's output, for each code on a chart: codeable, flag, or send to a coder. With the evidence. The coder decides. That's CoPilot, which we build now. AutoPilot comes later, when the numbers earn it.

Pilot scope: diabetes, CKD, heart failure. Aetna first."

## Slide 3 — Today's picture (1 min)

"This is how it works today, and it's correct. CIS sends the chart and its NLP output. The components send back a recommendation. The coder sees it.

That handshake doesn't change. CIS sends a file and gets a file back.

The only question is what happens to the data that went through. Today, nothing. Fine for a demo, not enough for a pilot."

## Slide 4 — Plus the data hub (3 min)

"Same handshake, one thing added underneath: the data hub. Everything that goes through gets recorded there, every version.

Five reasons we need it.

Replay. The feed and the rules keep changing. If we kept the files, we rerun old charts ourselves. If not, we ask CIS to resend every time.

Reproduce. Same chart plus same rules must give the same answer. A rule change must flip zero charts that were right before. Both checks need the old run and the new run saved.

Audit. CMS comes years later and asks why. By then the models and rules have changed. We need a frozen record per code: the sentence, who signed it, the rule as it was that day, what the coder did. Readable without ARIA.

Pilot numbers. Precision, recall, false accepts, coder time. Each one is what ARIA said against what the coder did. Today ARIA's answer is a file that leaves, and the coder's decision stays in CIS. The hub puts them side by side.

Feedback to CIS. The hub sees every chart, so it can say, per feed version, which fields arrived and which didn't. A daily number with an owner, instead of someone reading files by hand.

The platform's own build guide says it: the lakehouse is the logical home of all data.

What the hub does not do: it doesn't fix the chart or the NLP, it doesn't own the policy tool, and it isn't on the critical path for the November demo."

## Slide 5 — The architecture (6 min)

"One picture. Three things to set up.

Four lanes: CIS on top, the data hub second, the AI components third, reference data and feedback at the bottom.

Two kinds of handoff. With CIS it's S3: file in, file out, solid arrows. With the components, for the demo, it's also a file: we write a folder, they read and write back. Those are the green dashed arrows. Every hub box is a job that fires when a file lands.

Two doors: lookup for codes and reference data, explain for 'why this code'. Nobody reads our tables directly.

Now one chart, left to right.

One. CIS drops one ZIP per chart on S3: the PDF and the NLP JSON.

Two. Bronze. We keep the ZIP exactly as it came, every version.

Three. Silver. We clean it into six tables in the shared clinical schema. Rows that fail a data-quality check go to a seventh table, quarantine, with a reason and an owner. That feeds the daily report to CIS. Silver then writes one JSON per chart to the handoff folder.

Why six tables and not the raw JSON. The abstractor is the only one that wants the whole chart. Everyone else wants a field: the gates read codes, dates and signers; the explain API lands on one mention row; the quality report counts notes with no signer. Tables answer those; a nested JSON doesn't. So we split it once, by the six sections of the extraction requirements, and bundle it back into one JSON for the abstractor. Silver is the only layer whose shape is our call; the graph and gold we store as the components hand them to us.

Four. The clinical abstractor, on the platform side. The NLP found words; the abstractor decides which are true for this patient on this visit. Is it real, is it current, who signed it, is there MEAT proof. Out comes the clinical truth graph.

Five. We store that graph, versioned per run. It's the auditor's set of facts.

Six. The symbolic auditor, platform side. Six gates per code, stops at the first that fails. No AI, same in, same out. The HCC is attached here from the crosswalk. The rules come from PRM. Out comes one determination per code.

Seven. Gold. One row per code: codeable, flag, coder queue, or drop, which gate failed, the rule and snapshot id, every version. One results file per chart goes back to CIS on S3.

Eight. The coder reviews in the CIS app. 'Why this code' goes to the explain door.

Nine. CIS sends us the coder's decisions. We join them to gold and compute the pilot numbers, per HCC, per code, per date of service.

The rules, in one breath. A guideline PDF goes into PRM. Policy-to-logic drafts rules. Coders review them in the CIS screen through PRM's API. Changed rules go round again. A second person promotes. The auditor fetches the active set from PRM at run time. We copy PRM nightly for explain, eval and audit. The copy never drives a decision.

Tags: built runs today on synthetic data. POC means the platform code exists. New is PRM. Next is slice two.

Questions on the picture?"

## Slide 6 — Where the hub runs (2 min)

"This one is yours to decide. I'll give the facts.

Fixed either way: CIS is on AWS, the components run on Kubernetes on AWS, PRM is Postgres plus S3, there's no GCP yet.

Two options. Databricks on AWS, where it runs today. Or AWS native, in the existing lakehouse. The table compares them row by row: tables, bucket access, component connection, the write API, time to first real chart, risk.

I'm asking which one the hub should run on. The data layer is identical on both. Only the plumbing changes. Long term is your call."

If asked for your view: "I wouldn't rebuild now. But if it should live with the lakehouse team, the design doesn't change, the plumbing does."

## Slide 7 — Decisions (2 min, then discussion)

"Two decisions I need today.

One, which platform does the hub run on: Databricks on AWS, or AWS-native.

Two, CIS drops real charts on the thirtieth. We need a role into their bucket and a workspace cleared for PHI. Who sets those up, and by when?

The rest I'm tracking outside this room: the write API in the platform plan, with Reva; the account question, with Yesh or Nikhil after decision one; NLP location, golden dataset size and the file handoff, with Reva; the sample ZIP and contract answers, with Binod.

Decision one first; two depends on it. The access picture is in the appendix, slide 13."

Close: "Thanks. I'll send the deck, the contract draft and the blueprint today, with a note on what we decided and who owns what."

---

## Appendix — only if asked

## Slide 8 — Appendix divider

"These are the zoom-ins. Blueprint, silver tables, the CIS contract, the policy lane, and the accounts and roles."

## Slide 9 — Data blueprint

"One row per kind of data the hub keeps: what it is, who writes it, who reads it, whether it's PHI, how it's versioned, how long we keep it. Four rules at the bottom. Nothing that feeds a decision is ever overwritten. Every decision row carries its version keys. PHI tables are readable only by the pipeline, the components and the explain API. Other systems come through the doors or the S3 handoffs, never the tables."

## Slide 10 — Silver tables

"Six tables, one per section of the extraction requirements, plus quarantine. Chart, note, mention, code candidate, relationship, MEAT evidence. Quarantine holds rows that fail a check: confidence outside zero to one, a code at category level, a mention with no page or offsets, an assertion we don't recognise, a note with no signer, an unreadable ZIP. Each row has a reason and an owner. One bad mention doesn't stop the chart; the daily report tells CIS what to fix."

## Slide 11 — CIS contract v0.2

"One ZIP per chart, PDF plus JSON, on CIS's bucket with an event. The right side is what real exports have today against what we need. Biggest gap: no signer or credential. Also no facility, payer or HCC model version. Confidence is a raw count, not zero to one. Three assertion flags, not six. One code, not all candidates. The ask of CIS is per field: present, can add, or not available. First step is one sample ZIP."

## Slide 12 — Policy lane

"This is Reva's PRM, and the shaded row at the bottom is the only part that's ours. A PDF goes in, policy-to-logic drafts, PRM stores a snapshot, checks run, coders review through PRM's API, revisions loop, a second person promotes, the auditor fetches the active set from PRM. We copy PRM's tables nightly for explain, eval and audit. The copy never drives a decision, and we never write to PRM."

## Slide 13 — Accounts, buckets and roles

"This is the access picture behind decision two. One rule for reading it: every arrow points at a storage box and says who reads or writes it. Storage lives in its owner's column; the other side reaches across with the role in the yellow box.

Left, CIS. They own the chart bucket. Charts in, results out, decisions back, all in their bucket. Our jobs reach across: read in and decisions, write out. CIS needs no access to anything of ours.

Middle, the hub, wherever decision one puts it. We own the handoff folder: we write the clean chart JSON, the components write the graph and the verdicts back into it. They get one role: read ccdm, write ctg and determinations. We also own the lake tables, reference data included; only our jobs write there, and everyone else comes through the doors.

Right, Reva's account. PRM is the store of record. The auditor reads its rules from PRM by API, inside that account. Our nightly job reads PRM for the copy. We never write to PRM.

Three cross-account grants in total, the yellow boxes. Every arrow is a file, an event and a job. Nothing polls, nobody shares a bucket. This is what I need from whoever owns the middle column."
