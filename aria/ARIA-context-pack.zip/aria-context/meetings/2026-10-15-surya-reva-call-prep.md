# 2026-10-15 — Surya + Reva, 9:30–10:00: CIS dates, tech stack, roles (call script)

Why this call: Binod (CIS) gave dates on Oct 14 (data on S3 by Oct 30; demo to internal customers before Thanksgiving) and hadn't heard about Amit's role. Context: `meetings/2026-10-14-reva-goals-review-notes.md` (Reva meeting + Binod exchange). Leave the call with: (1) an answer for CIS on the dates, (2) the platform decisions needed to start building for real, (3) one sentence on roles and who briefs Tejveer and Cloud.

## 0–3 min — Open

Say: "Thanks for the time. Three things in 30 minutes: what we tell CIS about their dates, the platform decisions I need to start building properly, and how we present the roles to CIS and leadership. I'll send the actions after."

Facts, said once, not debated: "Binod says CIS is building an AWS service that publishes the NLP JSON plus the chart to S3 with an event notification. They target Oct 30 for the data, and leadership — they met yesterday morning — expects a demo to internal customers before Thanksgiving. Tejveer, Sundar and Cloud are tracking it. He hadn't heard about my role and asked for Tejveer and Cloud on a call. I told him the commitments sit with you two and asked him for a sample JSON."

## 3–10 min — The CIS dates (Surya and Reva decide)

Ask: "What do we tell CIS — are these dates real for us, or something to reset?"

What Amit can offer, to anchor the decision (say only if asked):
- By Oct 30: ready to receive their feed — S3 → bronze → silver CCDM — on their real JSON, if a sample arrives by about Oct 20 and the S3 access is set up. Slice 1 already runs end to end on synthetic data.
- Before Thanksgiving: a data-hub demo on real CIS data is doable. Anything that shows the abstractor or auditor depends on Reva's POC — Reva's call.
- Simplest demo story: CIS feed → data hub → Reva's POC → output back. What's missing is the plumbing between the three, which is my part.

Capture: the one-line answer to Binod, and who sends it.

## 10–22 min — Tech stack: what I need from Surya to start

Reva's position from Oct 14: hybrid is fine with a clear contract; his components run on Kubernetes on AWS; data concerns on Databricks is OK with him.

1. Platform: is Databricks the home for the ARIA data hub (bronze/silver/gold, reference tables, CTG, policy store)? Which workspace and catalog for shared ARIA dev — a new `aria` schema, and who creates it? (Today: ai_engineering_dev, my personal schema.)
2. CIS S3 → Databricks: external location + storage credential on CIS's bucket (cross-account IAM), or CIS pushes into a bucket of ours? Who on the platform side sets that up (Yesh's team?) and what is the lead time? Is Auto Loader file-notification mode (SQS) allowed?
3. PHI: real CIS charts are PHI. Which workspace/catalog is approved for PHI? Can the Oct 30 feed land in dev, or de-identified only?
4. Output back to CIS: S3 JSON drop for now, API later. Where would the API run — Databricks Apps / Model Serving, or Reva's Kubernetes platform?
5. How Reva's components read and write the hub: SQL warehouse + service principal, Delta Sharing, or REST? One ARIA service principal?
6. Repo and CI: Bitbucket repo (`dbx-dataops-aria`?) under which project, and who creates it; Jenkins shared library (Track B) or the new Bitbucket Pipelines SOP; branch model develop/main vs dev/mvp/prod.
7. If time: prod path (mvp/prod workspaces, serverless OK in prod), anything to keep portable for the GCP move, and whether I'm alone on this for now.

## 22–27 min — Roles and CIS communication

Say: "Binod's confusion came from not having heard about me. Can we all use one line: Reva owns the AI components; I own the data in and out of them — the data hub. One ARIA pipeline; Surya's team provides the data engineering."

Ask:
- Surya, can you brief Cloud and Tejveer? (Cloud is Surya's boss; this shouldn't come from me.)
- Who is on the Binod call: Binod plus us three; Tejveer/Cloud only if Surya wants. I'll send the invite today with three questions: sample JSON and how the chart is referenced; the S3 event mechanism and AWS account; how CIS wants ARIA's output back.

## 27–30 min — Close

Recap decisions and owners. Mine: architecture v6 + data-artifact blueprint (Reva's ask), the Binod call, weekly Reva catch-up, the repo once Surya confirms. Reva: POC code into a repo. Surya: platform owners, and the Cloud/Tejveer briefing.

## If asked

- "Where are you today?" — "Slice 1 runs on serverless: Auto Loader → bronze → silver CCDM v0.1 (encounter, condition_mention, quarantine), idempotent, on synthetic NLP JSON. Reva reviewed the reference tables yesterday: real projections of the CCDM, one-to-one."
- "How long to adapt to real JSON?" — "The parser is one file plus the rules; days, not weeks, once I have a sample."
- "Can you do Oct 30?" — "Yes for receiving the feed into bronze/silver, with a sample by about Oct 20 and S3 access. I can't commit anything on the AI side."
- "Databricks or AWS?" — "Reva said it's fine either way with a clear contract. Databricks is where our data engineering standard is going, so my default is Databricks for the data, Kubernetes for Reva's components, S3 as the handoff both ways. Your call."
