# Meet-and-greets — Sep 16, 2026 (Yesh, Nikhil, Rutvi)

Source: three voice transcripts in D:\Cotiviti\meetings (AI-generated, transcription is rough — names and product terms below are best readings). Context: Amit's second week; design proposal meeting with Reva/Surya is the next day (Sep 17).

## Yeshwanth "Yesh" Jagini — Databricks platform/admin side (14:32)

- Everything under Surya runs on Databricks, but Cotiviti has several other lakehouses (AWS and others) because of acquisitions. An ML cluster was cut over from on-prem (Cloudera) to Databricks in June; a few other clusters are still on. The data map (which data lives in which lakehouse) is confusing; nobody has a straight answer. Advice: focus on the task at hand and learn outward from there.
- No official platform team yet. Yesh's reports act informally as the Databricks platform team; he hasn't "opened the floodgates" company-wide. Go to Yesh for anything on access, platform, Databricks.
- GCP: exploration done in July in a Google-provided sandbox (took Databricks use cases, worked out what components to swap). No progress since; contracts, networking and security being set up. Cotiviti GCP account expected around end of October. No GCP environment exists yet to request access to.
- Claude Code setup: no API key needed; access is via an AD group. Amit's login failed for lack of that group — request raised.
- Process: standard agile, multiple teams, Jira.
- Follow-up: Yesh to send Confluence links (Databricks docs).

## Nikhil Shivalkar — Director, Data Ingestion & Architecture (15:42)

- His team is building a Lakehouse on AWS (for now) that pulls data from different products with a semantic layer on top for BI/analytics. Bronze/silver/gold already defined; one full business unit's data already loaded.
- Also building a new company-wide ingestion/data platform with Edifecs Smart Trading as the core ingestion engine, replacing a ~6-year-old homegrown ETL tool ("Nile" per transcript; Airflow-like UI, Cloudera backend). Cloudera migration goes in phases: prepay side first, then postpay.
- Ingestion patterns supported today: Oracle/RDBMS and customer files; they also have JSON and Kafka patterns, so ARIA's Kafka JSON feed could reuse their setup.
- Nikhil's ask: collaborate and co-locate data. Even if ARIA needs something new, build it in their lakehouse so the company doesn't end up with five AWS instances holding five datasets. Medium-term goal is moving to GCP; wants a central asset inventory.
- He pulls product-enriched, already-coded data (post-CIS) for analytics; only structured data so far, not unstructured. Charts belong to Health Enablement (multiple products under it); they are starting to pull structured Health Enablement data.
- Amit clarified: ARIA's input is structured JSON from CIS's NLP via Kafka, not raw charts; bronze keeps the unmodified event for replay. Nikhil: fine, they have JSON + Kafka patterns.
- Follow-ups: Amit to confirm with Reva whether CIS can publish to Kafka; reconnect with Nikhil once platform/lakehouse decisions are made.

## Rutvi Mistry — Manager, Data Eng AI (16:00)

- Rutvi is moving to a new team: manager → IC, as principal product manager, hands-on, in the RCA (Retrospective Claim Analysis) area. 9+ years at Cotiviti, ~7 in this team, manager for ~7–9 months with ~10 reports; wants to be hands-on again. Team is moving from "AI solutioning" to the enterprise platform and data team under Surya.
- Offered to help brainstorm GenAI/agentic solutions. Mentioned a data-modeling problem (every client sends the same field, e.g. claim ID, under a different name; needs standardizing so AI can consume it) they designed a solution for.
- Her read: ARIA is bigger than a one-person project; Surya may add folks.
- Amit's framing of his role: Principal Data Engineer with an AI prefix — data side integrated with AI components, wants hands-on exposure on the AI side too.

## Open follow-ups for Amit

- Get the Claude AD group access (ticket raised).
- Read the Confluence links Yesh sends.
- Ask Reva: can CIS publish NLP output to Kafka; which Health Enablement product the charts come from.
- Reconnect with Nikhil on lakehouse co-location and ingestion reuse after the design is agreed.
- Reach out to Rutvi for GenAI brainstorming.

## Added Sep 17 — what to say to Reva/Surya about Nikhil's lakehouse

Mention it as a platform input, not a design change: the layers, CCDM, graph and version keys are the same wherever the tables live. Agree to co-locate subject to three checks: (1) is his lakehouse Databricks on AWS or a native AWS stack; (2) is his Kafka/JSON ingestion pattern streaming (minutes) or batch; (3) is the environment approved for PHI. Add as a 7th question on the "What I need from you" slide.
