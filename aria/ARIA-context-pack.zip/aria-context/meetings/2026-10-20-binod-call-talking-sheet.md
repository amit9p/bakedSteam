# Talking sheet — Binod's ARIA update, Tue Oct 20, 9:30 (say it as written)

Reva leads. You speak at four moments. Everything else: listen, take notes.

---

## 1. When roles come up, or right after hellos

"Quick line on who does what, since it caused confusion last week. Reva owns the AI components, including the policy tool. I own the data in and out of them — the data hub. It's one ARIA pipeline; Surya's team provides the data engineering."

## 2. When the task list reaches you

"Five tasks on my side, with dates that depend on inputs.

One — the ingress contract with CIS, written down: file layout, chart reference, event, AWS account. One week after I get a sample JSON.

Two — our pipeline reading your real JSON into the raw and the clean clinical tables. About a week after I have the sample and read access to the bucket. It already runs end to end on synthetic data in the shape I'm assuming.

Three — reference data loaded: the CMS code list and HCC map, and a mocked clinical word list until the real taxonomy extract arrives. This week.

Four — the policy-store tables behind Reva's policy tool: policy documents, rule-set versions, rules, coder reviews. Two weeks, once Reva confirms the rule format, so the tool writes into the hub from day one and nothing has to be migrated later.

Five — the format of the results we send back to CIS. After item one, once we know how your app wants to consume it."

## 3. Asking CIS for what you need

"Three things from your side would unblock most of that.

A de-identified sample of the JSON for two or three charts, and how the chart file is referenced from it.

The event mechanism — S3 event to SNS, SQS or EventBridge — and which AWS account the bucket lives in, so our platform team can set up read access.

How your application wants the results back: poll a bucket, subscribe to an event, or call an API.

I've written down the layout I'm assuming. I'll send it right after this call — please correct it from a real sample. I'd rather be wrong on paper now than in code later."

## 4. When the policy tool is discussed

"The tool itself is Reva's. The storage behind it is mine: the policy documents, every version of every rule set, the rules, and the coders' reviews, all kept and replayable. I'll have those tables ready in dev in two weeks. What I need from Reva is one sample of the generated rules to settle the columns."

---

## If asked

**"Can you make October 30?"**
"October 30 is your date for the feed, and that's fine. We'll be ready to receive it within about a week of getting the sample and the access. What gets shown before Thanksgiving is Surya's and Reva's call, and they're aligning with Tejveer and Cloud on it."

**"Databricks or AWS?"**
"Being decided this week with our platform leads, Nikhil and Yesh. The contract with you doesn't change either way: S3 in, S3 out."

**"What have you built so far?"**
"A pipeline that lands a chart file into a raw table, keeps the latest copy per chart, splits it into a visit row and one evidence row per NLP mention, checks the codes, translates the assertions into our shared vocabulary, and sends anything that fails a rule to a quarantine table with the reason. Runs on serverless Databricks, re-runs cleanly."

**"What if our JSON looks different from what you assumed?"**
"Expected. The mapping is in one file and the accepted values are a list. Days to adapt, not weeks. The one thing that would hurt is if the output has no page numbers or character offsets — then a lot lands in quarantine and we'd need a conversation with the NLP side."

**"Where will our data sit? It's PHI."**
"In our governed workspace with access control on every table. Which workspace is approved for PHI is being confirmed with the platform team; a de-identified sample is enough for development."

**"Do you need our word list?"**
"Yes, please. Whatever terms and codes the NLP emits, we normalise to the shared schema; an extract of the word list makes that exact instead of guessed."

**"Who else is on your side?"**
"Me on data engineering for now, under Surya, with platform support from Yesh and Nikhil."

**"Can we call an API for the results?"**
"Results per chart go to S3 first. An explain API for coder-time questions — 'why no evidence for this code?' — comes after; tell us what your screen needs."

## Do not say

- Any commitment to Oct 30 or the Thanksgiving demo as ours.
- A platform preference.
- Anything about inviting Tejveer or Cloud.

## After the call, same day

- Teams to Binod and Venkateshwar: the contract draft, one line: "The layout I'm assuming — please correct it from a real sample."
- The agreed task list with owners and dates, to all attendees.
- Outcome into the knowledge base.
