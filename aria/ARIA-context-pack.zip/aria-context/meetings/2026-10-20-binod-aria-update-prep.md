# 2026-10-20 — Binod (CIS): "update about project ARIA", 9:30–10:00 (prep sheet)

Invite from Binod Chamoli, sent Mon Oct 19 12:12 PM. To: Reva, Venkateshwar Eaga, Amit. Cc: Tejveer Singh. Agenda, his words: "Task list for policy tool and wordlist/coding. Please come prepared to discuss."

## Read the invite

- This is CIS running the program, not a design discussion. Binod wants a task list: who does what, by when, against the Oct 30 / pre-Thanksgiving dates his leadership set. Tejveer on cc is the audience for that list.
- "Policy tool" = policy-to-logic, Reva's "first lane" (guideline document → generated rules → coder review → approved rule set). Reva owns it.
- "Wordlist/coding" = most likely the clinical word list the NLP side works from (terms, synonyms, codes) and the coding output. Confirm the meaning with Reva before the call; it touches our reference data (vocabulary, taxonomy concepts) and the coding recommendations.
- Venkateshwar Eaga is probably the India-based data scientist Reva mentioned on Oct 15 as helping CIS with the feed. First time meeting him.

## Before the call (Mon Oct 19)

1. Ten minutes with Reva: he leads; agree what "policy tool" and "wordlist/coding" mean in Binod's vocabulary; what Reva will put on the task list; what Amit's tasks are and their dates; the one-line roles statement.
2. Tell Surya the meeting exists (Tejveer is on cc) and ask whether he has spoken to Tejveer and Cloud yet. If not, say nothing about program commitments in the call beyond the data-side tasks below.

## Amit's part in the call

Roles line, said once: "Reva owns the AI components, including the policy tool. I own the data in and out of them — the data hub. One ARIA pipeline."

Data-side task list to offer (dates conditional, say so):

| # | Task | Needs | Date |
|---|---|---|---|
| 1 | Ingress contract with CIS written down: file layout, chart reference, event mechanism, AWS account | sample JSON from CIS | one week after the sample |
| 2 | Pipeline reading the real CIS JSON into bronze and silver (CCDM) | sample JSON + S3 access | about one week after both |
| 3 | Reference data loaded: CMS code list + HCC map; mocked clinical word list until the taxonomy extract arrives | nothing | this week |
| 4 | Policy-lane data: policy document store, rule-set versions (draft → reviewed → approved), coder feedback on rules — tables ready for the policy tool to write into | Reva's rule format | two weeks |
| 5 | Egress contract: results per chart back to CIS (S3) — format agreed with CIS | CIS's view of how they consume it | after item 1 |

Three questions for Binod / Venkateshwar (the same three from Oct 14, still open):

- A sample of the JSON, de-identified, and how the chart file is referenced from it.
- The event mechanism (S3 event → SNS/SQS/EventBridge?) and which AWS account the bucket lives in.
- How CIS wants to receive ARIA's output: S3 drop, and is there an API call at coder time?

## Do not

- Commit to Oct 30 or the Thanksgiving demo as ours. Those are CIS's dates; Surya and Reva own what we say back.
- Discuss Databricks vs AWS. Not decided; the design review with Nikhil and Yesh decides it. If asked: "the data hub platform is being decided this week with our platform leads; the contract with CIS doesn't change either way."
- Invite Tejveer or Cloud to anything. Surya's job.

## Briefing — the three things Amit brings, and how to talk about them

**1. The ingress contract (hand it over).** `aria/aria-ingress-contract-draft-v0.1.md`: the S3 layout, the event, the JSON per chart with every field and what ARIA does with it, the quarantine rule, a sketch of the output, the four asks. Say: "Here's the layout I'm assuming, written from what Reva and Binod described. Please correct it from a real sample; I'd rather be wrong on paper now than in code later." Then go straight to the four asks at the bottom.

**2. Bronze and silver on their JSON (what exists, what changes).** Today the pipeline lands a JSON file into a raw table, keeps the latest copy per chart, splits each chart into a visit row and one evidence row per mention, checks the code format, translates the assertion into our vocabulary, and sends failures to quarantine with reasons. It runs on serverless Databricks and re-runs cleanly. When the real JSON arrives, two things change: the field mapping in one file (silver.py) and the list of accepted assertion and section values. That's days, not weeks; the week in the estimate is mostly waiting on access. The risk to name honestly: if the real output lacks page numbers or character offsets, a lot lands in quarantine and we need a conversation with the NLP side.

**3. The policy-lane tables (Reva's tool, our storage).** The policy tool reads a guideline document and generates rules; coders review them; only approved rule sets run on charts. ARIA keeps that data: `policy_document` (the guideline, versioned), `rule_set` and `rule_set_version` (draft → reviewed → approved, old versions kept), `rule` (one per rule inside a version), `rule_review` (coder feedback on a rule). Two weeks once Reva confirms the rule format. Say: "The policy tool is Reva's; the storage behind it is mine, so every rule version and every coder comment is kept and replayable."

**The 60 seconds, if asked "what's your part?":** "I own the data hub: your feed in, our results out, and everything kept in between — the clinical tables, the truth graph, the recommendations, the rule versions. The pipeline already runs on synthetic data. To run on yours I need a sample JSON and bucket access; here's the layout I'm assuming. From there it's about a week to land your real data."

## After the call

- Send the task list as agreed, with owners and dates, to the attendees the same day.
- Add the outcome to the knowledge base; update the design review deck's phases slide with whatever dates were actually agreed.
