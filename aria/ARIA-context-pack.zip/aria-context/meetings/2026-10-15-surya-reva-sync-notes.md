# 2026-10-15 — Surya + Reva + Amit, 9:30: CIS dates, tech stack, roles (meeting notes)

Source: `D:\Cotiviti\meetings\Voice 261015_093037reva-surya-10-15-2026_original.txt` (AI transcript, 18 min recorded; Speaker 1 = Surya, Speaker 2 = Amit, Speaker 3 = Reva). Prep: `meetings/2026-10-15-surya-reva-call-prep.md`. Trigger: the Oct 14 Teams exchange with Binod (see `meetings/2026-10-14-reva-goals-review-notes.md`).

## Outcome in five lines

1. **Platform not decided, but unblocked.** Surya: "we have optionality — Databricks or AWS, pros and cons." Process agreed: Amit presents the pipeline design at a **design review with Nikhil Shivalkar and Yesh added** (Yesh provisions Databricks; Nikhil runs the AWS pipelines behind the lakehouse); they weigh in on options, Surya's group writes up a recommendation with pros and cons, Amit takes it back to the wider group. Surya: "that's not a blocker for you."
2. **Role confusion is now Surya's to fix.** He wasn't surprised ("silos, initiatives not connected, alignment not happening at the right level"). He is setting time with Tejveer and Cloud today/tomorrow to align on expectations and on how ARIA's dependencies are tracked in the program. Reva will also raise it with Cloud (he hadn't yet; Cloud was out last week).
3. **Dates: no commitment made.** Oct 30 (CIS drops NLP JSON + chart to S3) was restated as ingress only; the pre-Thanksgiving demo was noted, not accepted. Surya will hear the stakeholders' expectations from Tejveer/Cloud first.
4. **Surya's instruction to Amit: don't wait.** Define the interface and contract with CIS; where information is missing, mock it ("this is the file layout I expect CIS to dump") and build against the assumption while alignment happens.
5. **Amit's next move:** finish the design changes from Reva's review (v6), then set up the design review call with Surya, Reva, Nikhil and Yesh; the tech-stack call is made there.

## What was said

### Reva's grounding for Surya (the handoffs)
- ARIA is delivered to coders through the CIS application: a separate screen/app from today's, powered by our pipeline. CIS builds on the NLP system; our biggest dependency is the NLP-extracted concepts, entities and codes, which we don't have access to today.
- Flow: a chart is processed → CIS is notified → CIS curates the input we need per chart and dumps it to an S3 bucket → our pipeline is triggered by that event → does its work → writes coding recommendations plus a lot of metadata to an S3 bucket → CIS reads it through an event mechanism and displays it to the coder. That is the whole handshake: CIS gives input, we generate output, CIS displays it.
- Binod leads engineering on the CIS side; someone from India (a data scientist, name unclear in the transcript) is helping. Reva syncs with them weekly to finalise the shape and format of ingress and egress.
- Program status: a program exists, driven by program/project managers; Tejveer is one of the engineering leaders. What exists technically is POC-quality code for the whole agentic pipeline, written by Reva, not checked in anywhere; ARIA is a thin wrapper around it. "We don't have anybody; we're desperately trying to get resources."

### The Binod gap
- Reva had told Binod about Amit in the last two syncs and asked whether they had connected; Binod wasn't aware of Amit at all the first time. Reva: "in Binod's world everything is very simple — he thinks in terms of S3 buckets; the architecture to manage the data through the pipeline is something he's oblivious to." That's where the gap is; the data engineering in between is owned by Amit.
- Surya: not surprised; different people chasing different priorities; "let that not discourage you." It's a matter of aligning with Tejveer and Cloud, which he'll do, including which program pieces need to track our dependencies.

### Tech stack
- Amit: stack for the data pipeline still open (Databricks vs AWS); development starts once it's decided.
- Surya: both are possible with pros and cons; give him the conceptual flow and where the data comes in; he'll bring the right people, get options written up with a recommendation, and Amit presents it with pros and cons. For the design review, add Nikhil (AWS, lakehouse pipelines) and Yesh (Databricks provisioning).

## Agreed actions
- Surya: talk to Tejveer and Cloud (time being set up today/tomorrow) about alignment, expectations and program tracking of ARIA's dependencies.
- Reva: raise the same with Cloud in his own sync.
- Amit: define the CIS interface/contract; mock the input layout where unknown and keep building. Finish architecture v6 (Reva's six changes). Set up the data-pipeline design review with Surya, Reva, Nikhil, Yesh.
- Open from the prep sheet, not covered in the 18 minutes: the one-line roles statement for CIS; who joins the Binod call; PHI rules for real CIS data in dev; repo/CI path. Carry to the design review or to Surya 1:1.

## Names
- Nikhil Shivalkar — Director of Software Engineering (Data Ingestion & Architecture); AWS pipelines powering the lakehouse. To be on the design review.
- Yeshwanth "Yesh" Jagini — Manager Data Eng AI; Databricks provisioning and platform admin. To be on the design review.
- Tejveer — engineering leader on the program; Surya will align with him.
- Cloud (Xia) — head of the AI group; Surya and Reva will both brief him.
- Binod Chamoli — CIS engineering lead, ingress/egress counterpart.
