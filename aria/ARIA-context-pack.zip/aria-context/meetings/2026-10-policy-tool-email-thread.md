# "Policy Tool" email thread — Binod ↔ Reva, cc Cloud (and Tejveer from Oct 21)

Source: Outlook screenshots photographed Oct 20 (1:03 PM, 1:06 PM) and Oct 21 (Reva's 8:13 PM reply, Binod's 7:36 AM reply). Subject "Policy Tool" / "Re: Policy Tool". Amit is cc'd on every message and has not replied; nothing in the thread is addressed to the data hub. Reva's doc for reference: `confluence/p2l-rule-review-design-and-build-guide-reva.md`.

## 1. Binod, Tue Oct 20, 1:03 PM — "Policy Tool" (to Reva; cc Amit, Cloud)

Verbatim:

> Hi Reva,
> I took some time to review the document you shared. For our first milestone, we need to make the Policy Tool available for our clinical validators. Based on my understanding, here is the workflow along with the open items that need to be addressed before we can move forward.
>
> Five steps carry a policy document from upload to an approved rule set ready for coding.
>
> **Document Upload & Rule Extraction.** The user uploads a policy document to the tool. The document is placed in a designated S3 location. From there, an LLM API call processes the document and decomposes it into discrete, structured rules derived from the coding guidelines. *Open item: confirm which LLM API and invocation pattern (synchronous call vs. event-triggered on S3 upload) will be used.*
>
> **Rule Output & Retrieval.** The LLM returns a structured output containing the extracted rules. This output needs a defined access pattern, likely written to a storage location or returned via API response so it can be retrieved and rendered in the UI. *Open item: define the output format and the retrieval mechanism for the UI layer.*
>
> **User Review.** Once rules are displayed in the UI, the user reviews each one individually and either approves or rejects it. The user can also attach free-text feedback or comments to any rule, regardless of the decision made.
>
> **Decision Storage & Downstream Sharing.** Each rule's decision (approved or rejected) and accompanying comments are persisted in the database. Where applicable, this data can also be shared with other systems through an API if one is available for consumption.
>
> **Finalization for Coding.** Once the full document's rules have been reviewed, whether entirely approved or a mix of approved and rejected, the finalized rule set is used as input to the coding process.
>
> **Data Flow Diagram:** Admin → uploads policy → Storage (S3) → Processing [LLM API → Rules output (JSON)] → UI [Display Rules] → User decision → Approve/Reject (+Optional Comment) → Persistence (DB) → downstream API → Agentic Hub.
>
> [Diagram, top to bottom: User — Upload policy document → Storage — S3 `policy-documents/` → Processing — LLM API extract rules → Rule output (JSON) → Policy Rule Tool UI — Display rules for review → User decision per rule → Outcome — APPROVE + optional comment / REJECT + optional comment → Persistence — Database (rule + decision + comment) → Downstream API (if applicable) → Final Use — Document fully reviewed → Finalized rule set used in coding process. Legend: process step, LLM/AI processing, storage layer, approved path, rejected path.]
>
> **Open items to resolve before implementation:** (1) which LLM API and invocation method will perform rule extraction, (2) the exact output schema returned by that process and how the UI will retrieve it, and (3) which downstream API, if any, should receive the approved/rejected rule data.
>
> Please let me know if this aligns with your understanding, or if there are any corrections or additions needed.

Read against Reva's doc (the two pictures do not match; this is Reva's to correct, not Amit's):

| Binod's email | Reva's design |
|---|---|
| CIS's tool owns the flow: upload → S3 → "an LLM API call" → JSON → CIS UI → CIS database → "downstream API → Agentic Hub" | PRM (Agentic Hub) owns the flow: register in PRM → draft **job** (SQS, Textract + Bedrock; slow, costs money, never "just re-run") → immutable snapshot in PRM → CIS UI is a thin client of PRM's API → reviews stored in **PRM's** Postgres. Data flows from the hub to CIS, not CIS to the hub |
| Review = approve / reject + free-text comment per rule | Review = approve / reject / **revise** per item at a fingerprint, on three kinds of item (rule, value set, claim code set); revise loop produces new snapshots until converged |
| "Finalized rule set" may be "a mix of approved and rejected" | Converged = every in-scope rule approved; promotion needs a second sign-off; "nothing reaches production unapproved; the API enforces it" |
| Decisions persisted in CIS's database (Aurora) | Decisions are PRM records; the lake gets a nightly copy; CIS keeps nothing of record |
| Three open items: LLM API + invocation, output schema + retrieval, downstream API | These are Reva's four frozen contracts (API spec, job message schemas, store interfaces, access matrix) and the Stream G mock: milestone M0 |

## 2. Binod, Tue Oct 20, 1:06 PM — "Here is the UI that we have developed and deployed in our QA" (screenshot)

The app is branded **cotiviti · Policy Rule Review**, subtitle **"DM · CKD · CHF MEAT ruleset · Symbolic Auditor v2.3"** (so the sample rules came from Reva's auditor POC and his pilot HCCs: diabetes, CKD, heart failure). Status chips: Draft 4 · In review 3 · Revision needed 1 · Approved 0. Signed in as **Tejveer Singh**; nav: Rules, Users, Change password, Sign out.

Left panel: search by rule ID or title; category filter; "My queue". Rule list (id · status · title · category · layer · assignee):

- RA-ALL-L1-046 · In review · Radiology and lab reports are not acceptable… · ALL · Layer 1 · You
- RA-ALL-L1-047 · In review · Resident-authored note without teaching-p[hysician]… · ALL · Layer 1 · You
- RA-ALL-L2-042 · Draft · Negated or resolved condition is not an acti[ve diagnosis]… · ALL · Layer 2 · Unclaimed
- RA-ALL-L2-043 · Draft · Family-history mention is not a patient diag[nosis]… · ALL · Layer 2 · Unclaimed
- RA-ALL-L4-044 · Draft · Audio-only telehealth encounter is not risk-a[djustable]… · ALL · Layer 4 · Unclaimed
- RA-DM-L4-048 · Draft · Diabetes documented with CKD — complic[ation]… · DM · Layer 4 · Unclaimed
- RA-ALL-L2-041 · In review · Uncertain diagnosis — outpatient exclusion · ALL · Layer 2 · Venkateshwar Eaga
- RA-ALL-L1-045 · Revision needed · Unsigned note cannot support a diagnosis

Rule detail (RA-ALL-L1-046, In review, v1; tabs "Rule detail" and "Version history (1)"; tags Documentation Completeness · ALL · Layer 1):

- Title: *Radiology and lab reports are not acceptable risk-adjustment sources*
- Description: "Excludes diagnoses supported only by a radiology report or a laboratory report, which are not acceptable source documents for risk-adjustment diagnosis capture. The finding may still support another provider's documented diagnosis. AI-assisted draft: confirm the citation and the list of excluded note types before approval."
- IF: `note.noteType IN (radiology_report, lab_report)` [+ Comment]
- THEN: **Exclude** — `Set disposition = EXCLUDE · reason_code = NON_ACCEPTABLE_SOURCE_TYPE` [+ Comment]
- Policy citation: "Medicare Managed Care Manual, Chapter 7 — Risk Adjustment (to be confirmed) — Acceptable provider and source types for risk-adjustment diagnoses — to be confirmed" [+ Comment]

Right panel "Your review": "+ Add clause feedback"; overall verdict = Approve / Approve with minor edits / Revise & resubmit / Reject; "Submit review".

What the screenshot tells us:

- **The UI is closer to Reva's loop than Binod's 1:03 email said.** It has versions and a version history, a "Revision needed" status, per-clause comments, and four verdicts (two of which are "revise"), not just approve/reject. The data model behind it is: rule id, title, category (ALL / DM …), layer (1–4), status (Draft → In review → Revision needed → Approved), assignee, version, description, IF predicate over CCDM-style fields (`note.noteType`), THEN action (`disposition`, `reason_code`), citation (manual, chapter, section, "to be confirmed" flags), clause comments, verdict. Reva's PRM API has to serve exactly these; our lake copy (Stream H) will carry these columns.
- **Rule ID scheme** `RA-<category>-L<layer>-<nnn>`: RA = risk adjustment; category ALL or a condition (DM); layer 1–4 appears to be the auditor's gate order (1 documentation/source validity, 2 diagnosis validity — negated, family history, uncertain, 4 encounter/condition-specific). Our gold rows should record rule id + version + `disposition` + `reason_code`; those reason codes (`NON_ACCEPTABLE_SOURCE_TYPE` …) are the vocabulary the Explain API will surface to coders.
- **Users exist and Tejveer is in it himself**, with Venkateshwar as an assignee. The "clinical validators" Binod named are real people waiting on content.
- What it does not show: fingerprints/digests, snapshots, value sets or claim code sets, a promotion gate, or where decisions go after "Submit review" (Binod's email says CIS's database). Those are the gaps Reva's design fills.

## 3. Reva, Tue Oct 20, 8:13 PM — "Re: Policy Tool" (to Binod, Amit, Cloud)

Verbatim:

> Thanks Binod for the review. The five steps are close to the happy path, but five points need correcting. Details are in Appendix E (diagrams) and Appendix H (API) of the P2L Rule Review Design and Build Guide.loop.
>
> **1. Upload and extraction**
> - Policy package: what the user submits is either one PDF, or one ZIP containing several files and a manifest.json. The manifest follows a schema we will publish.
> - Upload flow: your backend makes three calls. Ask our API for an upload URL, sending the file's name, type, size and sha256 plus payer, edition and effective dates. PUT the file to that short-lived URL. Call "complete".
> - We verify size, checksum and real file type, and for a ZIP we list its entries and check the manifest. Only then do we queue the work, or we return the reasons for rejection. Your backend retries a failed upload until the URL expires, or asks for a new URL. You need no standing access to our storage.
> - Extraction is asynchronous: it is a queued job (text extraction with Textract, structural parsing, semantic chunker, hierarchy mapper, etc.) then synthesize using LLM calls, plus validation and repair). It takes hours for a full guideline. It is not triggered by S3 events. The UI shows job status. See the P2L design doc "Policy-To-Logic (P2L) Overview, Architecture, and Evaluation.loop" for more details.
>
> **2.** The UI never reads the model output or S3. Rules are stored as an unchangeable version, and the UI reads them only through our API (worklist and rule detail).
>
> **3. Triage and decisions**
> - Triage: an automatic check runs first. Only rules that pass ("ready") are shown to coders.
> - Decisions: approve, approve with minor edits, revise (with the corrected IF/THEN) or reject. Reject and revise need a reason from a structured list; the comment is always optional.
> - Value sets and claim code sets: two further item types use the same API and can follow in a later release. BTW, this is a new need and requires UX change.
>
> **4. Storage:** decisions are saved by our service, not a CIS database. CIS stores nothing that counts as a review. Each decision is tied to the exact version the coder saw, so a stale submission returns 409 and the screen must refresh.
>
> **5. Finalization:**
> - Feedback loop: reviews go back to the rule generator, which produces a new version, and only changed rules return to coders.
> - Promotion: a ruleset reaches production only through promotion: every in-scope rule approved, a regression report attached, and a second person approving. Rejected rules are never used.
> - Coding: the coding process then reads the active ruleset from us.
>
> **Answers to your three open items**
> 1. LLM and invocation: it's more than an LLM – it's a bunch of processing done in a pipeline to synthesize rules, in our AWS account, run as an asynchronous queued job.
> 2. Output schema and retrieval: you consume our API schema, not the model output. It is the first deliverable. You can build against a mock from then.
> 3. Downstream API: none needed from you. The Agentic Hub platform stores the decisions and serves approved rulesets to the coding process directly. Where records physically live (today a database and storage in our account, later the data hub) will not change the API you call.

## 4. Binod, Wed Oct 21, 7:36 AM — "Re: Policy Tool" (to Reva, Amit, Cloud; + Tejveer Singh)

Verbatim:

> + @Singh, Tejveer
> For the Policy Tool specifically, our proposed approach is to have Admin users upload coding guidelines as a single PDF per tenant, rather than supporting ZIP files with a manifest.json. This would simplify the upload flow on our end and avoid the added complexity of parsing a ZIP archive and validating against a manifest schema. Given this, we wanted to confirm, would a single PDF per tenant meet the requirements on your side as well, or is the ZIP/manifest structure a hard requirement for other reasons (e.g., supporting multiple source documents per policy, or metadata that the manifest captures that a PDF alone cannot)?
>
> Regarding the upload flow, can we simplify this to a single API call to submit the file, or make it event-based (e.g., triggered automatically when the file lands in S3)? A three-step process adds more potential failure points on our end. Let us know if there's a specific reason the current pattern is needed.
>
> For the Policy Tool specifically, we plan to use a dedicated database rather than reusing the CIS database, so this aligns with your approach of having decisions saved by your service. We are open to integrating with any API you provide for this purpose.
>
> Overall, I want to confirm if these all can be accomplished in the given time (2 weeks).

## 5. Reva, Thu Oct 22, 1:30 PM — "Re: Policy Tool" (to Binod, Amit, Cloud, Tejveer)

"I am still sick but I'll send some responses out." Inline replies to Binod's three points:

- Single PDF vs ZIP + manifest: "either a PDF or a zip file works. From what I've seen so far (Aetna and Humana), there's not been a single document that covers everything that's needed to synthesize the rules reliably. However, if there's a case where one PDF is comprehensive, then yes, one PDF is fine."
- Single API call or S3 trigger instead of three calls: "Yes, there are specific reasons, deliberately chosen after weighing several options, their pros/cons and tradeoffs involved. Details can be found in FAQ 1 of the Rule Review design doc."
- Can it all be done in two weeks: "TBD".

For the data hub: nothing changes. Policy packages will usually be bundles (several source documents), which the blueprint already notes for the lake copy (bundle id). The two-week question is still unanswered in front of Cloud and Tejveer.

## Where the thread stands (Oct 22)

- **Reva has set the terms in writing, in front of Cloud:** PRM is the centre; the UI is a thin client of PRM's API; decisions live in PRM, "CIS stores nothing that counts as a review"; extraction is a queued job that takes hours, not an API call or an S3 trigger; the first deliverable is the API schema, and CIS builds against a mock from then. Binod's three open items are answered: no downstream API needed from CIS.
- **Binod has accepted the ownership and pushed on friction:** single PDF instead of ZIP + manifest; one API call or an S3 event instead of three calls; a dedicated database on his side (still a database, but he says he'll integrate with whatever API Reva provides). He added Tejveer and asked the question that matters: **"can these all be accomplished in the given time (2 weeks)?"** That question is now Reva's to answer in writing, with Cloud and Tejveer reading. Reva's doc says no: PRM does not exist, six-week floor, exit criteria not dates; the honest two-week deliverable is the API schema plus a mock (his M0).
- **Reva's one sentence about us:** "Where records physically live (today a database and storage in our account, later the data hub) will not change the API you call." That is Stream H and LAKE-API-1 stated to Cloud as a plan. Expect "when?" to reach Surya; the answer is "after PRM's schema is frozen: nightly copy first (a manual export is acceptable at first, per Reva's doc), the write API at the design review".
- **A second Reva doc exists:** "Policy-To-Logic (P2L) Overview, Architecture, and Evaluation.loop". Amit has not read it. Ask for it; it describes the extraction pipeline (Textract, structural parsing, semantic chunker, hierarchy mapper, LLM synthesis, validation and repair).
- **Still nothing for Amit to reply to.** If Binod's "single PDF per tenant" question is answered with the manifest requirement, note for the lake copy that a policy package can hold several source files plus metadata (payer, edition, effective dates); the catalog of `policy-sources` should carry those fields.

## Side by side: Binod's flow vs Reva's (unchanged from Oct 20, now confirmed by Reva's reply)

| Binod's email | Reva's design (and his reply) |
|---|---|
| CIS's tool owns the flow: upload → S3 → "an LLM API call" → JSON → CIS UI → CIS database → "downstream API → Agentic Hub" | PRM owns the flow: upload through PRM's three-call API → queued job (hours) → immutable version in PRM → UI reads worklist and rule detail through PRM's API → decisions saved by PRM. No downstream API from CIS |
| Review = approve / reject + free-text comment | Approve / approve with minor edits / revise (with corrected IF/THEN) / reject; reject and revise need a structured reason; comment optional; value sets and claim code sets later |
| "Finalized rule set" may be a mix of approved and rejected | Promotion only: every in-scope rule approved, regression report attached, second person approving; rejected rules never used |
| Decisions in CIS's (or a dedicated) database | Decisions in PRM; a stale submission gets 409; CIS stores nothing that counts as a review |
| Three open items: LLM API + invocation, output schema + retrieval, downstream API | Pipeline job in Reva's account; API schema is the first deliverable, mock from then; no downstream API |
