# 2026-10-14 — Reva: goals review + data-hub unblock (meeting notes)

Source: `D:\Cotiviti\meetings\Voice 261014_140433-reva-discussion-10-14-2026_original.txt` (AI transcript, 53 min; Speaker 1 = Amit, Speaker 2 = Reva). Prep sheet: `meetings/2026-10-14-reva-goals-review-prep.md`. Only Goal 1 was walked through; the rest of the time Reva talked, which was the more valuable half.

## Outcome in five lines

1. The four-layer design is accepted in shape ("right pieces in the right layer"). What Reva wants added is a **data-artifact blueprint**: every type of data the data hub must manage, with its characteristics, storage, access, discovery, versioning and governance.
2. **Ingress changes:** CIS will drop NLP output + patient charts into an **S3 bucket** and fire an **event** that triggers the ARIA pipeline (not Kafka). CIS is staffing this now. Our job is to reconcile that mechanism with the design, by talking to the CIS point of contact.
3. **CIS point of contact: Binod Chamoli**, Director of Software Engineering. Reva has already told them about Amit; nobody had reached out before today (see the Binod exchange below).
4. **POC code:** all written by Reva, not in any repo. His next to-do is to push it to a remote so others can read it; he'll tell Amit when it's there. No access until then.
5. **Priority shift:** build what has the fewest unknowns first. Reva proposes **Policy-to-Logic and its data (policy store, versioned rule sets, coder feedback on rules) as the first deliverable**, then ARIA's core pipeline. Both depend on the CCDM and the data hub, so the data-hub work continues; its order of milestones changes.

**Added the same evening (from Binod, see below): CIS leadership has dates. CIS data available by Oct 30; a demo to internal customers before Thanksgiving. This is earlier than the December milestone in the goal draft and has to be reconciled with Surya and Reva.**

## What Reva said, by topic

### Design and the data hub
- "All data concerns are handled in the data hub." Artifacts he named: golden dataset, CTG, policy guidelines, coder feedback (on coding dispositions **and** on generated policy rules), the silver/CCDM data, plus access controls on all of it.
- The design must describe each artifact type: characteristics, requirements, how it is managed, accessed, discovered. "Come up with a design that says here's how we're going to do it." Then execution can start with a subset.
- Gold output (recommendations) must be managed like the other artifacts but with an extra guardrail: it is the foundation for auditability. A future CMS audit may require not just the final output but the clinical truth graph behind it. Think through storage, access, and exposure through an API for all of these.

### Ingress (CIS → us)
- Latest from Reva's sync with Binod: CIS provides the NLP output along with the patient charts, through an event-driven mechanism: dump into an S3 bucket, triggers fire the pipeline. CIS is engaging resources to build this.
- We must align on how that reconciles with our plan (Kafka was our assumption; S3 + event is theirs). That is the first thing to settle with Binod.

### Egress (us → CIS)
- The pipeline emits recommendations per chart as a unit: not just coding dispositions but the additional metadata needed for explainability. Assume a large JSON payload per chart (per code).
- CIS has to integrate that output **and** access the related data at runtime when a coder asks, e.g., "explain why the system found no evidence for this code." So the data hub must expose gold + CTG + evidence through an API, not only as tables. How CIS intends to consume the output is a question for the CIS team.

### The POC and its components
- No production code exists for ARIA; it is POC code Reva wrote alone. He is cleaning it up (especially the CCDM part, which "has had a checkered origin") and will check it into a remote repo; he'll notify Amit when it's there.
- The POC is a thin wrapper over independent components, exactly as the architecture diagram shows: clinical commons (represents the CCDM); clinical abstractor (wraps the NLP/CIS output, which arrives as **XML** today); symbolic auditor (applies the rules); policy-to-logic (compiles policy documents into rules); a transpiler (converts the rule-engine-agnostic clinical rule language into a specific engine's language, e.g., Drools or Prolog); a **Drools runtime** (the rules engine, running as a service on a port, which the symbolic auditor calls to execute a rule set and get results back).
- Components are simple backend services; they can run in Kubernetes. The agent-builder platform Reva is part of deploys everything to Kubernetes on AWS.

### CCDM — history and direction
- Original intent: CCDM is the one vocabulary every component at Cotiviti speaks.
- Reva could not get access to the NLP team's taxonomy (an API and artifacts) or to another team's (PDX); hit a brick wall. So the CCDM vocabulary grew organically from what policy-to-logic found in policy guidelines (diabetes, labs, treatments…) — the minimum set needed.
- Later he went around the wall: pulled tables directly from the NLP system's Oracle database, the concepts related to the top 50 HCC codes (the taxonomy is ~20M concepts / 40M relationships; only ~5% is used). He uses that today as a reference lookup: ICD-10 code → entity name, concept, synonyms.
- Two recent changes removed the access friction. Direction now: **CCDM wraps the existing taxonomy** and exposes the concepts applications need, through an API, in a controlled data hub, so teams can discover and use it. Gaps go back to the taxonomy team or into a **replaceable augmentation layer** on top of the core taxonomy. Today the taxonomy is only visible through the NLP team's visual tools, with no API.
- On Amit's reference tables (vocabulary, source_map, code_reference): "these are real projections of the CCDM schema, one-to-one." Positive; no objections.

### A second application: coder feedback on rules
- Policy-to-logic consumes a policy guideline document and generates rules, which can be wrong, incomplete, non-executable or inconsistent. Coders must review them; only when they approve a rule set is it used on charts.
- So there are two applications: ARIA (coders see recommended codes) and a new one where coders give feedback on generated rules. Rule review is a build-time activity, repeated whenever a coding guideline changes.
- Every rule set is versioned; every coder review and every system improvement produces a new version; lifecycle draft → reviewed → approved. These rules and the feedback must live in a managed data environment, like the golden dataset. The data hub must manage coding guidelines, rule revisions and feedback.

### Tech stack and platform
- Reva doesn't know Surya's platform (Databricks) or whether CIS uses it; CIS is going to S3 and deploying an application. Whether a Databricks layer sits on top is Amit's decision: "if all the data concerns are managed through Databricks, maybe that's the way to go."
- Stacks don't have to be homogeneous; hybrid is fine as long as there is a clear contract between them and the whole performs at production scale (security, governance, latency, throughput, many customers).
- Three alignments needed: which stack the data comes from, which stack the agentic components run on, and how egress goes back to CIS.
- An early-November workshop (NLP system leaders, CIS, CTO) is meant to align strategy and architecture for the neurosymbolic approach. Don't wait for it: get a clear picture of the tech stack now and start; refine later. Start simple (get CIS output → feed pipeline → consume output back into CIS) without cutting corners on the future vision.

### NLP gaps and build order
- The NLP/CIS output has serious gaps (Reva will raise them with William and other NLP leaders). ARIA fills some today, but they should be fixed at the root: the NLP system should provide entity relationships; "we should not be doing any extraction at all."
- Therefore: start with the piece with the fewest unknowns. Policy-to-logic has the fewest dependencies; its one big unknown is whether it can turn noisy guideline prose into correct, executable rules. First deliverable = policy-to-logic; then shift to ARIA's core; then show the gains on charts (coder productivity).
- But policy-to-logic depends on the CCDM, so the CCDM and the data hub are needed anyway, plus management of coding guidelines and rule revisions. Execution could start with: policy-to-logic, feedback data, policy store and rules.
- Leadership (Tejveer was the name Reva used) has said resources and infrastructure will be provided if needed; with resources, everything can be executed in parallel. The prerequisite either way is the blueprint.

### Demo expectations
- A data-hub-only demo (bronze → gold on synthetic data) is a worthy milestone, like a unit test, and necessary before the next step.
- What people will appreciate is integration with real data flowing through, e.g., the pipeline integrated with policy-to-logic, end to end.

## Agreed actions
- Amit: update the architecture with today's discussion (data-artifact blueprint, S3/event ingress, egress API, policy-to-logic lane first, CCDM-as-taxonomy-wrapper).
- Amit: contact Binod (CIS) about the ingress/egress mechanism and the NLP output. → Done the same afternoon; see below.
- Amit: set up a meeting with Reva and Surya to finalise the tech stack. → Now urgent because of the Oct 30 / Thanksgiving dates; Surya sync first thing Oct 15.
- Amit: set up a recurring weekly catch-up with Reva (he agreed).
- Reva: check the POC code into a remote repo and tell Amit.

## Same afternoon — Teams exchange with Binod Chamoli (CIS)

- Amit introduced himself (Reva's suggestion) and asked for 30 minutes on the S3 feed, a sample payload, and how CIS wants ARIA's output.
- Binod confirmed: CIS is building a **service in AWS that extracts information from the CIS app and publishes to S3; S3 generates an event notification so Reva can consume the data. The data is JSON, along with the chart.** (So JSON, not XML, from the feed; the XML Reva mentioned is what the NLP system produces internally.)
- He was confused by a second consumer ("a component that sits on top of what Reva is building?") and asked whether Surya/Cloud were aware; he had been in a meeting that day and hadn't heard about Amit's role from them. He asked that **Tejveer and Cloud** be included in any call.
- Amit's answer: not on top but inside the same effort — Reva owns the AI components, Amit the data in and out of them; one pipeline, one team; Surya is aware; a call with Reva and Surya to be set up.
- Binod then asked what "data plumbing" means concretely, listing 1) define the database schema, 2) build the logic to store the data, 3) provide APIs to access it. Amit confirmed all three plus ingest from the S3 feed and output back to CIS; Reva owns the AI logic (sent 5:20 PM).
- **Binod, 5:29 PM — the leadership picture.** He is not sure how Amit became involved. **Tejveer, Sundar and Cloud are monitoring the work.** Leadership (they met that morning) expects **a presentation to internal customers before Thanksgiving**, and CIS is **targeting Oct 30 to have the data available**. He offered support, and suggested talking to Tejveer and Cloud directly if there are timeline concerns.
- Amit sent Reva a heads-up at 5:29 PM. Reva, 5:31 PM: "we need to align on the tactical and strategic approaches we'll take. Was the issue with your role sorted?"
- Replies drafted for the same evening: to Reva (not sorted yet; the dates; please join a sync with Surya tomorrow so all three say the same thing); to Surya (15 min first thing Oct 15; he takes the Tejveer/Cloud alignment; agree what is actually committed for Thanksgiving before replying further); to Binod (commitments and demo plan sit with Surya and Reva; ask for a de-identified sample JSON ahead of Oct 30). No invite to Tejveer/Cloud from Amit.
- Learning: CIS leadership had not been told about the data-hub role, and they already have dates. That alignment belongs to Surya and Reva; Amit's part is to make the pipeline ready for the CIS JSON feed before Oct 30.

## Names mentioned
- Binod Chamoli — Director of Software Engineering, CIS point of contact (Teams: "Chamoli, Binod").
- Tejveer — senior leader Binod wants on the call; the same name Reva used for "resources will be provided."
- Sundar, Cloud — named by Binod as leaders monitoring the work, with Tejveer. Roles not yet confirmed.
- William — a leader on the NLP system team (Reva will raise the output gaps with him).

## Open questions carried forward
- Goals 2–4 were not reviewed; Reva's only comment on the goals was on Goal 1's scope (implicitly fine). Needs a follow-up or an email with the draft.
- What exactly is committed for the pre-Thanksgiving demo, and who presents (Surya/Reva to answer). The goal draft's December milestone has to move or be rescoped.
- Which stack for the data hub (Databricks) vs. the components (Kubernetes on AWS) and where the CTG/gold API lives.
- The three questions to Binod are still open: sample JSON and how the chart is referenced; the event mechanism (S3 → EventBridge/SNS/SQS) and AWS account; how CIS wants to receive ARIA's output.
- Whether the data hub owns the policy store / rules / feedback storage (Reva's implication: yes).
