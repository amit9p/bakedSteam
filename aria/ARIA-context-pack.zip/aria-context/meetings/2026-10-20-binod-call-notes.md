# 2026-10-20 — Binod (CIS) + Amit, 9:30: "update about project ARIA" (meeting notes)

Source: `D:\Cotiviti\meetings\Voice 261020_093239-binod-call-10-20-2026_original.txt` (AI transcript, 15 min; Speaker 1 = Binod, Speaker 2 = Amit). Reva and Venkateshwar did not join; Binod will check with Reva about rescheduling. Teams messages from Binod after the call: AWS QA account and a resource table (below).

## Outcome in five lines

1. **CIS has already built the policy tool's front end.** Binod: "the policy tool that Reva gave me, we have completed it — the front-end part, deployed in our Kubernetes QA; we have shared the back-end part also, the database and the schema." What CIS needs now is the data to show in it: the generated rules. "If you don't have people that can write that logic, we will supplement it, or I can build that logic or infrastructure."
2. **Dates, in his words:** "We need data by 30th of October." "Second week of November is when we have to push it to our internal customers." Earlier than the "before Thanksgiving" he wrote on Oct 14. He has to report to Sundar "the amount of work remaining and the time it will take."
3. **What he wants from us:** "an inventory of tasks for the policy tool and for the coding thing": what, who, when. He can arrange people if needed. The policy tool is first; passing chart data is second.
4. **The feed, confirmed:** S3 bucket with an event notification "to SQS or SNS, whatever you want." Also an SFTP (AWS Transfer Family) exists. Account and resource names sent by Teams (below); the exact bucket/prefix for ARIA "by tomorrow, the India team is out." Egress: "how do you want the return back? It's up to you, nobody told me anything. If you want me to define it, I can."
5. **He questioned the data hub.** "Why would the data go from bronze to gold? I thought it was direct communication between two services. What are we trying to achieve by putting the data in Databricks or any platform? Where is the data component coming into the picture?" Amit answered audit/replay and reusable components; Binod moved on but was not convinced. This needs a proper answer from Surya and Reva, not from Amit alone.

## What Binod sent (Teams, 9:37 and 9:49)

- AWS QA account: **981971132015**
- Aurora cluster: `cis-nxt-gen-qa-cluster` (the policy tool's database, presumably)
- S3 bucket: `cis-nxt-gen-data-qa`
- Transfer Family (SFTP) server: `cis-nxt-gen-sftp-qa`
- App pod IAM role: `cis_nxt_gen_pod_role_qa`; policy: `pod_policy_cis_nxt_gen_qa`

These are QA resources. Which prefix in the bucket is for ARIA, and whether the Aurora cluster holds the policy tool's schema, to be confirmed.

## After the call (Teams group chat, 10:05–10:11)

- 10:05, Reva (still on his service call): shared the Loop doc **"P2L Rule Review Design and Build Guide"** — "Not sure what you all talked about but am sharing a doc that goes over rule review design and build." Condensed in `confluence/p2l-rule-review-design-and-build-guide-reva.md`. Short version: the policy store of record is Reva's PRM service (Postgres + S3 + API in account AF-1); CIS builds the review app in CIS-1 against PRM's API; the data hub's part is the nightly copy of PRM's records into lake tables and, later, the lakehouse write API (`LAKE-API-1`).
- 10:11, Binod to Reva (verbatim): "We would need a task list for the Policy Tool & coding recommendation backend work. On our end, we have already deployed the frontend in our QA cluster and are now waiting on the data piece to move forward. As discussed earlier, Agentic Hub will own the backend of the Policy Tool and will provide the APIs for us to consume the data. Could you confirm: Do we have the full task list created for this backend work? Do you have resources available to work on these tasks? As mentioned in my earlier email, we need the data available before October 30th so we can integrate it into our frontend application. The overall plan is to present this to our customer by the second week of November, so timing on this is critical. Please let me know where things stand and if there is anything we can help unblock."
- Read together: Binod and Reva agree on the split (Agentic Hub owns the backend and the API; CIS owns the front end). What they do not agree on is time. Reva's doc commits to exit criteria, not dates, puts a six-week floor on the main chain, and says PRM "does not exist"; the only thing his plan delivers early is a frozen API contract plus a mock for CIS (milestone M0, stream G). "Data before October 30" therefore means the mock, unless Reva says otherwise. That answer is Reva's to give, not Amit's.
- 10:37, Binod's second call (10 min): see `meetings/2026-10-20-binod-2nd-call-notes.md`.
- 1:03 PM onward, the "Policy Tool" email thread (Binod ↔ Reva, cc Cloud, later Tejveer): `meetings/2026-10-policy-tool-email-thread.md`.

## The "Policy Tool" email thread (Oct 20–21)

Binod's 1:03 PM email (his five-step flow and three open items), his 1:06 PM QA screenshot, Reva's 8:13 PM reply (five corrections, answers to the three items) and Binod's Oct 21 7:36 AM reply (single PDF, single call, dedicated DB, "can it be done in 2 weeks?", Tejveer added) are transcribed in `meetings/2026-10-policy-tool-email-thread.md`, with a side-by-side against Reva's design.

## Binod's view of the system (his 10,000-foot description)

- Today, in production: the NLP system produces codes → CIS renders them to the coder → the coder takes an action → CIS records it → a report is generated and submitted to CMS. "This entire application is based on trust. We are not reinventing anything." Traceability and evidence surfacing "are already taken care of" in CIS.
- ARIA, in his words: "we are putting an agentic hub in between; we pass the data to it; we expect something in return." His mental model is two services talking asynchronously: send data, get a response, show it to the customer.
- Therefore his question: why bronze, silver, gold at all? Who uses them? This is the gap Reva named on Oct 15 ("he thinks in terms of S3 buckets; the architecture to manage the data is something he's oblivious to").

## Sample data

- Binod: get samples from the person working on it (name garbled in the transcript; likely Venkateshwar), who "has dev-quality charts, working in QA" and "all the data needed to develop it." Binod himself will send the bucket location.
- Amit's AWS access: not yet; request submitted, Surya to approve. Binod noted connectivity "will take some time."

## What this changes

- **Policy store (updated 10:05 after Reva's doc):** the system of record is Reva's PRM (Postgres + S3 + authenticated API, account AF-1), not our five tables and not CIS's Aurora. CIS's front end calls PRM's API. Our part is the lake copy of PRM's records (nightly; a manual export is acceptable at first), the catalog/governance definitions for those datasets, and later the lakehouse write API. The five-table page stays as our thinking only. Whether CIS's Aurora schema survives or is replaced by PRM's API is Reva's and Binod's to settle.
- **First deliverable for CIS:** generated rules to show in their policy tool = PRM + P2L output. That is Reva's stream. The earliest thing CIS can integrate against is the frozen API contract and mock (Reva's M0), not real rules.
- **Ingress:** bucket + SQS/SNS confirmed; account known; access setup can start with Yesh (cross-account read from the Databricks workspace to `cis-nxt-gen-data-qa`).
- **Egress:** CIS has no format in mind; the contract draft's section 2 is the starting point.
- **The "why a data hub" question** must be answered in one page, by Surya and Reva, in Binod's language (async service, trust, no reinvention), before the next call with him.
- **Dates:** second week of November for internal customers; the Thanksgiving framing is gone.

## Actions

- Amit, today: send Binod the data-side task inventory (what, when, dependencies) and the contract draft; ask for the bucket prefix and the event choice (SQS); ask Venkateshwar for sample JSON for two or three charts.
- Amit, today: tell Reva the doc is read; ask for Appendix G (data model) and B (exit criteria) so the lake copy can be designed; ask what he expects `LAKE-API-1` to do and by when; confirm the five-table page is retired in favour of PRM. Binod's 10:11 task-list and Oct 30 questions are addressed to Reva; Amit does not answer them.
- Amit, today: tell Surya about the AWS access approval, the Oct 30 / mid-November dates, and Binod's question on the data hub; ask who answers it.
- Yesh (via Surya): cross-account access from the Databricks workspace to `cis-nxt-gen-data-qa` in account 981971132015.
- Reva: policy-tool task inventory for Binod; the Aurora schema; reschedule the call.
