# ARIA data pipeline design review — Oct 29, 2026 (notes)

Attendees: Surya, Nikhil, Reva, Yesh, Amit. Surya and Nikhil joined late from a troubleshooting call. Transcript captured only the last ~28 min (`meetings\Voice 261029_112145-aria-datapipeline-review_original.txt`); the diarization mixes speakers.

## Outcomes

- Design accepted at the high level. Reva: "at a higher level this looks right; minor changes to some pictures." No objections from anyone.
- Decision 1 (platform) deferred. Org-wide hyperscaler decision expected in 1-2 weeks (Surya). Until then: keep building on Databricks (access exists, bronze/silver already there) but no major architectural commitments on either platform; keep the work transferable (Nikhil).
- Decision 2 (CIS bucket role, PHI workspace) not discussed. Still open.
- Data hub is not on the critical path for the Thanksgiving demo. Reva's priority is PRM + the rule review application for coders (first showcase of the neurosymbolic approach).

## Reva

- Decide on requirements, not schemas: lineage, provenance of every input to a decision, security/privacy, data lifecycle. Wants written decision tenets and evaluation dimensions derived from requirements to resolve trade-offs between platform options.
- PRM is being built by Reva himself; tactically S3 + Postgres, all access via APIs, migrate to lakehouse later. The hub's nightly policy copy fits that.
- Blueprint / data inventory (what data, PHI or not, security, versioning, lineage, retention): "great, we need a complete inventory."
- Analytics: data hub team owns data quality assessment and analytical capabilities, on the final output and on intermediates (clinical truth graph). Golden dataset = coder ground truth. Exact analytics needs too early to know; will reach out.

## Surya

- Hyperscaler decision in the next ~2 weeks; after that, confidence on where the pipeline lives. If timeline is tight and there is a plan B, go with plan B.
- Asked whether analytics/reporting teams need the gold/golden dataset; wants ARIA to fit the centralized reporting/governance framework (as with PPC, provider data management): observability, controls, freshness. Keep him in the loop.
- Thanked for transparency; keep sharing status.

## Nikhil

- Wait about a week for the hyperscaler decision. Continue code development on Databricks; hold off on major architectural choices; make work transferable.
- Personal view: for audit-heavy lineage/provenance, tables; greenfield he would pick Databricks for auditability and speed of development.

## Yesh

- Nothing substantive captured on the platform side.

## Follow-up (Oct 29 to Nov 10)

- Oct 29: recap email sent to all four; Reva asked for comment access to the deck; edit access given to all four. No comments received as of Nov 10.
- Nov 10: tenets + data blueprint page prepared (`aria\aria-tenets-and-blueprint.html`) to send as a Loop page, with a nudge to Surya (hyperscaler decision), Nikhil (CIS bucket role, PHI workspace) and Reva (which pictures).

## Actions (Amit)

1. Send the tenets + blueprint page; name the bucket access as open.
2. Continue bronze/silver on Databricks, portably (PySpark + Delta/Parquet, config-driven paths, no DLT / Unity-only / Databricks-workflow dependencies).
3. Reva: abstractor field names; file handoff OK for demo?; offer nightly PRM copy + eval tables toward the rule-review milestone.
4. Nikhil: lakehouse/AWS specifics, CIS bucket role. Binod: sample ZIP.
5. Surya: hyperscaler outcome.
