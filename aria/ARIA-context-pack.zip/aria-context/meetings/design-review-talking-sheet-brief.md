# Design review — brief talking notes, 13 slides

One card per slide. Say it, pause, next. About 12 minutes for 1–7. Appendix only if asked.

---

**1 · Title**
"Thanks for joining. This is the design review for the ARIA data pipeline. I want three things: your comments on the design, a decision on the platform, and access to real charts. Six slides, then two decisions. Stop me anytime."

**2 · What ARIA does**
"A chart is a doctor's notes. A coder turns it into ICD-10 codes. Some map to an HCC, which is what CMS pays on, and what CMS audits years later. So every code needs its proof: sentence, page, rule. ARIA says codeable, flag, or coder, with the evidence. The coder decides. Pilot: diabetes, CKD, heart failure, Aetna first."

**3 · Today's picture**
"CIS sends the chart and NLP output, the components send back a recommendation, the coder sees it. That handshake stays. The only question is what happens to the data that went through. Today, nothing."

**4 · Plus the data hub**
"One thing added underneath: everything that goes through gets recorded. Five reasons. Replay old charts when the feed or rules change. Reproduce: same chart plus same rules, same answer. Audit: a frozen record per code, years later. Pilot numbers: ARIA's answer next to the coder's. Feedback to CIS: which fields arrived, per feed version. The platform's own guide says the lakehouse is the home of all data. The hub doesn't fix the chart, doesn't own the policy tool, and isn't on the demo's critical path."

**5 · The architecture**
"Four lanes: CIS, data hub, AI components, reference data. Two handoffs: S3 with CIS, solid; a file folder with the components for the demo, green dashed. Two doors: lookup for codes, explain for why. Nobody reads our tables directly.

One chart. One, CIS drops a ZIP. Two, bronze keeps it as is. Three, silver cleans it into six tables plus quarantine, and writes one JSON to the handoff folder. Four, the abstractor decides which findings are true for this visit and builds the truth graph. Five, we store the graph. Six, the auditor runs six gates per code, attaches the HCC, uses the rules from PRM, and stops at the first fail. Seven, gold: one row per code, codeable, flag, coder queue, or drop. One results file per chart back to CIS. Eight, the coder reviews; why-this-code goes to explain. Nine, decisions come back; we compute the pilot numbers.

The rules: PDF into PRM, policy-to-logic drafts, coders review through PRM's API, a second person promotes, the auditor fetches from PRM. We copy PRM nightly. The copy never drives a decision."

**6 · Where the hub runs**
"Your call. Fixed either way: CIS and the components are on AWS, PRM is Postgres plus S3, no GCP yet. Two options: Databricks on AWS, where it runs today, or AWS-native in the existing lakehouse. The data layer is identical; only the plumbing changes. Which one should the hub run on?"

**7 · Decisions**
"Two decisions today. One, which platform does the hub run on. Two, CIS drops real charts on the thirtieth: who sets up our role into their bucket and a PHI-cleared workspace, by when. Decision one first. Everything else on the slide I'm tracking outside this room, with owners."

---

**8 · Appendix divider**
"Zoom-ins: blueprint, silver tables, CIS contract, policy lane, accounts and roles."

**9 · Data blueprint**
"Every dataset the hub keeps: who writes, who reads, PHI or not, versioning, retention. Four rules: nothing overwritten, every decision carries its versions, PHI readable only by pipeline and components, everyone else comes through the doors."

**10 · Silver tables**
"Six tables, one per section of the extraction requirements, plus quarantine. Quarantine holds rows that fail a check: bad confidence, category code, no offsets, unknown assertion, no signer, unreadable ZIP. Reason and owner on every row. One bad mention doesn't stop the chart. The daily report tells CIS what to fix."

**11 · CIS contract**
"One ZIP per chart on CIS's bucket. Right side: what real exports have today. Biggest gap, no signer. Also no facility, payer, model version. Confidence isn't zero to one. Three flags, not six states. One code, not all candidates. Ask per field: present, can add, not available. First step: one sample ZIP."

**12 · Policy lane**
"Reva's PRM; the shaded row is ours. Eight steps from PDF to active ruleset, all inside PRM. We copy it nightly for explain, eval and audit. The auditor reads PRM, not the copy. We never write to PRM."

**13 · Accounts and roles**
"Read it one way: arrows point at storage and say who reads or writes. CIS owns the chart bucket; we get one role. We own the handoff folder; the components get one role. Reva owns PRM; we get read. Three grants total, nothing polls, nobody shares a bucket. True whichever way decision one goes."

---

**Don't:** give dates · say "recommend" on 6 · say the hub improves quality · say gate numbers to coders · say "we store the rules".
