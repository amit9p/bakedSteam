# Cotiviti CI/CD tracks and the ARIA repo plan (from the internal Claude chat, 2026-10-12)

Source: 14 phone photos in `D:\Cotiviti\ARIA\images\aria-context-cicd-talk-confluence` (taken Oct 12, 2026, 13:47–14:07). Photos 1–13 are a conversation on Cotiviti's internal claude.ai (Sonnet 5.5, Atlassian MCP integration: Confluence + Rovo search, Jira; Bitbucket itself not browsable). Photo 14 is VS Code with Claude Code reading the project's `CLAUDE.md`. Amit's questions, in order: is there a Project ARIA repo; how Bitbucket and CI/CD work at Cotiviti; "I am in OAI_DataOps"; step-by-step to get the POC into Bitbucket + Jenkins + Databricks + testing; how to carry the context into Claude Code.

Everything below is what that chat said, condensed. Items it flagged as "confirm with your team" are marked ⚠.

## 1. Is there an ARIA repo? — no trace found

- Confluence/Rovo search: only an unrelated UI hit for "ARIA". Bitbucket code search is not enabled on the Cotiviti site (a site admin would have to turn it on). Jira search returned a 401. Bitbucket is self-hosted (`bitbucket.cotiviti.com`), the connector is read-only and can't browse it, so a repo could exist unseen.
- Where to look yourself: `https://bitbucket.cotiviti.com/projects/OAI` (AI/ML team repos), `https://bitbucket.cotiviti.com/projects/RCA`, the Confluence "Project Links" page in the MLSA space (lists repos for AI/ML projects), and `https://gitlab.cotiviti.com/MLPlatform` in case ARIA is hosted there.
- Bitbucket projects seen later in the chat: `OAI`, `OAIP`, `OAI Data Science`. Suggested repo name for ours: `dbx-dataops-aria`. Existing DataOps repo example (from the MLSA "Central Inventory" page): `dbx-dataops-rca-spotcheck-workflow`.

## 2. Bitbucket basics and branch conventions (both tracks)

- Project = folder of related repos (`OAI`, `RCA`). Repo URL pattern: `bitbucket.cotiviti.com/projects/<PROJECT>/repos/<repo-name>/browse`. Branch = your own copy; Pull request = how you ask to merge, teammates review, the pipeline builds and tests it.
- Daily workflow: `git clone <HTTPS URL>` (Clone button) → `git checkout develop && git pull` → `git checkout -b feature/my-change` → edit → `git add . && git commit -m "…"` → `git push -u origin feature/my-change` → open a PR `feature/my-change -> develop`.
- Branches: `feature/*` (and `bugfix/*`) = your work, built but not deployed to shared environments; `develop` = integration branch, protected, a merge here auto-deploys to DEV; `release/*` cut from `develop` for UAT and PROD (track A); `main` = protected, prod-released code, changes only via approved PR (track B SOP).
- Never commit passwords, tokens or keys. Pipelines use stored credentials (Jenkins credentials named `bitbucket-credentials` and `databricks-token` in the older flow; secured Bitbucket/Jenkins variables scoped per dev/prod in the SOP).

## 3. Two CI/CD tracks at Cotiviti

Sources named by the chat: Confluence "How to Create an ADLM CI/CD Request", "Databricks CI/CD Documentation", the Bitbucket pages in MLSA, the "Databricks App CI/CD SOP" (Draft v1.0, effective Aug 2026, written for Databricks Apps, contains placeholder values to confirm with DevSecOps) and the "Databricks Automation & Support" page.

**Track A — RCA apps (Bamboo + Octopus).** Java APIs, SQL databases, frontends, libraries. Bamboo = CI (build, unit tests, fail on red); Octopus Deploy = CD; Artifactory stores built packages; never overwrite an already-published version. Flow: push `feature/*` or open PR → Bamboo builds/tests; merge to `develop` → Bamboo builds, Octopus auto-deploys to DEV, manual button promotes to QC; `release/*` built, manual Octopus buttons deploy UAT then PROD. Getting a pipeline for a new repo = file an ADLM ticket (Jira request to the ADLM team): collect repo name, URL, pipeline type (Java Maven API, Frontend/npm, Database, Spark Python, libraries…), unit test command; pick an existing reference pipeline from the Confluence page (ADLM copies it); use Claude CLI with the page's prompt to format the ticket; afterwards validate builds on feature/develop/release and the DEV/QC/UAT deployments.

**Track B — AI/ML on Databricks (OAI team; projects `OAI`, `OAIP`).** Push to Bitbucket → webhook triggers a Jenkins job → Jenkins runs the shared pipeline library: setup → `databricks bundle validate` → `databricks bundle deploy` → optional tests. The bundle (`databricks.yml` + `resources/*.yml`) creates/updates jobs in the DEV or PROD workspace, authenticating as a service principal, not as you. The Confluence page also lists a branch promotion model dev → MVP → prod via merge requests, each merge redeploying the matching job workflow (listed as a platform requirement ⚠ confirm how the team actually does it). Parts of that page are generic Databricks docs (GitHub Actions examples) and not how Cotiviti works.

**Which one for OAI_DataOps.** The older docs describe the Jenkins flow; the newer SOP describes Bitbucket Pipelines (`bitbucket-pipelines.yml`). ⚠ Ask the lead which one our repos use; a repo's `Jenkinsfile` or `bitbucket-pipelines.yml` tells you.

## 4. The Databricks App CI/CD SOP, as summarised

- Big picture: code lives in Bitbucket; a pipeline tests and scans it, then deploys it to Databricks as a bundle (DAB). Nobody hand-deploys to prod; the pipeline is the only path to prod.
- Typical repo: `src/` (code), `tests/unit/` (pytest / JUnit), `resources/` (job and app definitions), `databricks.yml` (bundle manifest, dev and prod targets), `bitbucket-pipelines.yml` (pipeline), `sonar-project.properties` (SonarQube).
- `databricks.yml` defines two targets, `dev` and `prod`, each with its own workspace URL and its own service principal (a non-human identity the pipeline deploys as; personal credentials are not used).
- Merge checks on PRs: at least one reviewer approval; SonarQube quality gate passing; Veracode scan passing; all unit tests green.
- Pipeline stages in order: (1) build; (2) unit tests (pytest / JUnit; failure stops everything); (3) SonarQube scan (sample gates: >80% coverage on new code, no new blocker/critical issues — placeholders ⚠); (4) Veracode security scan (fails on unmitigated High / Very High); (5) deploy to dev, `databricks bundle deploy -t dev`, automatic from `develop`; (6) manual approval by the release approver after reviewing dev results; (7) deploy to prod, `databricks bundle deploy -t prod`, only from `main` after approval.
- Rollback: redeploy the last known-good git tag through the same pipeline; pause dependent jobs first to avoid duplicate runs.
- Secrets live in secured Bitbucket (or Jenkins) variables, scoped separately for dev and prod; never tokens, passwords or Veracode keys in code.
- Platform resources (catalog, schema, volumes, SQL warehouse) are owned by the MLPlatform team and must exist before you deploy. Prod promotion requires a checklist including security sign-off.
- Workspaces seen: `ai-engineering-dev`, `ai-engineering-prod`, plus others like `he-dev`, `he-prod` ⚠ confirm which ones the team uses.
- Databricks CLI on the pipeline agent should be close to the local version; the SOP requires v0.220 or later (`databricks --version`).
- Related pages: "Databricks + VS Code + Claude Code" (push Databricks code to Bitbucket once, then develop locally), "AI Platform Access for New Users" (lists the Bitbucket access groups), "Connecting Bitbucket to Databricks" (exact HTTP access token steps).

Questions for the lead (verbatim from the chat): Do our repos use Jenkins or Bitbucket Pipelines? Which Bitbucket project and repos does DataOps own? Who is the release approver for prod? Do we deploy apps, jobs or both?

## 5. Step-by-step plan to get the POC into Bitbucket → Jenkins → Databricks

**Step 0 — ask the lead / platform team now (you can't do these yourself, they take time):**
1. A Bitbucket repo in the right project (`OAI` / `OAIP` / `OAI Data Science`), name like `dbx-dataops-aria`, with branch protection on `main` and `develop`.
2. A Jenkins job for the repo plus a webhook from Bitbucket so commits trigger it.
3. Service principals and credentials for dev and prod, stored in Jenkins (SOP: MLPlatform owns these).
4. SonarQube and Veracode registration (`sonar-project.properties`, Veracode profile owned by DevSecOps).

**Step 1 — prepare the local project.** Make `aria_data_pipeline` the repo root (the tree showed `aria/aria_data_pipeline/`; `databricks.yml` and `Jenkinsfile` sit inside the inner folder, so run git from there). `.gitignore` must exclude at least `.venv/`, `.databricks/`, `__pycache__/`, `.pytest_cache/`, `.vscode/`, `*.pyc`, `.env` (`.databricks/` holds local bundle state; `.venv/` is huge and machine-specific). `dbx_profile` lives in `~/.databrickscfg`, outside the repo — good. Scan for secrets before the first commit:

```powershell
cd C:\Users\amit.prasad\dev\aria\aria_data_pipeline
git init -b develop
git add .
git diff --cached | Select-String -Pattern "dapi|token|secret|password|client_secret"
```

Parameterise personal values in `databricks.yml` (`bronze_schema=amit_prasad`, `ccdm_schema=amit_prasad`, personal `volume_root` are fine for dev; prod needs shared values). Pattern given:

```yaml
bundle:
  name: aria_data_pipeline
variables:
  catalog: {}
  bronze_schema: {}
  ccdm_schema: {}
  volume_root: {}
targets:
  dev:
    mode: development
    default: true
    workspace:
      host: https://<ai-engineering-dev workspace URL>
    variables:
      catalog: ai_engineering_dev_catalog_1688890232235261
      bronze_schema: amit_prasad      # personal while developing
  prod:
    mode: production
    workspace:
      host: https://<ai-engineering-prod workspace URL>
    run_as:
      service_principal_name: <prod SP, from MLPlatform>
    variables:
      catalog: <prod catalog, from MLPlatform>
      bronze_schema: <shared prod schema>
```

⚠ Confirm the prod catalog, schemas and volumes with MLPlatform; the SOP says these are environment-specific and must not be hard-coded across targets.

**Step 2 — create the repo and push.** Create the Bitbucket repo empty (no README), copy the HTTPS clone URL. Create a Bitbucket HTTP access token under your profile settings and let Git Credential Manager store it; never in a URL or a file. Then:

```powershell
git commit -m "Initial ARIA data pipeline"
git remote add origin <HTTPS URL>
git push -u origin develop
git checkout -b main
git push -u origin main
git checkout develop
```

Ask the tech lead to protect `main` and `develop`.

**Step 3 — define the Databricks job as code.** Already done (`resources/*.yml`, job `aria_hello_pipeline`). From here on change the job in YAML, never in the Databricks UI, or the next deploy overwrites the edit. First deploy by hand: `databricks bundle validate -t dev` → `deploy -t dev` → `run -t dev aria_hello_pipeline`.

**Step 4 — Jenkins.** Review the existing `Jenkinsfile` (it is a template). The shared library `jenkins-shared-library-oaip-migration` provides `runDatabricksPipeline()`, but that page may be out of date — ⚠ ask the platform team whether to use it or write stages directly. If directly, the shape is:

```groovy
pipeline {
  agent any
  stages {
    stage('Setup')    { steps { sh 'python -m venv .venv && . .venv/bin/activate && pip install …' } }
    stage('Test')     { steps { sh '. .venv/bin/activate && pytest --junitxml=report.xml' } }
    stage('Validate') { steps { withCredentials([usernamePassword(credentialsId: 'aria-dev-sp',
                                 usernameVariable: 'DATABRICKS_CLIENT_ID', passwordVariable: 'DATABRICKS_CLIENT_SECRET')]) {
                          sh 'databricks bundle validate -t dev' } } }
    stage('Deploy Dev') { when { branch 'develop' }
                          steps { withCredentials([...same dev creds...]) { sh 'databricks bundle deploy -t dev' } } }
    stage('Approve Prod') { when { branch 'main' }; steps { input 'Deploy to prod?' } }
    stage('Deploy Prod')  { when { branch 'main' }
                            steps { withCredentials([usernamePassword(credentialsId: 'aria-prod-sp', ...)]) {
                              sh 'databricks bundle deploy -t prod' } } }
  }
}
```

Adjust the `pip install` line to `pyproject.toml`; credential IDs and Databricks host values come from the platform team. Jenkins authentication, safest first: A) OAuth M2M with a service principal's client ID and secret in the Jenkins credentials store (recommended); B) a service-principal PAT in Jenkins credentials (works, long-lived token); C) your personal PAT — don't (breaks when you leave, acts as you). Separate credentials for dev and prod; never in the repo or printed in logs.

**Step 5 — testing in layers.** Locally `pytest` before every push (`test_rules.py`, `test_silver_transforms.py`); in the pipeline, tests run before any deploy and a failure stops everything; SonarQube and Veracode once DevSecOps sets them up (add the `sonar-project.properties` they give you); smoke test after the dev deploy: `databricks bundle run -t dev aria_hello_pipeline`, then confirm the output tables in the dev catalog; before prod: the SOP promotion checklist (schema, volumes, warehouse, dev test, security approval, then promote).

**Day-to-day flow:** `git checkout develop` → `git pull` → `git checkout -b feature/add-quality-rule` → change code and tests → `pytest` → `databricks bundle validate -t dev` → `git add .` → `git commit -m "Add quality rule"` → `git push -u origin feature/add-quality-rule` → PR into `develop`, review, merge → Jenkins deploys to dev automatically → when ready merge `develop` → `main` → the release approver triggers prod.

**Order of work:** send the Step 0 requests today; do Step 1, then Steps 2 and 3 on your own; Steps 4 and 5 once Jenkins and credentials are ready.

## 6. Carrying the context into Claude Code

Claude Code in VS Code is a separate product from the claude.ai chat; they don't share conversations. Claude Code reads `CLAUDE.md` at the start of every session, so the chat produced a block to paste into it ("# ARIA data pipeline: project context": team and platform; CI/CD target state to be confirmed; rules — never commit secrets, tokens or `.databrickscfg`; no hard-coded personal schemas or volume paths for prod; change jobs in `resources/*.yml` not the UI; run `pytest` and `databricks bundle validate -t dev` before every push; current status — POC job `aria_hello_pipeline` runs in dev, no Bitbucket repo yet, waiting on repo, Jenkins job, service-principal credentials; open questions — Jenkins vs Bitbucket Pipelines, prod catalog and schemas, release approver). Division of labour it suggested: Claude Code for editing the repo, fixing tests, running `pytest` and bundle commands; the chat for planning, explaining and reviewing pasted files.

## 7. What photo 14 shows (VS Code, 14:07)

- The block was appended to `CLAUDE.md` (lines 29–55) below the original starter content. Claude Code (VS Code extension, Sonnet 5.5 Max) read the file on request ("this is my aria project, go through claude.md to understand everything") and summarised the layout and conventions correctly.
- Claude Code's own observations: line 3 is a leftover placeholder to replace with Cotiviti's "Sample Claude.md Rules File"; the two halves of the file overlap and disagree (targets dev/mvp/prod in the starter vs dev/prod in the pasted block; dev described as a personal schema in one and as the `ai-engineering-dev` workspace in the other); the Databricks CLI is not on PATH in that terminal, so `bundle validate` won't run until it is installed or the extension's copy is added to PATH.
- Terminal: the `.venv` was activated with `Set-ExecutionPolicy -Scope Process -ExecutionPolicy RemoteSigned; & …\.venv\Scripts\Activate.ps1`. Status bar: "Databricks Connect disabled". Claude Code is installed and answering, so the login/token problem from September is resolved.

## 8. What this changes for our plan

- Two branch models are now on the table: the Confluence CI/CD page's dev → mvp → prod and the SOP's develop → main (dev auto, prod with approval). Our `databricks.yml` has dev/mvp/prod targets; keep `mvp` until the lead says which model DataOps follows, then delete or rename. First question to the lead.
- The `Jenkinsfile` placeholder in the starter (`runDatabricksPipeline()` from the shared library) matches the older flow; the SOP may want `bitbucket-pipelines.yml` plus SonarQube/Veracode instead. Don't finish either until Step 0 answers arrive.
- Add to the repo before the first push: `.gitignore` entries above (ours already has most; add `.pytest_cache/`, `.vscode/`, `.env` if missing), `sonar-project.properties` placeholder, a `tests/unit/` layout if the SOP's layout is enforced.
- `CLAUDE.md` needs one merged version: replace line 3 with Cotiviti's Sample Claude.md Rules File content, keep the starter's layout/conventions, fold in the CI/CD target state and the rules from the pasted block, and make the targets section say one thing.
- Claude Code works now; the extension-bundled CLI (`%USERPROFILE%\.vscode\extensions\databricks.databricks-2.18.0-win32-x64\bin\databricks.exe`) can be put on PATH so `bundle validate` runs from Claude Code's terminal.
- Jenkins auth target: OAuth M2M service principal (option A), separate dev/prod — matches the Confluence page's `dab-sp-prod` pattern.
