# Setup guide — VS Code + Databricks + Claude Code on the Cotiviti Windows laptop

Built for Amit from the Confluence docs photographed on Sep 22, 2026 (Sanket Zanwar's unified workflow guide, Jonathan Dehdari's "Claude Code on Databricks", Security's Zscaler SSL fix, and the "Integrating Claude Code with VS Code (Windows)" doc — full transcriptions in `confluence\databricks-vscode-claude-code.md`). Sanket's doc is written for a Mac; everything below is translated to Windows/PowerShell and to a laptop without admin rights. Lines marked **[doc]** are straight from Cotiviti's docs; lines marked **[Claude]** are my additions — sanity-check those with the team if anything looks off.

Two routes. Do A today (nothing to install), then B when the software is on the laptop.

---

## Route A — Claude Code inside Databricks (browser only, ~15 min)

1. https://sso.cotiviti.com → Databricks icon → workspace **ai-engineering-dev**. [doc]
2. Left panel, bottom → **Serving** → **Integrate Coding Agents** → **Get Started** → **Other Integrations** → drop-down **Claude Code** → set default model **Claude Sonnet** → **Generate API Key** → click the eye icon → copy the JSON to Notepad. The token starts with `dapi`. [doc]
3. Left panel → **Workspaces** → **Create** → **File**. Paste the block below (paste as plain text if needed), replace `dapi...` with your token, then rename the tab to **`.bashrc`** (leading dot). [doc]

```bash
export PATH="$HOME/.local/bin:$PATH"

export ANTHROPIC_BASE_URL='https://dbc-0fa270fd-fb38.cloud.databricks.com/serving-endpoints/anthropic'
export ANTHROPIC_MODEL='databricks-claude-sonnet-4-6'
export ANTHROPIC_SMALL_FAST_MODEL='databricks-claude-haiku-4-5'
export ANTHROPIC_CUSTOM_HEADERS='x-databricks-use-coding-agent-mode: true'
export CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC=1
export DISABLE_TELEMETRY=1
export ANTHROPIC_AUTH_TOKEN='dapi...'

claude() {
    if which claude >/dev/null 2>&1; then
        command claude "$@"
    else
        curl -fsSL https://claude.ai/install.sh | bash -s 2.1.86 && command claude "$@"
    fi
}
```

4. **Compute** → create a cluster if you don't have one; auto-terminate 30–60 min. [doc]
5. **Workspaces** → **Create** → **Notebook** (empty). Attach it to your cluster (or Serverless for light work). Press play. Click the terminal icon bottom-right (or the terminal tab under the notebook). [doc]
6. In the terminal: `mkdir myproject; cd myproject; claude` — the `.bashrc` installs Claude Code on first run. If `claude` isn't found: `~/.local/bin/claude`. Accept the color scheme and the working-directory prompt. [doc]
7. Put a `CLAUDE.md` in the working directory (Security requirement — contents from the "Sample Claude.md Rules File" page on SharePoint, or the internal "Cotiviti Github Agents Repo"). [doc]
8. Switch models later by editing `ANTHROPIC_MODEL` in `.bashrc` (`databricks-claude-haiku-4-5` / `-sonnet-4-6` / `-opus-4-7`), then `source .bashrc`, restart `claude`, check with `/model`. [doc]

---

## Route B — VS Code on the laptop

### Step 0 — Get the software (no admin on this laptop)

Needed [doc]: VS Code (latest), Python **3.10 or 3.11** (not 3.12+ — databricks-connect issues), Git for Windows, Node.js 18+ (only if you want the `claude` command-line tool; the VS Code extension route doesn't need it).

[Claude] Check **Workspace ONE Intelligent Hub** first for each; otherwise a Service Desk software ticket. The Cotiviti docs assume per-user installs — Git at `C:\Users\<you>\AppData\Local\Programs\Git\` — so the user-scope installers (VS Code "User Installer", Python "install for me only", Git for Windows) may go through without admin; Node usually needs the ticket.

### Step 1 — Zscaler certificate fix (do this before anything that uses Node, including the Claude Code extension) [doc]

1. Win+R → `certmgr.msc` → **Trusted Root Certification Authorities → Certificates** → find **"Zscaler"** → right-click → All Tasks → Export → **Base-64 encoded X.509 (.CER)** → save as `C:\Users\<you>\ZscalerCACert.pem`.
2. PowerShell: `Get-Content "C:\Users\<you>\ZscalerCACert.pem"` — first line must be `-----BEGIN CERTIFICATE-----`.
3. PowerShell:
   `[System.Environment]::SetEnvironmentVariable("NODE_EXTRA_CA_CERTS", "C:\Users\<you>\ZscalerCACert.pem", "User")`
   then check: `[System.Environment]::GetEnvironmentVariable("NODE_EXTRA_CA_CERTS", "User")`
4. `taskkill /F /IM code.exe`, reopen VS Code, and in its terminal `$env:NODE_EXTRA_CA_CERTS` should print the path.

[Claude] If `pip`, `npm` or `git clone` also fail with certificate errors behind Zscaler, point them at the same file: `pip config set global.cert C:\Users\<you>\ZscalerCACert.pem`, `npm config set cafile C:\Users\<you>\ZscalerCACert.pem`, `git config --global http.sslCAInfo C:\Users\<you>\ZscalerCACert.pem`.

### Step 2 — Two tokens from Databricks [doc]

Open https://dbc-0fa270fd-fb38.cloud.databricks.com/ (via sso.cotiviti.com → Databricks → ai-engineering-dev).

- **PAT for the VS Code Databricks extension**: Settings → Developer → Access Tokens → Generate New Token (description, expiry) → copy now, it's shown once.
- **Coding-agent token for Claude Code**: Serving → Integrate Coding Agents → Get Started → Other Integrations → Claude Code → Generate API Key → eye icon → copy (`dapi…`). (Same as Route A step 2 — reuse that token if you already have it.)

Keep both out of git, screenshots and chat.

#### If Databricks says "contact your administrator" when you try to create a token (hit on 2026-09-22) [Claude]

Both buttons create a personal access token, and PAT creation is switched off per user until a workspace admin grants the "Can use" token permission (Databricks admin console → workspace settings → Personal Access Tokens → Permissions). Nothing in the Cotiviti docs works around that — every route (`.bashrc` in the web terminal, VS Code extension, CLI) needs a `dapi…` token for Claude Code.

1. First check the workspace switcher (top-right): the token permission is per workspace, and the docs assume **ai-engineering-dev** (`dbc-0fa270fd-fb38`). If you only see another workspace, the "How do I get Access?" page in the MLSA Confluence space is the request path.
2. Ask for the entitlement. Surya's welcome email named David Munoz as the go-to for Jira/Databricks/Confluence access; Yesh's team runs the Databricks platform side. One message covering token permission + personal cluster + keytab saves three round-trips (draft in the chat of 2026-09-22).
3. Meanwhile — the **Databricks VS Code extension does not need a PAT**: when it asks how to authenticate, pick **OAuth (user to machine)**; it opens the browser, you log in through SSO, and the profile it writes to `%USERPROFILE%\.databrickscfg` shows up as `Auth Type: Profile '<name>'` in the panel (that's what Sanket's `SZ_vscde` is). If OAuth is also blocked you get an error at that step — same ticket.
4. Meanwhile — **Bitbucket is independent of Databricks tokens**: create the HTTP access token in Bitbucket (Manage account → HTTP access tokens) and clone the repo now (Step 4 below).
5. Stopgap for Claude Code only if the ticket drags: an OAuth session token from the Databricks CLI (`databricks auth login --host https://dbc-0fa270fd-fb38.cloud.databricks.com --profile ai-eng`, then `databricks auth token --profile ai-eng` prints an `access_token`) should be accepted by the serving endpoint as `ANTHROPIC_AUTH_TOKEN`, but it expires after about an hour, so you restart `claude` with a fresh one. Claude Code's `apiKeyHelper` setting can automate the refresh. Untested at Cotiviti — try only after the extension's OAuth sign-in works.

### Step 3 — Databricks extension in VS Code [doc]

1. Extensions (Ctrl+Shift+X) → install **Databricks**.
2. Databricks icon in the sidebar → **Configure Databricks** → Host URL `https://dbc-0fa270fd-fb38.cloud.databricks.com/` (nothing after `.com/`) → PAT from Step 2, or **OAuth (user to machine)** if you have no PAT (browser SSO login, no token).
3. You should now see your clusters, workspace files and sync state. [Claude] The configuration is saved per opened folder, so do this with your project folder open (after Step 4 is fine too).

### Step 4 — Code into Bitbucket once, then clone locally [doc]

One-time in the Databricks browser UI (only if your code currently lives only in the workspace): Workspace → your project folder → **Add > Git Folder** → provider Bitbucket → paste the repo URL (create an empty repo on bitbucket.cotiviti.com first if needed) → Create Git Folder → commit and push from the Git panel.

On the laptop (PowerShell):

```powershell
git clone <URL from the repo's Clone button> C:\Users\<you>\DBX_bitbucket
cd C:\Users\<you>\DBX_bitbucket
code .
```

[Claude] Cotiviti runs Bitbucket **Server**, so the URL looks like `https://bitbucket.cotiviti.com/scm/<project>/<repo>.git`, not the `bitbucket.org` placeholder in the doc. When git asks for credentials, use your Cotiviti username and a Bitbucket **HTTP access token** (Manage account → HTTP access tokens — see `confluence\databricks-cicd-and-bitbucket.md`), not your password; Windows Credential Manager remembers it.

Then in the Databricks extension: **Local Folder Mapping** → your clone (`C:\Users\<you>\DBX_bitbucket`). Panel should show: Local Folder = clone, Target = `dev`, Auth Type = your profile, Cluster = your personal cluster (the ▷ starts it), Remote Folder = `/Workspace/Users/amit.prasad@cotiviti.com/.bundle/DBX_bitbucket/dev/files`, Sync State = STOPPED (IN PROGRESS while a save syncs). From now on every save syncs to the workspace automatically; develop only in VS Code. [doc]

Add to `.gitignore` before the first commit: `.venv/`, `*.keytab`, `*.pem`, `.vscode/` (if you ever put a token in workspace settings). [doc + Claude]

### Step 5 — `.venv` + Databricks Connect [doc]

1. VS Code status bar (bottom) → click **"Databricks Connect Disabled"** → YES to create a virtual environment → the extension pip-installs `databricks-connect` into `.venv\` → wait for **"Databricks Connect Enabled"**. Don't activate the venv manually.
2. Verify in a VS Code terminal: `python -m databricks.connect test` (cluster must be running — start it with ▷ first). [Claude] On Windows use `Get-Command python` (PowerShell) instead of `which python`; it should point inside `.venv\Scripts\`.
3. Project deps, if any: `.venv\Scripts\Activate.ps1` then `pip install -r requirements.txt`. [Claude — Windows form of the doc's `source .venv/bin/activate`]
4. The `databricks-connect` version must match the cluster's DBR (e.g. DBR 16.x ↔ `databricks-connect` 16.1.x). Mismatch warning → `pip install databricks-connect==<cluster-dbr-version>`. [doc]

### Step 6 — Claude Code

**6a. VS Code extension (recommended first — no Node/npm needed)** [doc]

1. Extensions → install **"Claude Code"** by Anthropic.
2. File → Preferences → Settings → Extensions → Claude Code → enable **Disable Login Prompt** → under Environment Variables click **Edit in settings.json**.
3. Paste this into the **user** settings.json (the doc says both user and workspace; [Claude] keep the token only in the user one so it never lands in the repo). Fill in the coding-agent token. Save (Ctrl+S). Valid JSON, no trailing commas.

```json
{
    "claudeCode.preferredLocation": "panel",
    "security.workspace.trust.untrustedFiles": "open",
    "claudeCode.disableLoginPrompt": true,
    "claudeCode.environmentVariables": [
        { "name": "ANTHROPIC_BASE_URL", "value": "https://dbc-0fa270fd-fb38.cloud.databricks.com/serving-endpoints/anthropic" },
        { "name": "ANTHROPIC_AUTH_TOKEN", "value": "<your dapi token>" },
        { "name": "ANTHROPIC_CUSTOM_HEADERS", "value": "x-databricks-use-coding-agent-mode: true" },
        { "name": "ANTHROPIC_MODEL", "value": "databricks-claude-sonnet-4-6" },
        { "name": "ANTHROPIC_SMALL_FAST_MODEL", "value": "databricks-claude-haiku-4-5" },
        { "name": "ANTHROPIC_DEFAULT_SONNET_MODEL", "value": "databricks-claude-sonnet-4-6" },
        { "name": "CLAUDE_CODE_GIT_BASH_PATH", "value": "C:\\Users\\<you>\\AppData\\Local\\Programs\\Git\\bin\\bash.exe" }
    ]
}
```

   [Claude] Model names: the Windows doc uses `haiku-4-5` as default and `sonnet-4-5` for the Sonnet alias; Sanket's and Jonathan's newer pages use `sonnet-4-6`. Use whatever appears in the Serving endpoints list of the workspace — that list is the truth. The Git Bash line is the doc's "Optional" step; include it only after Git is installed at that path.
4. Restart VS Code → Claude Code icon in the Activity Bar → new chat. If you get an SSL error, Step 1 wasn't picked up (fully quit VS Code with `taskkill`). Logs: Output panel → "Claude Code".

**6b. Command-line `claude` in the VS Code terminal (optional; needs Node 18+ and Git Bash)** [doc, Windows-ized by Claude]

`npm install -g @anthropic-ai/claude-code` → `claude --version`. Set the variables once at user level in PowerShell (mirrors the doc's "add them to your shell profile"; the doc's `PATH=/root/.local/bin` and `CLAUDE_CODE_USE_ENTERPRISE=true` lines are Linux/Mac-side — the second one is harmless to add if you want to match the doc exactly):

```powershell
[System.Environment]::SetEnvironmentVariable("ANTHROPIC_BASE_URL", "https://dbc-0fa270fd-fb38.cloud.databricks.com/serving-endpoints/anthropic", "User")
[System.Environment]::SetEnvironmentVariable("ANTHROPIC_AUTH_TOKEN", "<your dapi token>", "User")
[System.Environment]::SetEnvironmentVariable("ANTHROPIC_CUSTOM_HEADERS", "x-databricks-use-coding-agent-mode: true", "User")
[System.Environment]::SetEnvironmentVariable("ANTHROPIC_MODEL", "databricks-claude-sonnet-4-6", "User")
[System.Environment]::SetEnvironmentVariable("ANTHROPIC_SMALL_FAST_MODEL", "databricks-claude-haiku-4-5", "User")
```

Restart VS Code, open the terminal (Ctrl+`) in the repo, run `claude`. One-shots work too: `claude "find all places where init_hdfs_kerberos is called"`.

### Step 7 — `CLAUDE.md` and permissions at the repo root [doc]

`CLAUDE.md` (Security wants one in every working directory; start from the SharePoint sample and add project facts). Template adapted from Sanket's:

```markdown
# Project: <ARIA repo name> – Databricks

## Environment
- Python 3.11 in .venv (managed by the Databricks VS Code extension / Databricks Connect)
- Cluster start + Kerberos auth must be done in the browser notebook before local execution
- Live sync to /Workspace/Users/amit.prasad@cotiviti.com/.bundle/<repo>/dev/files is handled by the extension

## Key Paths
- <folder>: <what lives there>

## Conventions
- All Spark reads of HDFS data go through the Kerberos-authenticated session
- Don't commit .venv/, *.keytab, *.pem, or any file with tokens
```

`.claude\settings.json` to cut permission prompts (never pre-approve `rm -rf` or similar):

```json
{ "permissions": { "allow": ["Bash(git *)", "Bash(python *)", "Bash(pip *)", "Bash(find *)", "Bash(grep *)"] } }
```

### Recipe — creating a new Databricks project from VS Code (done 2026-09-22) [Claude]

1. Empty folder (e.g. `C:\Users\amit.prasad\dev\<project>`) → File → Open Folder.
2. Databricks icon → Configure Databricks → host `https://dbc-0fa270fd-fb38.cloud.databricks.com` → **OAuth (user to machine)**. After the first time the profile (`dbx_profile`) is just picked from a list.
3. Accept "create a new project" (= `databricks bundle init`): template **default-python**, name it, ETL/Lakeflow pipeline **no**, wheel package **no**, serverless **yes**, catalog → Enter (defaults to `ai_engineering_dev_catalog_1688890232235261`), personal schema **yes** (→ `amit_prasad`).
4. Open the created folder; the panel shows Target `dev`, the profile, and `[dev amit_prasad] sample_job` under Bundle Resource Explorer.
5. Hover the job → **Deploy and Run** once to prove the path (no Python or cluster needed — runs on serverless).
6. Replace the sample `resources/` and `src/` with the real code (ARIA: `aria\aria-pipeline-starter`), keep `databricks.yml`, commit, push.

Existing repo instead: `git clone`, open the folder, step 2 — the extension finds `databricks.yml` at the root. Without the wizard: `databricks bundle init default-python --output-dir <folder>`.

Per-machine, once: Python 3.11 + `.venv` (the red "Databricks Connect disabled" button), Git for Windows, the Zscaler certificate variables. Observed on 2026-09-22: with no Python installed the extension tries `uv python install` and the download fails behind Zscaler — install Python from Workspace ONE / python.org ("Install Now", per-user) instead, and set `UV_NATIVE_TLS=1` plus `SSL_CERT_FILE` to the exported Zscaler .pem so `uv`/`pip` trust the proxy. For git behind Zscaler: `git config --global http.sslBackend schannel` (uses the Windows certificate store).

### Step 8 — Every session: cluster + Kerberos (browser), then work locally [doc]

1. VS Code terminal: `git pull origin <branch>`.
2. Databricks extension → ▷ on your cluster → wait for Running (faster than the browser).
3. **Browser** notebook attached to that cluster → run the `init_hdfs_kerberos()` block (full code in `confluence\databricks-vscode-claude-code.md`, Doc 2 §3). Expected: `HDFS ready: amit.prasad@COTIVITI.COM`. This can't run through Databricks Connect (no Py4J gateway locally) — it's the one thing the browser is still for.
4. `claude` (or the extension panel) → develop → saves sync automatically → run via Databricks Connect locally or cells in the browser → `git add / commit / push`.

Kerberos prerequisites [doc, resolved for Amit]: the code copies your keytab from `/Volumes/ai_engineering_dev_catalog_1688890232235261/user_amit_prasad/personal/amit.prasad.keytab` to `/etc/` on the driver and logs in as `amit.prasad@COTIVITI.COM`. So that Volume path and keytab must exist for you — the docs don't say who creates it. `keytab not found` → path/keytab missing; `GSS initiate failed` → cluster restarted, re-run the block; `CalledProcessError on cp` → wrong path or `/etc/` not writable (single-user cluster expected).

---

## Things to ask the team before/while doing this

- Who provisions the personal cluster in ai-engineering-dev and the Kerberos keytab in `/Volumes/ai_engineering_dev_catalog_…/user_amit_prasad/personal/`? (Yesh's platform side is the likely owner.)
- Which Bitbucket project/repo should ARIA code live in, and does the dev/mvp/prod branch + Jenkins/DAB pipeline from yesterday's notes apply to it?
- Which model endpoints are currently enabled in the workspace's Serving list (sonnet-4-6 / opus-4-7 or older)?
- Where is the current "Sample Claude.md Rules File" / Cotiviti Github Agents Repo, and is it mandatory for every repo?
- Can VS Code, Python 3.11, Git and Node come through Workspace ONE, or does it need a Service Desk ticket?
