# How Bitbucket, VS Code, Claude Code, Databricks and Jenkins fit together at Cotiviti (for the ARIA pipeline)

Written by Claude on 2026-09-22 from the Confluence pages in `confluence\databricks-cicd-and-bitbucket.md` (CI/CD, Bitbucket) and `confluence\databricks-vscode-claude-code.md` (VS Code, Claude Code, Kerberos). Lines marked **[doc]** come from those pages; **[inferred]** is standard Databricks practice that the pages imply but don't spell out — confirm with Reva/Surya before treating it as Cotiviti policy.

## The one-paragraph version

Code lives in **Bitbucket** (bitbucket.cotiviti.com, Bitbucket Server). You write it on your laptop in **VS Code**; the Databricks extension mirrors your working copy into your own dev folder in the workspace and runs it on your personal cluster. **Claude Code** is an assistant inside VS Code that edits those same local files — it deploys nothing. **Databricks** is the runtime: compute, Unity Catalog storage, Workflows/Jobs as the scheduler, model serving. **Jenkins** (not Jira) is the deployment robot: a merge in Bitbucket fires a webhook, Jenkins runs `databricks bundle validate/deploy` against the dev, mvp or prod workspace as the service principal `dab-sp-prod`, and the jobs defined in your repo's `resources/*.yml` get created or updated there. **Jira** holds the ticket, nothing more. In prod nobody clicks anything in the Databricks UI — every job, schedule and cluster spec is a file in the repo. [doc + inferred]

## Who does what

| Piece | Role | What you touch it for |
|---|---|---|
| Bitbucket Server | system of record for code; branches `dev` → `mvp` → `prod` [doc] | pull requests, reviews, HTTP access token for git |
| VS Code + Databricks extension | local editing; syncs saves to `/Workspace/Users/amit.prasad@cotiviti.com/.bundle/<repo>/dev/files`; starts your cluster; runs files via Databricks Connect [doc] | all day-to-day coding |
| Claude Code | AI pair-programmer in the VS Code terminal/panel; calls Claude models served from Databricks (`…/serving-endpoints/anthropic`) — that's why it needs the Databricks token [doc] | write/refactor/explain code, tests; never runs the pipeline |
| Databricks workspace (one each for dev/mvp/prod) | compute, Unity Catalog (catalog › schema › table/volume), Workflows/Jobs, model serving, MLflow [doc] | dev: personal cluster, notebooks for exploration, Kerberos auth cell, watching job runs. prod: read-only for humans in practice [inferred] |
| Jenkins `gad1dmljenkin01.cotiviti.com/jenkins/job/Databricks_Migration/` | CI/CD; shared library `jenkins-shared-library-oaip-migration` → `runDatabricksPipeline()` → `pip install databricks-cli` → `bundle validate -t <target>` → `bundle deploy -t <target>` → optional integration tests [doc] | nothing manual; it reacts to commits/merges |
| Service principal `dab-sp-prod` | identity Jenkins uses to deploy and (normally) the identity prod jobs run as [doc] | ask who owns it / whether ARIA gets its own |
| Jira | tickets / stories | branch names and PR titles reference the ticket [inferred] |

Two deployment styles appear in the CI/CD page [doc]: (1) **Asset Bundles via Jenkins** — the fully worked example (`OAIP/dbx-ovaledgeprofiler`); (2) **jobs whose task source is the Bitbucket repo + branch** — "redeploy happens automatically if the job task uses Bitbucket as source", i.e. the job pulls the branch at run time so a merge alone changes what runs. Ask Reva which one ARIA should follow; the Jenkins/DAB one is the documented path.

## Life of a change (what "enterprise manner" means here)

1. **Ticket** in Jira (e.g. ARIA-123). [inferred]
2. **Branch** from `dev`: `git checkout -b feature/ARIA-123-claims-ingest`. [inferred — the doc only defines dev/mvp/prod; feature branches are normal practice]
3. **Write** in VS Code, with Claude Code: pipeline code in `src/`, job definition in `resources/*.yml`, per-environment settings in `databricks.yml`. Every save syncs to your `.bundle/…/dev/files` folder. [doc]
4. **Test in dev** on your personal cluster: run a file via Databricks Connect, run pytest locally, or `databricks bundle deploy -t dev` + `bundle run` to create a `[dev amit_prasad] …` copy of the job in the dev workspace and run it. If the data is on HDFS, run the Kerberos cell in a browser notebook first. [doc + inferred]
5. **Commit, push, pull request** → `dev` in Bitbucket; reviewer approves; merge. [doc]
6. **Jenkins** webhook → validate → deploy to the **dev workspace** as `dab-sp-prod` → the official dev job exists/updates. [doc]
7. **PR `dev` → `mvp`** → Jenkins deploys to mvp, redeploys the mvp job workflow. **PR `mvp` → `prod`** → same for prod. [doc]
8. **Prod runs on its schedule** (defined in the yml: cron/trigger, retries per task, notifications), as the service principal; you watch Job Runs, logs, alerts. [doc]
9. Need a change in prod? Back to step 2. Never edit the prod job in the UI. [inferred]

## What stays manual in the Databricks UI

Dev only: creating your personal single-user cluster (auto-terminate 30–60 min), tokens, the one-time "Add > Git Folder" to push existing workspace code to Bitbucket, the Kerberos `init_hdfs_kerberos()` cell each session (if HDFS), exploring tables in Catalog / SQL Editor, reading Job Runs and driver logs. [doc] Everything that *defines* the pipeline — job, tasks, schedule, cluster spec, permissions, notifications — is code. [inferred from the DAB model in the doc]

## What a repo should look like

The Jenkins step reads `bundle/databricks.yml`, uploads `src/`, and creates jobs from `resources/*.yml` [doc]. Copy the exact layout from `bitbucket.cotiviti.com/projects/OAIP/repos/dbx-ovaledgeprofiler` (and its Jenkinsfile) rather than inventing one — the shared library expects it. Typical shape [inferred]:

```
aria-pipeline/
  bundle/databricks.yml      # bundle name; targets dev / mvp / prod (workspace hosts, variables per env)
  resources/
    aria_ingest_job.yml      # job: tasks, schedule, job-cluster spec, retries, notifications
  src/
    aria/                    # python package: extract / transform / load / utils
    notebooks/               # thin notebooks that call the package
  tests/                     # pytest; run locally or via Databricks Connect
  Jenkinsfile                # @Library('jenkins-shared-library-oaip-migration') … runDatabricksPipeline()
  CLAUDE.md                  # project rules for Claude Code (Security requires one)
  .gitignore                 # .venv/, *.keytab, *.pem, .databricks/
  README.md
```

## Building the ARIA bronze → silver → gold pipeline, step by step (added 2026-09-22)

Visual version with two diagrams: `guides\aria-pipeline-blueprint.html` (also published as the "ARIA Pipeline Blueprint" artifact in the Claude app).

1. **Decide with Reva/Yesh**: where the source lands (CIS NLP JSON on a Kafka topic Databricks can reach, or files CIS drops into a Volume); Workflow job with PySpark tasks (what the Cotiviti docs show) vs. a Lakeflow/DLT pipeline; catalog + schema per environment; which Bitbucket project owns ARIA; Jenkins `Databricks_Migration` path vs. jobs that pull the branch directly.
2. **Repo**: `aria-pipeline` in the agreed Bitbucket project (created by the project admin), branches dev/mvp/prod with PRs required. Clone, open in VS Code, copy the layout and `Jenkinsfile` from `OAIP/dbx-ovaledgeprofiler` — the Jenkins shared library expects it.
3. **Environments in code**: `bundle/databricks.yml` targets dev/mvp/prod — workspace host, `run_as` service principal for mvp/prod, variables the code reads (catalog, schema, topic or landing Volume, checkpoint path). Dev mode gives each developer a private `[dev <name>]` copy of the job.
4. **Code in `src/aria/`**: `ingest_bronze.py` (Structured Streaming from Kafka or Auto Loader from the Volume → Delta, append-only, raw payload + ingest metadata, checkpoint in a Volume — the replay log); `to_silver.py` (explicit JSON schema, dedupe on event id, types, conform to the CCDM, `MERGE`, DQ checks that fail loudly); `to_gold.py` (truth-graph facts and CIS-facing outputs, idempotent); `common/` (config from bundle variables, logging, DQ helpers). `tests/` with pytest on small DataFrames, run through Databricks Connect. Claude Code writes/refactors/tests; the extension syncs every save to dev.
5. **Job in `resources/aria_pipeline.yml`**: tasks bronze → silver → gold chained with `depends_on`; job-cluster spec (DBR matching `databricks-connect`) or serverless; `schedule` cron, or `continuous` / file-arrival trigger; per-task `max_retries`; notifications; permissions; tags. Jenkins turns this file into the real job in every workspace.
6. **Prove it in dev**: personal cluster from the extension → transforms and tests via Databricks Connect → `databricks bundle deploy -t dev` + `bundle run aria_pipeline -t dev` → check tables in Catalog Explorer and the run in Job Runs. Kerberos cell first if the source is HDFS.
7. **Ship**: PR → dev (review) → Jenkins deploys dev; PR dev → mvp; PR mvp → prod; prod job runs on schedule as the service principal. Fixes start again at a feature branch.
8. **Operate**: Job Runs, driver logs, retries, alerts, UC lineage/grants, cost (auto-terminate, per-run job clusters). Every change is a commit.

### Who creates what

| Thing | Created by | Defined where |
|---|---|---|
| Repo, branches, PR rules | Bitbucket project admin, then you | Bitbucket |
| Pipeline code, tests | you + Claude Code | `src/aria/`, `tests/` |
| Environments (hosts, catalogs, run-as) | you, once | `bundle/databricks.yml` |
| Workflow job (tasks, schedule, cluster spec, retries, alerts, permissions) | Jenkins via `bundle deploy` — never by hand | `resources/aria_pipeline.yml` |
| Job cluster | Databricks, per run, from the yml (or serverless) | same yml |
| Personal dev cluster | you, Compute UI, 30–60 min auto-terminate | dev workspace only |
| Workspace copy of the code | extension (dev sync) · Jenkins (bundle deploy) | `/Users/<you>/.bundle/…` · bundle root |
| bronze/silver/gold tables | your code on first run (`CREATE TABLE IF NOT EXISTS` / `writeStream.toTable`) — confirm if a DDL task is preferred | `src/aria/` |
| Catalog, schema, grants, Volumes, secret scopes, service principal, Kafka connectivity | platform team (Yesh's side) via Jira | outside the repo |

Note on the Bitbucket repo Rutvi shared earlier (two folders + yml files, per Amit): not captured in this knowledge base — if it holds `databricks.yml` + `resources/` + `src/`, it is an Asset Bundle repo and a good template; drop a screenshot in D:\Cotiviti to fold it in.

## While the token request is pending — do these now

1. Software on the laptop (Workspace ONE, else Service Desk): VS Code, Python 3.10/3.11, Git for Windows. Node only if you want the `claude` CLI.
2. Zscaler cert fix (`NODE_EXTRA_CA_CERTS`) — guide Step 1.
3. Bitbucket: sign in, create your HTTP access token, open `OAIP/dbx-ovaledgeprofiler` and read its layout + Jenkinsfile; ask Reva which Bitbucket project ARIA lives in and who creates the repo.
4. VS Code: install the Databricks, Python and Claude Code extensions; try the Databricks extension's OAuth (user-to-machine) sign-in — no token needed.
5. Clone the repo (or an empty one), let the extension create `.venv`, scaffold the layout above, write `CLAUDE.md` and `.gitignore`.
6. Databricks UI, dev workspace: create your personal cluster if the policy lets you; browse Catalog for the ARIA source tables; look at existing jobs in dev/mvp/prod for naming conventions and which principal runs them.
7. Jenkins: open the `Databricks_Migration` folder and see how a repo is onboarded (one job per repo?).

## Questions for Reva / Surya

- Which Bitbucket project for ARIA, and who creates the repo? Any required repo template?
- Jenkins `Databricks_Migration` + Asset Bundles, or Git-sourced jobs — which does ARIA use? Is there an onboarding step to register a new repo with Jenkins?
- Which three workspaces map to dev/mvp/prod for AI engineering, and does ARIA get its own service principal or use `dab-sp-prod`?
- Which catalogs/schemas does ARIA read and write? Does any source sit on HDFS (Kerberos) or is it all Unity Catalog?
- Cluster policy for jobs: job clusters from a policy, or serverless?
- Who reviews PRs into `dev`, and who approves `mvp` → `prod`?
