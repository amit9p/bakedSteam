# ARIA — context handoff for Claude

**As of:** Nov 10, 2026. **Owner:** Amit Prasad, Principal Data Engineer – AI, Cotiviti.
**Purpose:** one file that brings a fresh Claude session up to date on Project ARIA: who is who, what is being built, what is decided, what is open, and where the detailed documents are. Read this first; open the detailed docs in section 11 only when a question needs them.

**How to keep it in sync:** this file is regenerated on Amit's personal machine (where the full knowledge base and meeting transcripts live) and carried to the office laptop through his repo. If something here conflicts with what Amit says in the session, Amit is right; tell him the file needs an update.

---

## 1. How Amit likes to work

- Short, direct answers in plain English. Push back if a reply is getting long. He refines iteratively.
- He often dictates (voice-to-text), so expect transcription errors: "Reva" may appear as Riva/River/Reiva, "Yesh" as Yash, "tenets" as TNets, "CIS" as "sea ice", "ARIA" as "area".
- He is new to healthcare / risk adjustment (joined Sep 8, 2026) and new to Databricks beyond the SQL editor. 15+ years in data engineering: PySpark, AWS (EMR, Glue, S3, Lambda, Step Functions), Snowflake, Airflow, Kafka, Terraform. Explain domain terms simply; don't explain data engineering basics.
- For meetings he wants bullet-point question lists and talking lines he can read out as written. Answers written "as him" should sound like a person in a meeting room: point first, one or two reasons, no AI polish.
- Office laptop: Windows 11, no local admin. Software comes through Workspace ONE or a Service Desk ticket. Zscaler SSL inspection is in the path.
- Never state demo dates or PRM dates on his behalf; those are not his to give.

## 2. What ARIA is

- **ARIA** = a risk-adjustment medical coding assistant. It reads a patient chart and, for each diagnosis code, says **codeable**, **flag**, or **send to coder queue**, always with the evidence (sentence, page, rule). **CoPilot** now (coder decides); **AutoPilot** later (no coder), only when the numbers prove it.
- It is a feature inside the existing coding application **CIS**, not a new app. Coders keep working in CIS.
- Pilot scope: three conditions (diabetes, CKD, heart failure), Aetna first.
- Built on the **Agentic Hub**, the AI platform designed by Reva: reusable components (clinical abstractor, symbolic auditor, policy-to-logic, PRM) plus a shared clinical data model (CCDM).
- **Why it matters (business):** CMS pays Medicare Advantage plans by member risk score, which comes from HCCs, which come from ICD-10 codes on charts. CMS only pays for a condition that is present and managed at that visit (MEAT evidence). CMS can audit years later (RADV), sample charts, and extrapolate the error rate to the whole contract. So every code needs its proof. See `aria/how-coding-moves-money.md`.

## 3. Amit's piece: the data hub

Amit owns the **data hub** — the data engineering layer between CIS and the AI components. Everything that passes through is recorded there, versioned.

**Why a data hub at all (five reasons):**
1. **Replay** — rerun old charts when NLP or rules change, without asking CIS to resend.
2. **Reproducibility** — same chart + same rules = same answer; a rule change flips no previously-correct chart. Both are release gates.
3. **Audit** — a frozen record per code for CMS, readable years later.
4. **Pilot numbers** — precision, recall, overrides, coder time; needs ARIA's answer joined to the coder's decision.
5. **Feedback to CIS** — a daily data-quality report per feed version.

**What it does not do:** it does not fix the chart or the NLP, does not own the policy tool, and is not on the critical path for the first demo.

## 4. Architecture (v6) — four lanes

1. **CIS** (external): drops one ZIP per chart (PDF + NLP JSON + mode) on S3 with an event; later shows results to the coder.
2. **Data hub** (Amit): bronze → silver → truth-graph store → gold → results file; Explain API; feedback and evaluation.
3. **AI components** (Reva's, Kubernetes on AWS): Clinical Abstractor, Symbolic Auditor, Policy-to-Logic (P2L), PRM.
4. **Reference data + feedback**: code sets, HCC crosswalk, payer lists, taxonomy copy, golden dataset, policy copy; Lookup API.

**One chart, nine steps:**
1. CIS drops the ZIP on S3; event fires.
2. **Bronze**: keep the ZIP exactly as received, every version.
3. **Silver**: clean into six CCDM tables — chart, note, mention, code_candidate, relationship, meat_evidence. Bad rows go to **quarantine** with a reason and an owner. Export one clean JSON per chart to a handoff folder.
4. **Clinical Abstractor**: decides what is true for this patient at this visit (real, current, who signed, MEAT proof).
5. **Clinical Truth Graph (CTG)** stored in the hub, one per chart, versioned per run.
6. **Symbolic Auditor**: six fail-fast gates per code, deterministic, using the active rule set fetched from PRM. HCC attached at gate one from the crosswalk.
7. **Gold**: one row per code — disposition, first failed gate, rule id + snapshot digest, all version keys. One results file per chart back to S3 for CIS.
8. **Coder** reviews in CIS; "why this code?" calls the Explain API.
9. **Feedback**: coder decisions come back; joined to gold for the pilot metrics.

**Policy lane (Reva's eight steps):** guideline PDF → PRM → P2L drafts rules → immutable snapshot with digest → quality checks → coders review in CIS's rule-review screen via PRM's API → revise → second-person promote → auditor fetches the active rule set at run time. **PRM is the store of record (Postgres + S3). The hub keeps a nightly copy for explain, evaluation and audit. The copy never drives a decision. The hub never writes to PRM.** Say "we copy the rules", never "we store the rules".

**Two doors:** Lookup API (codes, crosswalk, reference data) and Explain API (why this code). Nobody reads hub tables directly.

**Handoffs:** CIS ↔ hub is S3 files with events. Hub ↔ components is a file handoff for the demo (hub writes a folder, components read and write back). Nothing polls.

**Four rules for all hub data:** (1) nothing that feeds a decision is overwritten; (2) every decision row carries its version keys; (3) PHI is read by jobs, not people; (4) other systems come through the doors or S3 handoffs.

## 5. People

| Person | Role | Relevance |
|---|---|---|
| **Surya Vadlamani** | VP Data Engineering – AI; Amit's manager | Decides platform with Nikhil and Yesh; aligning with Tejveer and Cloud on expectations |
| **Reva** (Sharanabasappa Revadigar) | Principal AI Engineer / architect; owns Agentic Hub and ARIA | Amit's day-to-day technical counterpart; writes in Loop; building PRM himself |
| **Nikhil Shivalkar** | Director of Software Engineering, Data Ingestion & Architecture | AWS lakehouse side; needed for CIS bucket role |
| **Yeshwanth "Yesh" Jagini** | Manager Data Eng AI | Databricks platform/provisioning; PHI workspace question |
| **Binod Chamoli** | Director of Software Engineering, CIS | CIS point of contact: ingress ZIP, egress, policy-tool front end |
| **Cloud Xia** | Head of the AI group; Surya's manager | Sponsor; tracks ARIA with Tejveer and Sundar |
| **Tejveer** | Engineering leader on the program | Source of the demo timeline on the CIS side |
| **Sundar** | CTO (Edifecs side) | Leadership tracking |
| **Venkateshwar Eaga** | CIS team | Asked for a sample ZIP |
| **Rutvi Mistry** | Former manager on the team; moved to RCA AI Product (Sep 25) | Open to questions |
| **David Munoz** | — | Go-to for access issues (Jira, Databricks, Confluence) |

Amit reports to Surya but works day to day with Reva. Reva sits in the Health Enablement domain.

## 6. What is built today

- **Slice 1 runs on Databricks** (workspace `ai-engineering-dev`, Unity Catalog, serverless, Asset Bundle), on **synthetic data only**. Job `aria_hello_pipeline`: generate sample events → bronze `chart_events` (Auto Loader, append-only) → silver (`encounter`, `condition_mention`, `quarantine`) with quality gates. First successful run Sep 23, 2026.
- Repo layout: `src/aria/` (config, sample_data, bronze, rules, silver, quality), `src/notebooks/` (three thin tasks), `resources/*.job.yml`, `databricks.yml` with dev/mvp/prod targets, `tests/`, placeholder `Jenkinsfile`, `CLAUDE.md`.
- Known serverless gotcha: `.cache()` / `.persist()` are not allowed.
- **Not built:** six-table silver (two of six exist), CTG store, gold, publish, feedback, Explain/Lookup APIs, reference tables (still constants in `rules.py`), PRM copy, golden dataset, replay job.
- **Not in Bitbucket/Jenkins yet.** The CI/CD plan is in `guides/cotiviti-cicd-tracks-and-aria-repo-plan.md` (OAI track: Jenkins + Databricks Asset Bundles).
- **No real data yet.** No PHI anywhere. Reva's POC component code is not checked into a repo, so Amit cannot see it.

## 7. Timeline of what happened

- **Sep 8** — Amit joins. Sep 16 meet-and-greets with Yesh, Nikhil, Rutvi.
- **Sep 22–23** — VS Code + Databricks + Claude Code set up; first pipeline run.
- **Oct 14** — Design and goals reviewed with Reva: design mostly right, six changes asked, including a data blueprint. Binod named as CIS contact.
- **Oct 15** — Sync with Surya + Reva: platform (Databricks vs AWS) to be decided through a design review with Nikhil and Yesh. Instruction to Amit: define the CIS contract, mock the input, keep building.
- **Oct 20** — Two calls with Binod. CIS feed shape learned: one ZIP per chart, PDF + encounter-nested JSON (codes, section, sentence, offset, confidence). Binod's 2–3 week target is an internal-stakeholder demo, not production; the data pipeline need not be in it.
- **Oct 20–21** — Reva's Loop pages read (P2L build guide, ARIA architecture, evaluation methodology, explainability, NLP extraction requirements). Architecture revised to **v6**: PRM is the policy store of record; silver grows to six tables; gold becomes "determinations".
- **Oct 29** — **Design review** with Surya, Nikhil, Reva, Yesh (13-slide deck). Outcomes in section 8.
- **Nov 10** — Follow-up being sent: decision tenets + data blueprint (Loop page), plus a nudge on the hyperscaler decision and bucket access.

## 8. Decisions and positions as of Nov 10

- **Design:** accepted at the high level. Reva: "at a higher level this looks right; minor changes to some of the pictures." He has edit access to the deck; no comments received yet; he has not said which pictures.
- **Platform:** **not decided.** An org-wide hyperscaler decision was expected within 1–2 weeks of Oct 29 (Surya); no update yet. Options: Databricks on AWS (today), AWS-native lakehouse (Nikhil's), GCP (no environment yet).
- **Interim instruction (Nikhil):** keep building on Databricks, but no major architectural commitments, and keep the work transferable. In practice: PySpark + Delta/Parquet, config-driven paths, no DLT, nothing Unity-only as a contract.
- **Nikhil's personal view:** for audit-heavy lineage/provenance, tables; greenfield he would pick Databricks for auditability and speed.
- **Reva's priority:** the **rule review application for coders** (P2L rules → PRM → coder feedback) is first; it is the first showcase. PRM is tactically S3 + Postgres behind APIs, migrating to the lakehouse later.
- **Demo:** an internal demo around Thanksgiving was mentioned. The data hub is not on its critical path; a file handoff is enough.
- **Reva asked for two things:** (a) **decision tenets** — written principles plus evaluation dimensions derived from requirements (lineage, provenance, PHI/security, lifecycle), so the platform choice is scored, not argued; (b) a **complete data inventory** (the blueprint). Both drafted: `aria/data-hub-decision-tenets.md` and `aria/aria-data-blueprint.md`; combined paste-ready page `claude_output/aria/aria-tenets-and-blueprint.html`.
- **Analytics (Reva):** the data hub team owns data-quality assessment and analytical capability, on final output and on intermediates like the truth graph. Exact needs too early.
- **Reporting (Surya):** ARIA's gold data should fit the centralized reporting/governance framework; keep his group in the loop.

## 9. Open items

1. **Hyperscaler / platform decision** — waiting on Surya.
2. **CIS bucket access + PHI-approved workspace** — needed before real charts can flow. Not discussed on Oct 29. Owner unclear (Nikhil or Yesh, follows the platform decision).
3. **Sample ZIP from CIS** (Binod / Venkateshwar) and a field-by-field answer on contract v0.2: present / can add / not available.
4. **Reva's picture changes** to the deck — which slides.
5. **Abstractor input field names** — what Reva's parser expects, so the handoff JSON matches.
6. **Is a file handoff acceptable for the demo** (Reva) and does CIS pre-run NLP or does the hub call it.
7. **Golden dataset** — size (256 vs 200) and who holds it.
8. **Lakehouse write API** that the P2L plan assumes from data engineering — owner and date; settle with Reva once PRM's schema is real.
9. **Repo and CI** — ARIA into Bitbucket + Jenkins.
10. **CIS egress** — results-file location and event; coder decisions back with reason codes.

Known gaps in the CIS NLP feed (from Reva's check of real exports): no signer / credential / co-signature / signature time; no facility type, payer, HCC model version; confidence is a raw match count, not 0–1; three true/false assertion flags instead of six states; one winning code instead of all candidates; no relationships or MEAT evidence.

## 10. Next steps for Amit

1. Send the tenets + blueprint page to all four (reply-all on "ARIA data pipeline — design review").
2. Keep building on Databricks, portably: six-table silver, quarantine reason codes, reference tables as Delta tables, then the handoff export.
3. Get the repo into Bitbucket/Jenkins.
4. Follow up: Surya (platform), Nikhil (bucket role), Reva (pictures, field names, demo handoff), Binod (sample ZIP).
5. Offer the nightly PRM copy and the evaluation tables as the data hub's contribution to Reva's rule-review milestone.

## 11. Document index

All paths are relative to `claude_output\` in Amit's Cotiviti folder (same paths in the Claude project "Project-ARIA"). `INDEX.md` there lists every source and when it was processed.

**Architecture and design (start here)**
- `aria/aria-architecture-v6.md` — the one architecture: lanes, nine steps, eight policy steps, doors.
- `aria/aria-data-blueprint.md` — every kind of data the hub keeps, with rules.
- `aria/data-hub-decision-tenets.md` — tenets, dimensions, platform scoring sheet.
- `aria/stack-options.md` — Databricks-on-AWS vs AWS-native, row by row; fixed facts; AWS account and bucket details.
- `aria/aria-cis-contract-v0.2.md` — the CIS ↔ ARIA contract draft, field by field.
- `aria/why-a-data-hub.md` — the one-page case for the hub.
- `aria/aria-box-by-box-walkthrough.md` — each box in plain words.
- `aria/where-the-taxonomy-lives.md` — who owns the clinical taxonomy, the lookup door.
- `aria/how-coding-moves-money.md` — business explainer.
- `aria/aria-slice1-demo-walkthrough.md`, `aria/aria-pipeline-starter.md` — what runs today, file by file.
- `aria/policy-store-tables-v0.1.md`, `aria/aria-ingress-contract-draft-v0.1.md` — superseded; kept for history.
- Deck: `aria/aria-design-review-deck-cotiviti.pptx` (13 slides; 1–7 talk, 8–13 appendix).

**Reva's pages (transcribed from Loop/Confluence)**
- `confluence/aria-architecture-reva-loop-page.md` — component view, six gates, routing lanes.
- `confluence/p2l-rule-review-design-and-build-guide-reva.md` — PRM, snapshots, fingerprints, streams A–J (H = data bridge, the data engineer's).
- `confluence/p2l-overview-architecture-evaluation-reva.md` — policy-to-logic pipeline and evaluation.
- `confluence/aria-evaluation-methodology.md` — metrics, targets, golden dataset, path to autonomy.
- `confluence/show-dont-tell-explainability-reva.md` — explainability commitments.
- `confluence/nlp-extraction-requirements-reva.md` — what the NLP feed must carry; basis of the six silver tables.
- `confluence/prfaq-agentic-hub.md` — the Agentic Hub PRFAQ.

**Meetings**
- `meetings/2026-10-29-design-review-notes.md` — outcomes of the design review.
- `meetings/design-review-talking-sheet.md` (+ `-short`, `-brief`) — per-slide lines and Q&A answers.
- `meetings/2026-10-20-binod-call-notes.md`, `meetings/2026-10-20-binod-2nd-call-notes.md` — CIS feed shape, demo timeline.
- `meetings/2026-10-policy-tool-email-thread.md` — Binod ↔ Reva on the policy tool.
- `meetings/2026-10-15-surya-reva-sync-notes.md`, `meetings/2026-10-14-reva-goals-review-notes.md`.
- `meetings/2026-09-16-meet-and-greets-yesh-nikhil-rutvi.md`.

**Platform and setup**
- `guides/cotiviti-cicd-tracks-and-aria-repo-plan.md` — Bitbucket/Jenkins plan for ARIA.
- `guides/cotiviti-databricks-dev-workflow-explained.md`, `guides/setup-guide-vscode-databricks-claude-code-windows.md`.
- `confluence/databricks-cicd-and-bitbucket.md`, `confluence/databricks-vscode-claude-code.md`.
- `log/2026-09-22-vscode-databricks-first-job.md`, `log/2026-09-23-first-aria-pipeline-run.md`.

**Company context**
- `cotiviti/data-ai-org-structure-2026-10.md`, `cotiviti/ai-engineering-vision-cloud-2026-10.md`, `cotiviti/team-directory-and-project-leads.md`, `cotiviti/cotiviti-medical-record-coding-product.md`, `cotiviti/new-hire-onboarding-deck-2026-08-20.md`.

## 12. Glossary

- **CIS** — the existing coding application coders work in; ARIA plugs into it.
- **ICD-10 / HCC / RAF** — diagnosis code / payment category some codes map to / the risk score weight.
- **MEAT** — Monitor, Evaluate, Assess, Treat: proof a condition was managed at the visit.
- **DOS** — date of service.
- **RADV** — CMS's audit of risk-adjustment data.
- **CCDM** — Common Clinical Data Model: the shared schema and vocabulary; silver is its tables.
- **CTG** — Clinical Truth Graph: the abstractor's output, facts with evidence per chart.
- **Clinical Abstractor** — decides which NLP findings are true, current and supported.
- **Symbolic Auditor** — deterministic rule engine; six fail-fast gates per code.
- **P2L** — Policy-to-Logic: turns guideline PDFs into rules.
- **PRM** — Policy Rules Manager: store of record for rules, reviews and the active rule set.
- **Snapshot / digest / fingerprint** — an immutable rule set / its hash / the hash of one rule a review is tied to.
- **Bronze / silver / gold** — as received / cleaned into tables / the per-code verdicts.
- **Quarantine** — rows that failed a data check, kept with a reason and owner.
- **Golden dataset** — de-identified charts with coder-confirmed answers; every release is tested against it.
- **CoPilot / AutoPilot** — coder decides / no coder.
- **Shadow mode** — ARIA runs alongside coders without affecting them, to compare (Kappa).
- **Tenets** — short written principles used to settle trade-offs between options.
- **Agentic Hub** — the AI platform ARIA is built on; "AF-1" is its AWS account in Reva's docs.
- **OAI / OIA** — Amit's org group; its CI/CD track is Jenkins + Databricks Asset Bundles.
