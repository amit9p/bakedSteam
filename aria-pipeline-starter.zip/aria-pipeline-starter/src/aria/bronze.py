"""Bronze: land every CIS chart event exactly as received. Append-only. Never edited.

Table bronze.chart_events (from aria-data-pipeline-walkthrough.md, box 3):
  chart_id | client_id | received_at | payload (raw JSON) | pdf_uri | source_msg_id | phi_flag
plus source_file (which landing file it came from) for traceability.

Mechanism: Auto Loader (cloudFiles) reads the landing folder as text, one JSON per line, and
remembers which files it has already processed in the checkpoint. `availableNow` = process
everything new, then stop — so a scheduled job costs nothing between runs. When CIS publishes to
Kafka instead, only this reader changes; the table and everything downstream stay the same.
"""

from pyspark.sql import SparkSession, functions as F, types as T

from .config import Settings

TABLE = "chart_events"

# The bronze schema as a StructType too, so tests and other code can build bronze-shaped frames.
SCHEMA = T.StructType([
    T.StructField("chart_id", T.StringType()),
    T.StructField("client_id", T.StringType()),
    T.StructField("received_at", T.TimestampType()),
    T.StructField("payload", T.StringType()),
    T.StructField("pdf_uri", T.StringType()),
    T.StructField("source_msg_id", T.StringType()),
    T.StructField("phi_flag", T.BooleanType()),
    T.StructField("source_file", T.StringType()),
])


def ensure_table(spark: SparkSession, settings: Settings) -> str:
    table = settings.bronze_table(TABLE)
    spark.sql(f"CREATE SCHEMA IF NOT EXISTS {settings.catalog}.{settings.bronze_schema}")
    spark.sql(
        f"""
        CREATE TABLE IF NOT EXISTS {table} (
          chart_id       STRING    COMMENT 'CIS chart id, from the payload',
          client_id      STRING    COMMENT 'client the chart belongs to',
          received_at    TIMESTAMP COMMENT 'when the data hub landed it',
          payload        STRING    COMMENT 'exact JSON as received - the replay record',
          pdf_uri        STRING,
          source_msg_id  STRING    COMMENT 'message id from CIS / Kafka, for idempotency',
          phi_flag       BOOLEAN,
          source_file    STRING    COMMENT 'landing file this row came from'
        )
        USING DELTA
        COMMENT 'ARIA bronze: exact copy of every CIS chart event. Append-only, replay source.'
        """
    )
    return table


def ingest_chart_events(spark: SparkSession, settings: Settings) -> dict:
    """Land new files from the landing folder into bronze.chart_events. Returns row counts."""
    settings.validate()
    table = ensure_table(spark, settings)
    checkpoint = f"{settings.checkpoint_root}/{TABLE}"

    raw = (
        spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "text")
        .option("cloudFiles.schemaLocation", f"{checkpoint}/_schema")
        .option("cloudFiles.includeExistingFiles", "true")
        .load(settings.landing_path)
    )

    bronze = (
        raw.withColumn("chart_id", F.get_json_object("value", "$.chart_id"))
        .withColumn("client_id", F.get_json_object("value", "$.client_id"))
        .withColumn("received_at", F.current_timestamp())
        .withColumn("pdf_uri", F.get_json_object("value", "$.chart_pdf_uri"))
        .withColumn("source_msg_id", F.get_json_object("value", "$.source_msg_id"))
        .withColumn("phi_flag", F.lit(True))
        .withColumn("source_file", F.col("_metadata.file_path"))
        .withColumnRenamed("value", "payload")
        .select("chart_id", "client_id", "received_at", "payload", "pdf_uri", "source_msg_id", "phi_flag", "source_file")
    )

    before = spark.table(table).count()
    query = (
        bronze.writeStream.format("delta")
        .option("checkpointLocation", checkpoint)
        .trigger(availableNow=True)
        .toTable(table)
    )
    query.awaitTermination()
    after = spark.table(table).count()
    return {"table": table, "rows_before": before, "rows_after": after, "rows_added": after - before}
