"""CCDM v0.1 rules that need no Spark — unit-tested in tests/test_rules.py.

Source: ccdm-v0-1-design.md (vocabulary + source_map tables). When the real ccdm.vocabulary and
ccdm.source_map tables exist, silver reads them instead of these constants.
"""

import hashlib
import re

CCDM_SOURCE = "nlp_v3"

# ccdm.source_map — how the NLP's words become CCDM words (assertion only, for slice 1)
ASSERTION_SOURCE_MAP = {
    "present": "ACTIVE",
    "history": "HISTORY",
    "negated": "NEGATED",
    "possible": "SUSPECTED",
}

# ccdm.vocabulary — the allowed values
VOCABULARY = {
    "assertion": {"ACTIVE", "HISTORY", "NEGATED", "SUSPECTED"},
    "section": {"ASSESSMENT_PLAN", "HPI", "MEDICATIONS", "PROBLEM_LIST", "LABS", "RADIOLOGY"},
    "meat_criterion": {"M", "E", "A", "T"},
    "disposition": {"CODEABLE", "CODER_QUEUE", "DROP"},
}

_ICD10CM = re.compile(r"^[A-TV-Z][0-9][0-9A-Z](\.[0-9A-Z]{1,4})?$")


def translate_assertion(raw: str | None) -> str | None:
    """'present' -> 'ACTIVE'; unknown or empty -> None (the row will be quarantined)."""
    if raw is None:
        return None
    return ASSERTION_SOURCE_MAP.get(raw.strip().lower())


def normalize_icd10(raw: str | None) -> str | None:
    if raw is None:
        return None
    code = raw.strip().upper()
    return code or None


def is_valid_icd10(code: str | None) -> bool:
    return bool(code) and _ICD10CM.match(code) is not None


def mention_id(chart_id: str, char_start: int, char_end: int, icd10: str) -> str:
    """Stable id for a mention: the same span + code always gets the same id, so MERGE is idempotent."""
    key = f"{chart_id}|{char_start}|{char_end}|{icd10}"
    return "M-" + hashlib.sha1(key.encode("utf-8")).hexdigest()[:10]


def quarantine_reasons(icd10: str | None, assertion: str | None, page: int | None,
                       char_start: int | None, char_end: int | None) -> list[str]:
    reasons: list[str] = []
    if not is_valid_icd10(icd10):
        reasons.append("icd10_invalid")
    if assertion not in VOCABULARY["assertion"]:
        reasons.append("assertion_not_in_vocabulary")
    if page is None or page < 1:
        reasons.append("page_missing")
    if char_start is None or char_end is None or char_start >= char_end:
        reasons.append("span_invalid")
    return reasons
