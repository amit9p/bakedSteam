"""Synthetic CIS chart events for dev runs — the ingress contract from aria-data-pipeline-walkthrough.md.

Everything here is invented (fake chart ids, fake clients, textbook phrases). No PHI.
Each call writes one JSON-Lines file into the landing folder, so every run gives Auto Loader
something new to pick up. The batch deliberately includes:
  * CH-8841 sent twice (a re-send) -> silver keeps the latest copy only
  * one mention with assertion "maybe"  -> not in the source map -> quarantine
  * one mention with code "XYZ"         -> not a valid ICD-10-CM code -> quarantine
"""

import json
import uuid
from datetime import datetime, timezone

from .config import Settings


def _event(chart_id: str, client_id: str, dos: str, mentions: list[dict], msg_suffix: str = "") -> dict:
    return {
        "chart_id": chart_id,
        "client_id": client_id,
        "mode": "COPILOT",
        "dos": dos,
        "chart_pdf_uri": f"s3://cis-charts/2026/03/{chart_id}.pdf",
        "source_msg_id": f"k-{uuid.uuid4().hex[:8]}{msg_suffix}",
        "event_ts": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "nlp_output": mentions,
    }


def _m(text: str, start: int, end: int, page: int, code: str, assertion: str, section: str | None = None,
       confidence: float | None = None) -> dict:
    d = {"text": text, "start": start, "end": end, "page": page, "code_candidates": [code], "assertion": assertion}
    if section:
        d["section"] = section
    if confidence is not None:
        d["confidence"] = confidence
    return d


def sample_events() -> list[dict]:
    return [
        _event("CH-8841", "CLIENT-A", "2026-03-14", [
            _m("Type 2 diabetes with kidney complications", 412, 454, 3, "E11.22", "present", "ASSESSMENT_PLAN", 0.94),
            _m("CKD stage 3", 588, 599, 3, "N18.30", "present", "ASSESSMENT_PLAN", 0.91),
            _m("History of heart failure", 640, 664, 3, "I50.9", "history", "ASSESSMENT_PLAN", 0.72),
        ]),
        _event("CH-8842", "CLIENT-A", "2026-03-15", [
            _m("COPD, stable", 120, 132, 2, "J44.9", "present", "PROBLEM_LIST", 0.88),
            _m("possible pneumonia", 300, 318, 2, "J18.9", "possible", "HPI", 0.55),
            _m("no evidence of DVT", 401, 419, 2, "I82.409", "negated", "HPI", 0.80),
        ]),
        _event("CH-8843", "CLIENT-B", "2026-03-16", [
            _m("morbid obesity", 88, 102, 1, "E66.01", "present", "ASSESSMENT_PLAN", 0.90),
            _m("something unclear", 200, 217, 1, "XYZ", "present", "HPI", 0.30),        # -> quarantine
            _m("hypertension", 250, 262, 1, "I10", "maybe", "PROBLEM_LIST", 0.85),     # -> quarantine
        ]),
        # re-send of CH-8841 with one extra mention: latest copy wins in silver
        _event("CH-8841", "CLIENT-A", "2026-03-14", [
            _m("Type 2 diabetes with kidney complications", 412, 454, 3, "E11.22", "present", "ASSESSMENT_PLAN", 0.94),
            _m("CKD stage 3", 588, 599, 3, "N18.30", "present", "ASSESSMENT_PLAN", 0.91),
            _m("History of heart failure", 640, 664, 3, "I50.9", "history", "ASSESSMENT_PLAN", 0.72),
            _m("hyperlipidemia", 700, 714, 4, "E78.5", "present", "MEDICATIONS", 0.83),
        ], msg_suffix="-resend"),
    ]


def write_sample_file(dbutils, settings: Settings) -> str:
    """Write one JSON-Lines file into the landing folder; returns its path."""
    dbutils.fs.mkdirs(settings.landing_path)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    path = f"{settings.landing_path}/cis_events_{stamp}.jsonl"
    body = "\n".join(json.dumps(e) for e in sample_events()) + "\n"
    dbutils.fs.put(path, body, True)
    return path
