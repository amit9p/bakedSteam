"""Small data-quality gates. A failed gate raises, which fails the task, which pages you — on purpose."""

from pyspark.sql import DataFrame, functions as F


class DataQualityError(RuntimeError):
    pass


def assert_no_nulls(df: DataFrame, columns: list[str], where: str = "") -> None:
    for c in columns:
        n = df.filter(F.col(c).isNull()).count()
        if n:
            raise DataQualityError(f"{where}: {n} rows with NULL {c}")


def assert_min_rows(df: DataFrame, minimum: int, where: str = "") -> int:
    n = df.count()
    if n < minimum:
        raise DataQualityError(f"{where}: expected at least {minimum} rows, found {n}")
    return n
