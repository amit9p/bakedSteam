"""ARIA data hub (layer 2) — pipeline package.

bronze  : land CIS chart events exactly as received (append-only, replayable)
silver  : convert bronze payloads into CCDM v0.1 tables, quarantine what does not fit
rules   : pure Python rules (no Spark) so they can be unit-tested on a laptop
config  : one Settings object built from job parameters / notebook widgets
"""

__all__ = ["config", "rules", "bronze", "silver", "quality", "sample_data"]
