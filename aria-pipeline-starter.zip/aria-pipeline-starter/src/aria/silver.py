"""Silver: bronze.chart_events -> CCDM v0.1 tables (slice 1: encounter + condition_mention + quarantine).

From ccdm-v0-1-design.md, "What silver does with them":
    bronze payload
       -> parse header      -> encounter
       -> for each mention  -> translate via source_map -> check vocabulary -> validate span/code
                            -> pass: condition_mention   |   fail: quarantine (with reason)

Idempotent: a chart re-sent by CIS replaces its earlier rows (latest received_at wins) and MERGE
keys are stable (chart_id + mention_id), so re-running the job never duplicates anything.
Not yet in this slice: provider, evidence_span, hcc lookup via code_reference (needs the CMS
reference tables).
"""

from pyspark.sql import DataFrame, SparkSession, Window, functions as F, types as T

from . import rules
from .config import Settings

NLP_ITEM = T.StructType([
    T.StructField("text", T.StringType()),
    T.StructField("start", T.IntegerType()),
    T.StructField("end", T.IntegerType()),
    T.StructField("page", T.IntegerType()),
    T.StructField("code_candidates", T.ArrayType(T.StringType())),
    T.StructField("assertion", T.StringType()),
    T.StructField("section", T.StringType()),
    T.StructField("confidence", T.DoubleType()),
])

EVENT = T.StructType([
    T.StructField("chart_id", T.StringType()),
    T.StructField("client_id", T.StringType()),
    T.StructField("mode", T.StringType()),
    T.StructField("dos", T.StringType()),
    T.StructField("chart_pdf_uri", T.StringType()),
    T.StructField("source_msg_id", T.StringType()),
    T.StructField("event_ts", T.StringType()),
    T.StructField("nlp_output", T.ArrayType(NLP_ITEM)),
])


# --------------------------------------------------------------------------- tables
def ensure_tables(spark: SparkSession, s: Settings) -> dict:
    spark.sql(f"CREATE SCHEMA IF NOT EXISTS {s.catalog}.{s.ccdm_schema}")
    enc, men, quar = s.ccdm_table("encounter"), s.ccdm_table("condition_mention"), s.ccdm_table("quarantine")
    spark.sql(f"""
        CREATE TABLE IF NOT EXISTS {enc} (
          chart_id STRING, encounter_id STRING, patient_id STRING, client_id STRING,
          dos DATE, provider_id STRING, ccdm_version STRING, updated_at TIMESTAMP
        ) USING DELTA COMMENT 'CCDM: one row per visit'""")
    spark.sql(f"""
        CREATE TABLE IF NOT EXISTS {men} (
          chart_id STRING, mention_id STRING, encounter_id STRING, icd10 STRING, hcc STRING,
          page INT, char_start INT, char_end INT, text_span STRING, assertion STRING, section STRING,
          source STRING, source_conf DOUBLE, ccdm_version STRING, updated_at TIMESTAMP
        ) USING DELTA COMMENT 'CCDM: one row per place a condition is mentioned'""")
    spark.sql(f"""
        CREATE TABLE IF NOT EXISTS {quar} (
          chart_id STRING, mention_id STRING, reasons STRING, mention_json STRING,
          ccdm_version STRING, quarantined_at TIMESTAMP
        ) USING DELTA COMMENT 'CCDM: mentions that failed vocabulary / code / span validation'""")
    return {"encounter": enc, "condition_mention": men, "quarantine": quar}


# --------------------------------------------------------------------------- transforms
def latest_event_per_chart(bronze: DataFrame) -> DataFrame:
    w = Window.partitionBy("chart_id").orderBy(F.col("received_at").desc(), F.col("source_msg_id").desc())
    return bronze.withColumn("_rn", F.row_number().over(w)).filter("_rn = 1").drop("_rn")


def parse_events(bronze_latest: DataFrame) -> DataFrame:
    return bronze_latest.withColumn("e", F.from_json("payload", EVENT))


def build_encounters(events: DataFrame, ccdm_version: str) -> DataFrame:
    return events.select(
        F.col("chart_id"),
        F.concat(F.lit("ENC-"), F.col("chart_id")).alias("encounter_id"),  # until CIS sends one
        F.lit(None).cast("string").alias("patient_id"),
        F.coalesce(F.col("e.client_id"), F.col("client_id")).alias("client_id"),
        F.to_date("e.dos").alias("dos"),
        F.lit(None).cast("string").alias("provider_id"),
        F.lit(ccdm_version).alias("ccdm_version"),
        F.current_timestamp().alias("updated_at"),
    )


def build_mentions(events: DataFrame, ccdm_version: str) -> tuple[DataFrame, DataFrame]:
    """Returns (condition_mention rows, quarantine rows)."""
    assertion_map = F.create_map(*[F.lit(x) for kv in rules.ASSERTION_SOURCE_MAP.items() for x in kv])
    vocab_assertion = F.array(*[F.lit(v) for v in sorted(rules.VOCABULARY["assertion"])])

    m = (
        events.select("chart_id", F.posexplode_outer("e.nlp_output").alias("pos", "m"))
        .filter(F.col("m").isNotNull())
        .withColumn("icd10", F.upper(F.trim(F.element_at("m.code_candidates", 1))))
        .withColumn("assertion", assertion_map[F.lower(F.trim(F.col("m.assertion")))])
        .withColumn("section", F.upper(F.trim(F.col("m.section"))))
        .withColumn("page", F.col("m.page"))
        .withColumn("char_start", F.col("m.start"))
        .withColumn("char_end", F.col("m.end"))
        .withColumn("mention_id", F.concat(F.lit("M-"), F.substring(
            F.sha1(F.concat_ws("|", "chart_id", F.col("char_start").cast("string"),
                               F.col("char_end").cast("string"), F.coalesce("icd10", F.lit("")))), 1, 10)))
        .withColumn("reasons", F.array_compact(F.array(
            F.when(~F.coalesce(F.col("icd10"), F.lit("")).rlike(r"^[A-TV-Z][0-9][0-9A-Z](\.[0-9A-Z]{1,4})?$"), F.lit("icd10_invalid")),
            F.when(~F.array_contains(vocab_assertion, F.coalesce(F.col("assertion"), F.lit(""))), F.lit("assertion_not_in_vocabulary")),
            F.when(F.col("page").isNull() | (F.col("page") < 1), F.lit("page_missing")),
            F.when(F.col("char_start").isNull() | F.col("char_end").isNull() | (F.col("char_start") >= F.col("char_end")), F.lit("span_invalid")),
        )))
    )

    good = m.filter(F.size("reasons") == 0).select(
        "chart_id", "mention_id",
        F.concat(F.lit("ENC-"), F.col("chart_id")).alias("encounter_id"),
        "icd10",
        F.lit(None).cast("string").alias("hcc"),            # slice 2: lookup in ccdm.code_reference
        "page", "char_start", "char_end",
        F.trim(F.col("m.text")).alias("text_span"),
        "assertion", "section",
        F.lit(rules.CCDM_SOURCE).alias("source"),
        F.col("m.confidence").alias("source_conf"),
        F.lit(ccdm_version).alias("ccdm_version"),
        F.current_timestamp().alias("updated_at"),
    )
    bad = m.filter(F.size("reasons") > 0).select(
        "chart_id", "mention_id",
        F.concat_ws(",", "reasons").alias("reasons"),
        F.to_json("m").alias("mention_json"),
        F.lit(ccdm_version).alias("ccdm_version"),
        F.current_timestamp().alias("quarantined_at"),
    )
    return good, bad


# --------------------------------------------------------------------------- load
def _merge(spark: SparkSession, df: DataFrame, table: str, keys: list[str]) -> None:
    from delta.tables import DeltaTable  # imported here so the pure transforms above need no Delta on a laptop

    target = DeltaTable.forName(spark, table)
    cond = " AND ".join(f"t.{k} = s.{k}" for k in keys)
    (target.alias("t").merge(df.alias("s"), cond)
     .whenMatchedUpdateAll()
     .whenNotMatchedInsertAll()
     .execute())


def run(spark: SparkSession, s: Settings) -> dict:
    from delta.tables import DeltaTable

    s.validate()
    tables = ensure_tables(spark, s)
    bronze = spark.table(s.bronze_table("chart_events"))

    events = parse_events(latest_event_per_chart(bronze)).cache()
    encounters = build_encounters(events, s.ccdm_version)
    mentions, quarantine = build_mentions(events, s.ccdm_version)

    # a chart's earlier mentions (and quarantine rows) vanish when it is reprocessed: delete, then load
    charts = [r.chart_id for r in events.select("chart_id").distinct().collect()]
    if charts:
        DeltaTable.forName(spark, tables["condition_mention"]).delete(F.col("chart_id").isin(charts))
        DeltaTable.forName(spark, tables["quarantine"]).delete(F.col("chart_id").isin(charts))

    _merge(spark, encounters, tables["encounter"], ["chart_id", "encounter_id"])
    _merge(spark, mentions, tables["condition_mention"], ["chart_id", "mention_id"])
    quarantine.write.format("delta").mode("append").saveAsTable(tables["quarantine"])

    return {
        "charts": len(charts),
        "encounters": encounters.count(),
        "mentions": mentions.count(),
        "quarantined": quarantine.count(),
        "tables": tables,
    }
