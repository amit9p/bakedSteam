"""Runtime settings, read once from the job parameters (which arrive in notebooks as widgets)."""

from dataclasses import dataclass


@dataclass(frozen=True)
class Settings:
    catalog: str
    bronze_schema: str
    ccdm_schema: str
    volume_root: str
    ccdm_version: str = "0.1"
    generate_samples: bool = False

    @classmethod
    def from_widgets(cls, dbutils) -> "Settings":
        def get(name: str, default: str = "") -> str:
            try:
                return dbutils.widgets.get(name)
            except Exception:  # widget not defined when the notebook is run by hand
                return default

        return cls(
            catalog=get("catalog"),
            bronze_schema=get("bronze_schema"),
            ccdm_schema=get("ccdm_schema"),
            volume_root=get("volume_root").rstrip("/"),
            ccdm_version=get("ccdm_version", "0.1"),
            generate_samples=get("generate_samples", "false").strip().lower() == "true",
        )

    # ---- paths -------------------------------------------------------------
    @property
    def landing_path(self) -> str:
        return f"{self.volume_root}/landing/chart_events"

    @property
    def checkpoint_root(self) -> str:
        return f"{self.volume_root}/_checkpoints"

    # ---- tables ------------------------------------------------------------
    def bronze_table(self, name: str) -> str:
        return f"{self.catalog}.{self.bronze_schema}.{name}"

    def ccdm_table(self, name: str) -> str:
        return f"{self.catalog}.{self.ccdm_schema}.{name}"

    def validate(self) -> None:
        missing = [k for k in ("catalog", "bronze_schema", "ccdm_schema", "volume_root") if not getattr(self, k)]
        if missing:
            raise ValueError(f"Missing settings: {missing}. Pass them as job parameters or notebook widgets.")
