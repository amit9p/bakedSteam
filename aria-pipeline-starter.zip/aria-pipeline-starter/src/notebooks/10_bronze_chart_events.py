# Databricks notebook source
# MAGIC %md
# MAGIC # 10 · bronze.chart_events — land raw CIS events
# MAGIC Auto Loader reads new files from the landing folder and appends them, byte-for-byte, to the bronze
# MAGIC table. Runs to completion (`availableNow`) so a scheduled job costs nothing between runs.

# COMMAND ----------

import os, sys

def _add_src_to_path():
    """The notebook lives in src/notebooks/; the aria package lives in src/. Find src/ and put it on sys.path."""
    candidates = [os.path.abspath(os.path.join(os.getcwd(), ".."))]
    try:  # classic clusters: exact notebook path from the context (not available on serverless)
        nb = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()
        candidates.append(os.path.abspath(os.path.join("/Workspace" + nb, "..", "..")))
    except Exception:
        pass
    for c in candidates:
        if os.path.isdir(os.path.join(c, "aria")):
            if c not in sys.path:
                sys.path.insert(0, c)
            return c
    raise ImportError(f"aria package not found next to this notebook; looked in {candidates}")

try:
    import aria  # noqa: F401
except ImportError:
    _add_src_to_path()

from aria.config import Settings
from aria import bronze

# COMMAND ----------

settings = Settings.from_widgets(dbutils)
result = bronze.ingest_chart_events(spark, settings)
print(result)

# COMMAND ----------

display(spark.table(result["table"]).orderBy("received_at", ascending=False).limit(20))
