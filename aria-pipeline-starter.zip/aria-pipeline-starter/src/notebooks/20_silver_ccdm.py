# Databricks notebook source
# MAGIC %md
# MAGIC # 20 · Silver — CCDM v0.1 (encounter, condition_mention, quarantine)
# MAGIC Parses the latest bronze payload per chart, translates the NLP's words into CCDM words, validates
# MAGIC every mention, and MERGEs the result. Anything that fails validation lands in quarantine with a reason.

# COMMAND ----------

import os, sys

def _add_src_to_path():
    """The notebook lives in src/notebooks/; the aria package lives in src/. Find src/ and put it on sys.path."""
    candidates = [os.path.abspath(os.path.join(os.getcwd(), ".."))]
    try:  # classic clusters: exact notebook path from the context (not available on serverless)
        nb = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()
        candidates.append(os.path.abspath(os.path.join("/Workspace" + nb, "..", "..")))
    except Exception:
        pass
    for c in candidates:
        if os.path.isdir(os.path.join(c, "aria")):
            if c not in sys.path:
                sys.path.insert(0, c)
            return c
    raise ImportError(f"aria package not found next to this notebook; looked in {candidates}")

try:
    import aria  # noqa: F401
except ImportError:
    _add_src_to_path()

from aria.config import Settings
from aria import silver, quality

# COMMAND ----------

settings = Settings.from_widgets(dbutils)
result = silver.run(spark, settings)
print({k: v for k, v in result.items() if k != "tables"})

# COMMAND ----------

# Data-quality gates: fail the task loudly rather than let a bad table through
mentions = spark.table(result["tables"]["condition_mention"])
quality.assert_no_nulls(mentions, ["chart_id", "mention_id", "icd10", "assertion"], where="condition_mention")
quality.assert_min_rows(mentions, 1, where="condition_mention")

# COMMAND ----------

display(mentions.orderBy("chart_id", "page", "char_start"))

# COMMAND ----------

display(spark.table(result["tables"]["quarantine"]).orderBy("quarantined_at", ascending=False).limit(20))
