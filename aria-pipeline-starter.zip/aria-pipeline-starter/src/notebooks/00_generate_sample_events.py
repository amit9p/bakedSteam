# Databricks notebook source
# MAGIC %md
# MAGIC # 00 · Generate sample CIS events (dev only)
# MAGIC Writes one JSON-Lines file of synthetic chart events into the landing folder so the bronze task has
# MAGIC something to pick up. Skipped when the job parameter `generate_samples` is not `true` (mvp/prod).

# COMMAND ----------

import os, sys

def _add_src_to_path():
    """The notebook lives in src/notebooks/; the aria package lives in src/. Find src/ and put it on sys.path."""
    candidates = [os.path.abspath(os.path.join(os.getcwd(), ".."))]
    try:  # classic clusters: exact notebook path from the context (not available on serverless)
        nb = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()
        candidates.append(os.path.abspath(os.path.join("/Workspace" + nb, "..", "..")))
    except Exception:
        pass
    for c in candidates:
        if os.path.isdir(os.path.join(c, "aria")):
            if c not in sys.path:
                sys.path.insert(0, c)
            return c
    raise ImportError(f"aria package not found next to this notebook; looked in {candidates}")

try:
    import aria  # noqa: F401
except ImportError:
    _add_src_to_path()

from aria.config import Settings
from aria import sample_data

# COMMAND ----------

settings = Settings.from_widgets(dbutils)
settings.validate()

if settings.generate_samples:
    path = sample_data.write_sample_file(dbutils, settings)
    print(f"wrote {path}")
else:
    print("generate_samples is not true — nothing written (expected outside dev)")
