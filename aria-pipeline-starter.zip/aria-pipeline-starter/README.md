# aria-pipeline — starter (slice 1 of the ARIA data hub)

The smallest thing that is real: synthetic CIS chart events (your ingress contract from the ARIA walkthrough) land in a Volume → Auto Loader appends them to **`bronze.chart_events`** → a silver job turns the latest copy of each chart into **CCDM v0.1** tables **`encounter`**, **`condition_mention`**, **`quarantine`**. Everything is code: one job yml, one package, three thin notebooks, tests, a Jenkinsfile. Nothing gets created by hand in Databricks except your personal dev cluster.

```
CIS (later: Kafka)          today: 00_generate_sample_events writes a .jsonl into the landing Volume
        │
        ▼  Auto Loader (10_bronze_chart_events)
bronze.chart_events         exact payload, append-only, replayable
        │
        ▼  parse → source_map → vocabulary/code/span checks (20_silver_ccdm)
ccdm.encounter · ccdm.condition_mention          ← good rows (MERGE, idempotent)
ccdm.quarantine                                   ← bad rows with a reason
```

Layout is the standard Databricks Asset Bundle shape — `databricks.yml` at the repo root, `resources/*.yml`, `src/` — which is what the VS Code extension and `databricks bundle init` expect and what the Cotiviti CI/CD page describes. **If the reference repo `OAIP/dbx-ovaledgeprofiler` nests these differently, mirror that repo** — the Jenkins shared library expects its shape.

---

## Part A — one-time setup, in this order

**A1. Repo in Bitbucket.** Ask Reva/Rutvi which Bitbucket project ARIA lives in and have the project admin create `aria-pipeline` with branches `dev`, `mvp`, `prod` (default `dev`) and "pull request required" on all three. You need a Bitbucket HTTP access token (Manage account → HTTP access tokens) for `git clone` / `push`.

**A2. First commit.** Clone the repo, copy this starter into it (if you scaffolded a project with the VS Code extension's `bundle init`, delete its sample `resources/` and `src/` and keep only these files), then:

```powershell
git checkout -b feature/ARIA-1-bronze-silver-slice
git add . ; git commit -m "ARIA slice 1: bronze.chart_events + CCDM v0.1 silver (bundle, job, tests)"
git push -u origin feature/ARIA-1-bronze-silver-slice
```

Open a pull request into `dev`. Nothing runs yet — that's fine; the PR is how the repo gets its first reviewed content.

**A3. Jenkins + webhook (ask the owner of `Databricks_Migration`).** A merge does not "spin clusters"; it triggers Jenkins, which runs `databricks bundle deploy` so the *job definition* exists in the workspace. The job's cluster spins only when the job runs. What you need from the Jenkins owner: (1) a job for this repo under `Databricks_Migration/` (the same way `dbx-ovaledgeprofiler` has one), (2) the Bitbucket webhook on the repo pointing at Jenkins (Repository settings → Webhooks; they know the URL), (3) confirmation that `dab-sp-prod` — or an ARIA service principal — can deploy to the three workspaces. Then replace the placeholder call in `Jenkinsfile` with the exact `runDatabricksPipeline(...)` call from the reference repo.

**A4. Databricks dev workspace — the only manual bits.** (a) Compute → create your personal single-user cluster, auto-terminate 30–60 min. (b) Catalog Explorer → confirm `ai_engineering_dev_catalog_1688890232235261` › `amit_prasad` › Volume `personal` exist (the same place your Kerberos keytab goes). If the schema or Volume is missing, that's a Jira to the platform team, and change the defaults in `databricks.yml` to whatever you *do* have. Nothing else — tables, job, schedule all come from code.

**A5. Laptop.** VS Code + Databricks extension signed in (OAuth or PAT), the repo folder open, `.venv` created by clicking "Databricks Connect Disabled" → Yes. For the terminal commands below you also want the Databricks CLI (`winget install Databricks.DatabricksCLI`, or the zip from the CLI releases page) and one login: `databricks auth login --host https://dbc-0fa270fd-fb38.cloud.databricks.com --profile ai-eng-dev`.

---

## Part B — run slice 1 in dev

All commands from the repo root, in the VS Code terminal (or use the Databricks extension's Deploy / Run buttons, which run the same thing):

```powershell
databricks bundle validate -t dev -p ai-eng-dev        # reads databricks.yml + resources, checks it
databricks bundle deploy   -t dev -p ai-eng-dev        # uploads src/, creates job "[dev amit_prasad] aria_hello_pipeline"
databricks bundle run aria_hello_pipeline -t dev -p ai-eng-dev   # runs it and streams task status
```

Then look, in the Databricks UI: **Workflows** → `[dev amit_prasad] aria_hello_pipeline` → the run, three green tasks. **Catalog Explorer** → your schema → four new tables. Expected after the first run:

| table | rows | why |
|---|---|---|
| `chart_events` (bronze) | 4 | the sample file has 4 events, one of them a re-send of CH-8841 |
| `encounter` | 3 | one row per chart |
| `condition_mention` | 8 | CH-8841 latest copy 4 + CH-8842 3 + CH-8843 1 |
| `quarantine` | 2 | `XYZ` (icd10_invalid) and assertion `maybe` (assertion_not_in_vocabulary) |

Run it again: bronze grows by 4 (a new landing file), the silver tables stay at 3 / 8 / 2 — that is the idempotency you want to see. Unit tests on the laptop: `pytest` from the repo root (`test_rules.py` needs nothing; `test_silver_transforms.py` uses Databricks Connect when the cluster is running, otherwise skips).

Iterating: edit in VS Code (Claude Code helps), save (the extension syncs to your `.bundle/…/dev/files`), then `bundle deploy` + `bundle run` again — or open the notebooks from that synced folder in the browser, attach your personal cluster, set the widgets to the same values as the variables, and run cell by cell.

---

## Part C — promote

1. PR `feature/…` → `dev`, review, merge → Jenkins deploys the *unprefixed* `aria_hello_pipeline` to the dev workspace.
2. Fill the `TODO`s in `databricks.yml` for mvp and prod (workspace hosts, catalogs, service principal application id) — values from Yesh.
3. PR `dev` → `mvp`, PR `mvp` → `prod`. In those targets `generate_samples` is `false`, so the pipeline waits for real landing files (or the Kafka reader, slice 2).
4. Uncomment `schedule:` in the job yml when it should run on its own.

---

## Manual vs. code

| Manual, dev only | Code, every environment |
|---|---|
| your personal cluster · tokens · checking the schema/Volume exist · looking at runs and tables | catalog/schema/table DDL (`ensure_table`), the job and its tasks, retries, alerts, schedule, parameters, cluster spec, tests |

## Next slices (in the order your architecture needs them)

1. Replace `00_generate_sample_events` with the real ingress: Structured Streaming from the CIS Kafka topic (`aria.chart.ready`) — only `bronze.py`'s reader changes — or Auto Loader on files CIS drops.
2. `ccdm.vocabulary`, `ccdm.source_map`, `ccdm.code_reference` as real tables; silver reads them instead of `rules.py`; `hcc` filled from `code_reference`.
3. `ccdm.provider`, `ccdm.evidence_span`.
4. CTG store (`ctg.node`, `ctg.edge`) → gold (`gold.determination`, `gold.gate_result`) → egress to CIS.

## Cheat sheet

```
databricks bundle validate -t dev      check the bundle
databricks bundle deploy   -t dev      create/update the [dev …] job + upload code
databricks bundle run aria_hello_pipeline -t dev
databricks bundle summary  -t dev      what is deployed where
pytest                                 unit tests (repo root)
```
