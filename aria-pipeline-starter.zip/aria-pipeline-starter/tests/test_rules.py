"""Unit tests for the pure CCDM rules. Run on the laptop: `pytest` (no Spark, no Databricks needed)."""

from aria import rules


def test_assertion_translation_follows_source_map():
    assert rules.translate_assertion("present") == "ACTIVE"
    assert rules.translate_assertion(" History ") == "HISTORY"
    assert rules.translate_assertion("negated") == "NEGATED"
    assert rules.translate_assertion("possible") == "SUSPECTED"
    assert rules.translate_assertion("maybe") is None
    assert rules.translate_assertion(None) is None


def test_icd10_validation():
    assert rules.is_valid_icd10("E11.22")
    assert rules.is_valid_icd10("I10")
    assert rules.is_valid_icd10("I82.409")
    assert not rules.is_valid_icd10("XYZ")
    assert not rules.is_valid_icd10("")
    assert not rules.is_valid_icd10(None)
    assert rules.normalize_icd10(" e11.22 ") == "E11.22"


def test_mention_id_is_stable_and_distinct():
    a = rules.mention_id("CH-8841", 412, 454, "E11.22")
    b = rules.mention_id("CH-8841", 412, 454, "E11.22")
    c = rules.mention_id("CH-8841", 588, 599, "N18.30")
    assert a == b
    assert a != c
    assert a.startswith("M-") and len(a) == 12


def test_quarantine_reasons():
    assert rules.quarantine_reasons("E11.22", "ACTIVE", 3, 412, 454) == []
    assert "icd10_invalid" in rules.quarantine_reasons("XYZ", "ACTIVE", 1, 1, 2)
    assert "assertion_not_in_vocabulary" in rules.quarantine_reasons("I10", None, 1, 1, 2)
    assert "span_invalid" in rules.quarantine_reasons("I10", "ACTIVE", 1, 10, 5)
    assert "page_missing" in rules.quarantine_reasons("I10", "ACTIVE", 0, 1, 2)
