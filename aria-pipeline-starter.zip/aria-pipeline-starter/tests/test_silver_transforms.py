"""DataFrame-level tests for the silver transforms.

Runs through Databricks Connect against your personal cluster when the .venv has it (start the
cluster first), or a local pyspark if that's what is installed. Skips cleanly if neither is present.
"""

import json
from datetime import datetime

import pytest

pyspark = pytest.importorskip("pyspark")
from pyspark.sql import Row  # noqa: E402

from aria import bronze, silver  # noqa: E402


@pytest.fixture(scope="session")
def spark():
    try:
        from databricks.connect import DatabricksSession
        return DatabricksSession.builder.getOrCreate()
    except Exception:
        from pyspark.sql import SparkSession
        return SparkSession.builder.master("local[1]").appName("aria-tests").getOrCreate()


def _payload(chart_id, mentions):
    return json.dumps({
        "chart_id": chart_id, "client_id": "CLIENT-T", "mode": "COPILOT", "dos": "2026-03-14",
        "chart_pdf_uri": f"s3://x/{chart_id}.pdf", "source_msg_id": "k-1", "nlp_output": mentions,
    })


def test_latest_copy_wins_and_bad_mentions_are_quarantined(spark):
    old = _payload("CH-1", [{"text": "old", "start": 1, "end": 5, "page": 1, "code_candidates": ["I10"], "assertion": "present"}])
    new = _payload("CH-1", [
        {"text": "Type 2 diabetes", "start": 10, "end": 25, "page": 2, "code_candidates": ["E11.9"], "assertion": "present", "section": "HPI", "confidence": 0.9},
        {"text": "broken", "start": 30, "end": 20, "page": 2, "code_candidates": ["XYZ"], "assertion": "maybe"},
    ])
    bronze_df = spark.createDataFrame([
        Row(chart_id="CH-1", client_id="CLIENT-T", received_at=datetime(2026, 3, 15, 1, 0), payload=old,
            pdf_uri=None, source_msg_id="k-0", phi_flag=True, source_file="f0"),
        Row(chart_id="CH-1", client_id="CLIENT-T", received_at=datetime(2026, 3, 15, 2, 0), payload=new,
            pdf_uri=None, source_msg_id="k-1", phi_flag=True, source_file="f1"),
    ], schema=bronze.SCHEMA)

    events = silver.parse_events(silver.latest_event_per_chart(bronze_df))
    assert events.count() == 1

    good, bad = silver.build_mentions(events, "0.1")
    good_rows = good.collect()
    bad_rows = bad.collect()

    assert len(good_rows) == 1
    assert good_rows[0].icd10 == "E11.9"
    assert good_rows[0].assertion == "ACTIVE"
    assert good_rows[0].section == "HPI"
    assert good_rows[0].mention_id.startswith("M-")

    assert len(bad_rows) == 1
    reasons = bad_rows[0].reasons.split(",")
    assert {"icd10_invalid", "assertion_not_in_vocabulary", "span_invalid"} <= set(reasons)

    enc = silver.build_encounters(events, "0.1").collect()
    assert enc[0].encounter_id == "ENC-CH-1"
    assert str(enc[0].dos) == "2026-03-14"
