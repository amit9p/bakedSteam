# Project: ARIA data hub (layer 2) — Databricks pipeline

Replace this header with Cotiviti's "Sample Claude.md Rules File" (SharePoint / Cotiviti Github Agents Repo) and keep the project notes below.

## What this repo is
- The ARIA data-engineering pipeline on Databricks: CIS chart events → bronze → silver (CCDM) → CTG → gold → back to CIS.
- Slice 1 (this repo today): synthetic CIS events → `bronze.chart_events` → CCDM v0.1 `encounter`, `condition_mention`, `quarantine`.
- Deployed as a Databricks Asset Bundle. Jenkins runs `databricks bundle deploy -t <dev|mvp|prod>` on merge; nobody edits jobs in the UI.

## Environment
- Python 3.11 in `.venv` created by the Databricks VS Code extension (Databricks Connect). Do not activate it by hand.
- Dev workspace `https://dbc-0fa270fd-fb38.cloud.databricks.com`; dev tables live in the developer's personal schema (see `databricks.yml` variables).
- Cluster start (and Kerberos auth, if HDFS is ever a source) happens in the browser; the extension syncs every save to `/Users/<me>/.bundle/aria-pipeline/dev/files`.

## Layout
- `databricks.yml` — targets dev/mvp/prod + variables (catalog, schemas, volume_root, ccdm_version)
- `resources/*.job.yml` — the Workflow jobs (tasks, retries, schedule, notifications)
- `src/aria/` — package: `bronze.py`, `silver.py`, `rules.py` (pure, unit-tested), `config.py`, `quality.py`, `sample_data.py`
- `src/notebooks/` — thin entry points only; logic goes in the package
- `tests/` — pytest; `test_rules.py` needs nothing, `test_silver_transforms.py` uses Databricks Connect or local pyspark

## Conventions
- Bronze is append-only and never edited; silver is idempotent (MERGE on stable keys, latest copy of a chart wins).
- Every silver row carries `ccdm_version`. Vocabulary/source-map values live in `rules.py` until the CCDM reference tables exist.
- Table and column names follow ccdm-v0-1-design.md exactly. Don't invent new names without updating that doc.
- Never commit `.venv/`, `*.keytab`, `*.pem`, tokens, or real chart data. Sample data is synthetic and must stay that way.
- When changing a job, change the yml; when changing logic, add or update a test first.
